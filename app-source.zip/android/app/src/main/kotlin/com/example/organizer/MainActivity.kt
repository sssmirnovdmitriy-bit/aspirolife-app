package com.aspiroapp.aspirolife

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
