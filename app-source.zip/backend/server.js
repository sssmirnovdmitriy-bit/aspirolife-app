import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

const app = express();
app.use(cors());
app.use(express.json());

const {
  CLAUDE_API_KEY,
  TWELVEDATA_API_KEY,
  APP_SHARED_SECRET,
  PORT = 3000,
} = process.env;

const CLAUDE_MODEL = 'claude-haiku-4-5-20251001';

const TICKER_NAMES = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META', 'AMD'];

// Не даём валить сервер запросами — 60 запросов за 15 минут с одного IP.
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 60 });
app.use(limiter);

// Простая проверка, что запрос идёт из нашего приложения, а не откуда попало.
function requireAppSecret(req, res, next) {
  if (!APP_SHARED_SECRET) return next(); // если секрет не задан — не блокируем (для локальной отладки)
  if (req.header('x-app-secret') !== APP_SHARED_SECRET) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

app.get('/health', (req, res) => res.json({ ok: true }));

async function askClaude(system, user) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': CLAUDE_API_KEY,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: CLAUDE_MODEL,
      max_tokens: 1024,
      system,
      messages: [{ role: 'user', content: user }],
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Claude API error ${response.status}: ${text}`);
  }

  const data = await response.json();
  return (data.content || [])
    .map((block) => block.text || '')
    .join('')
    .replaceAll('*', '')
    .replaceAll('#', '');
}

app.post('/v1/ticker-analysis', requireAppSecret, async (req, res) => {
  const { ticker, days } = req.body || {};
  if (!ticker || !days) {
    return res.status(400).json({ error: 'ticker and days are required' });
  }

  try {
    const text = await askClaude(
      'Ты бот, который анализирует куда пойдет стоимость актива по тикеру',
      `Пронализируй, куда может пойти цена ${ticker} через ${days} дней. В ответе верни только - АНАЛИЗ: (анализ в 2-3 предложения, что может случиться в течении ${days} дней), РЕЗУЛЬТАТ: (куда пойдет цена)`,
    );
    res.json({ text });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'ai_unavailable' });
  }
});

app.post('/v1/mission', requireAppSecret, async (req, res) => {
  const { dateBirth } = req.body || {};
  if (!dateBirth) {
    return res.status(400).json({ error: 'dateBirth is required' });
  }

  try {
    const text = await askClaude(
      'Ты бот, который рассказывает миссию и предназначение человека на основе даты рождения',
      `Пронализируй дату рождения ${dateBirth}. В ответе верни только - МИССИЯ: (в 7-9 предложений), ПРЕДНАЗНАЧЕНИЕ: (в 7-9 предложений)`,
    );
    res.json({ text });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'ai_unavailable' });
  }
});

app.get('/v1/stock-prices', requireAppSecret, async (req, res) => {
  try {
    const params = new URLSearchParams({
      symbol: TICKER_NAMES.join(','),
      interval: '1day',
      outputsize: '2',
      apikey: TWELVEDATA_API_KEY,
    });

    const response = await fetch(`https://api.twelvedata.com/time_series?${params}`);
    if (!response.ok) {
      const text = await response.text();
      throw new Error(`TwelveData error ${response.status}: ${text}`);
    }

    const data = await response.json();
    const result = [];
    for (const symbol of TICKER_NAMES) {
      const json = data[symbol];
      if (json && json.status === 'ok') {
        result.push({ symbol, ...json });
      }
    }
    res.json({ result });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'stock_data_unavailable' });
  }
});

app.listen(PORT, () => {
  console.log(`AspiroLife backend listening on port ${PORT}`);
});
