import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/core/purchase/purchase_api.dart';
import 'package:organizer/core/purchase/purchase_constants.dart';
import 'package:organizer/core/purchase/store_config.dart';
import 'package:organizer/feature/my_app.dart';
import 'package:organizer/generated/codegen_loader.g.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:purchases_flutter/purchases_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  await initializeDateFormatting('ru', null);
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  if (defaultTargetPlatform == TargetPlatform.iOS) {
    StoreConfig(store: Store.appStore, apiKey: appleApiKey);
  } else if (defaultTargetPlatform == TargetPlatform.android) {
    StoreConfig(store: Store.playStore, apiKey: googleApiKey);
  }

  // 2️⃣ Инициализируем RevenueCat через PurchaseApi.init()
  await PurchaseApi.init();

  runApp(
    ProviderScope(
      child: EasyLocalization(
        supportedLocales: const [Locale('en'), Locale('ru')],
        path: 'assets/translations/',
        startLocale: const Locale('ru'),
        assetLoader: const CodegenLoader(),
        fallbackLocale: const Locale('en'),
        child: const MyApp(),
      ),
    ),
  );
}
