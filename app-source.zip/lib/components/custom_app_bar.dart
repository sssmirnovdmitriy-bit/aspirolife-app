import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';

class CustomAppBar extends StatelessWidget {
  final String text;
  const CustomAppBar({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: AnimatedButton(
            onTap: () {
              Navigation.goBack(context);
            },
            child: Icon(
              Icons.arrow_back_ios_new,
              color: AppConstants.whiteColor,
            ),
          ),
        ),
        Text(
          text,
          style: GoogleFonts.unbounded(
            color: AppConstants.whiteColor,
            fontSize: 14,
          ),
        ),

        SizedBox(width: 20, height: 50),
      ],
    );
  }
}
