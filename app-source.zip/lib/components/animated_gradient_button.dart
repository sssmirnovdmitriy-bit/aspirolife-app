import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AnimatedGradientButton extends StatefulWidget {
  final VoidCallback onPressed;
  final String text;
  final Widget? child;
  final double width;
  final double height;
  final Color startColor1;
  final Color endColor1;
  final Color startColor2;
  final Color endColor2;

  const AnimatedGradientButton({
    Key? key,
    required this.onPressed,
    required this.text,
    this.child,
    required this.width,
    required this.height,
    required this.startColor1,
    required this.endColor1,
    required this.startColor2,
    required this.endColor2,
  }) : super(key: key);

  @override
  _AnimatedGradientButtonState createState() => _AnimatedGradientButtonState();
}

class _AnimatedGradientButtonState extends State<AnimatedGradientButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Color?> _colorAnimation1;
  late Animation<Color?> _colorAnimation2;

  late AnimationController _sizeAnimationController;
  late Animation<double> _sizesAnimation;
  double _scale = 1.0;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    )..repeat(reverse: true);

    _colorAnimation1 = ColorTween(
      begin: widget.startColor1,
      end: widget.endColor1,
    ).animate(_controller);

    _colorAnimation2 = ColorTween(
      begin: widget.startColor2,
      end: widget.endColor2,
    ).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails details) {
    setState(() {
      _scale = 0.98; // уменьшение размера кнопки
    });
  }

  void _onTapUp(TapUpDetails details) {
    setState(() {
      _scale = 1.0; // возвращение кнопки к исходному размеру
    });
    widget.onPressed(); // выполнение действия
  }

  void _onTapCancel() {
    setState(() {
      _scale = 1.0; // возвращение кнопки к исходному размеру
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return GestureDetector(
          onTapDown: _onTapDown,
          onTapUp: _onTapUp,
          onTapCancel: _onTapCancel,
          child: Transform.scale(
            scale: _scale,
            child: Container(
              height: widget.height,
              width: widget.width,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _colorAnimation1.value ?? widget.startColor1,
                    _colorAnimation2.value ?? widget.startColor2,
                  ],
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      widget.text,
                      style: GoogleFonts.montserrat(
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(width: 4),
                    widget.child ?? const SizedBox(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
