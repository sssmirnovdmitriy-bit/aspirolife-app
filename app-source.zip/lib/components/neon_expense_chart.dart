import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class NeonYearlySavingsChart extends StatelessWidget {
  bool isMinus = false;

  final List<double> monthlyNetPlus = [
    10000,
    15000,
    -5000,
    20000,
    5000,
    -10000,
    15000,
    10000,
    5000,
    7000,
    -3000,
    12000,
  ];

  final List<double> monthlyNetMinus = [
    -5000,
    -7000,
    -3000,
    -4000,
    -6000,
    -8000,
    -2000,
    -1000,
    -500,
    -700,
    -300,
    -200,
  ];

  static const Color darkGreenColor = Color.fromARGB(255, 166, 255, 0);

  NeonYearlySavingsChart({super.key, required this.isMinus});

  @override
  Widget build(BuildContext context) {
    double total = 0;
    final List<FlSpot> savingsData = [];
    final List<bool> isPositive = [];

    final monthlyNet = isMinus ? monthlyNetMinus : monthlyNetPlus;

    // Создаём точки + сохраняем знак накоплений
    for (var i = 0; i < monthlyNet.length; i++) {
      total += monthlyNet[i];
      savingsData.add(FlSpot(i + 1.0, total));
      isPositive.add(total >= 0);
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
      ),
      padding: EdgeInsets.only(left: 12, right: 12),
      child: LineChart(
        LineChartData(
          gridData: FlGridData(show: false),
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false, reservedSize: 40),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 22,
                getTitlesWidget: (value, meta) {
                  return Text(
                    '${value.toInt()}м',
                    style: TextStyle(color: Colors.white, fontSize: 10),
                  );
                },
              ),
            ),
            rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          borderData: FlBorderData(show: false),
          lineBarsData: _generateColorSegments(savingsData, isPositive),
          minY:
              savingsData.map((e) => e.y).reduce((a, b) => a < b ? a : b) -
              5000,
        ),
      ),
    );
  }

  List<LineChartBarData> _generateColorSegments(
    List<FlSpot> data,
    List<bool> isPositive,
  ) {
    List<LineChartBarData> segments = [];
    int start = 0;

    for (int i = 1; i <= data.length; i++) {
      bool isLast = i == data.length;
      bool signChanged = !isLast && isPositive[i] != isPositive[i - 1];

      if (signChanged || isLast) {
        int end = isLast ? i - 1 : i;
        final segmentSpots = data.sublist(start, end + 1);
        final color = isPositive[start] ? darkGreenColor : Colors.redAccent;

        segments.add(
          LineChartBarData(
            spots: segmentSpots,
            isCurved: true,
            color: color,
            barWidth: 4,
            isStrokeCapRound: true,
            dotData: FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              color: color.withOpacity(0.2),
            ),
          ),
        );
        start = i;
      }
    }

    return segments;
  }
}
