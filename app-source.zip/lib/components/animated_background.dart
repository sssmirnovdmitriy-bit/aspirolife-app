import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:organizer/components/app_constants.dart';

class FloatingBlobsBackground extends StatefulWidget {
  @override
  _FloatingBlobsBackgroundState createState() =>
      _FloatingBlobsBackgroundState();
}

class _FloatingBlobsBackgroundState extends State<FloatingBlobsBackground>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 60), // Делаем анимацию медленной
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: BlobPainter(_controller.value),
          child: Container(),
        );
      },
    );
  }
}

class BlobPainter extends CustomPainter {
  final double progress;
  final Random random = Random();

  BlobPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint =
        Paint()
          ..style = PaintingStyle.fill
          ..maskFilter = MaskFilter.blur(
            BlurStyle.normal,
            50,
          ); // Больше размытия

    final colors = [
      AppConstants.darkGreenColor.withOpacity(0.3),
      AppConstants.darkYellowColor.withOpacity(0.3),
      AppConstants.bgColor.withOpacity(0.3),
      AppConstants.darkGreenColor.withOpacity(0.3),
      AppConstants.ligthYellowColor.withOpacity(0.3),
    ];

    for (int i = 0; i < 5; i++) {
      double dx =
          lerpDouble(
            size.width * 0.2,
            size.width * 0.8,
            (sin(progress * pi * 2 + i) + 1) /
                2, // Плавный синусоидальный сдвиг
          ) ??
          size.width * 0.5;

      double dy =
          lerpDouble(
            size.height * 0.2,
            size.height * 0.8,
            (cos(progress * pi * 2 + i) + 1) / 2, // Аналогичный сдвиг по Y
          ) ??
          size.height * 0.5;

      double radius =
          80 + (sin(progress * pi + i) + 1) * 30; // Плавное изменение размера

      paint.color = colors[i % colors.length];

      canvas.drawCircle(Offset(dx, dy), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant BlobPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
