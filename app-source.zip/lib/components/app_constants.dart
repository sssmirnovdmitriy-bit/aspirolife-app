import 'package:flutter/material.dart';
import 'package:organizer/core/models/book_model.dart';
import 'package:unicons/unicons.dart';

class AppConstants {
  static const Color bgColor = Color.fromARGB(255, 13, 14, 14);
  static const Color bgGreyColor = Color.fromARGB(255, 33, 34, 35);
  static const Color secondaryColor = Color.fromARGB(255, 32, 32, 33);
  static const Color redColor = Colors.redAccent;

  static const Color whiteColor = Color.fromARGB(255, 247, 245, 243);
  static const Color darkGreenColor = Color.fromARGB(255, 166, 255, 0);
  static const Color darkYellowColor = Color(0xFFD9B08C);
  static const Color ligthYellowColor = Color.fromARGB(255, 255, 175, 101);
  static const Color lightGreyColor = Color(0xFFD1E8E2);
  static const Color greyColor = Colors.grey;

  static const List<IconData> bottomIcons = [
    Icons.event_busy_rounded,
    Icons.event_available_rounded,
    Icons.family_restroom_rounded,
    Icons.cases_rounded,
  ];

  //IMAGES
  static const String pointsImage = 'assets/images/star_icon.png';

  //ICON
  static const String smokingIcon = 'assets/images/nosmoking_icon.png';
  static const String alcoholIcon = 'assets/images/alcohol_icon.png';
  static const String casinoIcon = 'assets/images/casino_icon.png';
  static const String drugsIcon = 'assets/images/drugs_icon.png';
  static const String socialsIcon = 'assets/images/socials_icon.png';
  static const String clockIcon = 'assets/images/clock_icon.png';
  static const String joggingIcon = 'assets/images/run.png';
  static const String eatingIcon = 'assets/images/eating.png';
  static const String yogaIcon = 'assets/images/yoga.png';
  static const String gymIcon = 'assets/images/weightlifting.png';

  //ANIMATIONS

  static const String casinoAnim = 'assets/lotties/casino_anim.json';
  static const String calendarAnim = 'assets/lotties/calendar_anim.json';
  static const String fireworksAnim = 'assets/lotties/fireworks_anim.json';
  static const String airAnim = 'assets/lotties/air_anim.json';
  static const String crownAnim = 'assets/lotties/crown_animation.json';
  static const String goldRainAnim = 'assets/lotties/gold_rain.json';
  static const String alcoholAnim = 'assets/lotties/alcohol_anim.json';
  static const String smokingAnim = 'assets/lotties/smoking_anim.json';
  static const String phoneAnim = 'assets/lotties/phone_anim.json';
  static const String drugsAnim = 'assets/lotties/drugs_anim.json';
  static const String fireAnim = 'assets/lotties/fire_animation.json';
  static const String heartAnim = 'assets/lotties/heart_animation.json';
  static const String messageAnim = 'assets/lotties/message_anim.json';
  static const String joggingAnim = 'assets/lotties/jogging_anim.json';
  static const String foodAnim = 'assets/lotties/eating_anim.json';
  // static const String gymAnim = 'assets/lotties/workout_anim.json';
  static const String gymAnim = 'assets/images/vector_icon_sport.svg';
  static const String yogaAnim = 'assets/lotties/yoga_anim.json';
  static const String meditationAnim = 'assets/lotties/meditation_anim.json';

  List<BookModel> books = [
    BookModel(
      text: 'Бодо Шефер "Мани или азбука денег"',
      description:
          'Финансовая грамотность для всех и каждого. Книга предназначена в первую очередь для детей, но полезна и взрослым. Она поможет восполнить пробелы в финансовом воспитании и заложить основы разумного обращения с деньгами.',
      isRead: false,
    ),
    BookModel(
      text: 'Бодо Шефер "Путь к финансовой свободе"',
      description:
          'Четкая пошаговая инструкция к финансовой свободе и денежной стабильности. Автор делится принципами, которые помогут обрести материальную независимость.',
      isRead: false,
    ),
    BookModel(
      text: 'Роберт Кийосаки "Богатый папа – бедный папа"',
      description:
          'Отличное руководство для начинающих инвесторов. Объясняет различия в подходах к деньгам у бедных и богатых, и подчеркивает важность финансовой грамотности.',
      isRead: false,
    ),
    BookModel(
      text: 'Роберт Кийосаки "Квадрант денежного потока"',
      description:
          'Изучение финансовых потоков и способов изменить свою финансовую судьбу. Объясняет различие между работой по найму и предпринимательством.',
      isRead: false,
    ),
    BookModel(
      text: 'Наполеон Хилл "Думай и богатей"',
      description:
          'Классика по психологии успеха. В книге даны принципы достижения богатства и развития личности через правильное мышление и окружение.',
      isRead: false,
    ),
    BookModel(
      text: 'Джордж Клейсон "Самый богатый человек в Вавилоне"',
      description:
          'О накоплении и сохранении капитала. Практическое руководство, как выстроить финансовую стабильность на основе простых, проверенных временем правил.',
      isRead: false,
    ),
    BookModel(
      text: 'Роберт Г. Аллен "Множественные источники дохода"',
      description:
          '10 стратегий для увеличения дохода и создания финансовой независимости. Подходит для тех, кто хочет зарабатывать, не жертвуя временем и вложениями.',
      isRead: false,
    ),
    BookModel(
      text: 'Т. Харв Экер "Думай, как миллионер"',
      description:
          'Финансовая психология: как мышление влияет на благосостояние. Рекомендации по «перепрошивке» подсознания на богатство и успех.',
      isRead: false,
    ),
    BookModel(
      text: 'Джо Витале "Как делать деньги"',
      description:
          'Открывает секреты богатейших людей планеты и показывает, как правильно тратить и зарабатывать деньги, чтобы они возвращались с удвоенной силой.',
      isRead: false,
    ),
    BookModel(
      text: 'Ричард Брэнсон "К черту все! Берись и делай!"',
      description:
          'Манифест предпринимателя. О том, как действовать смело, не боясь риска и не дожидаясь идеальных условий. Источник мотивации и силы.',
      isRead: false,
    ),
  ];

  static const Map<String, IconData> badHabitIcons = {
    "SMOKING": Icons.smoke_free_outlined, // 🚬 курение
    "ALCOHOL": UniconsLine.glass_martini, // 🍸 алкоголь
    "SOCIALS": UniconsLine.mobile_android, // 📱 соцсети
    "DRUGS": UniconsLine.capsule, // 💊 наркотики
    "GAMBLING": UniconsLine.dice_five, // 🎲 азартные игры
    "TIMELOSS": UniconsLine.history, // ⏳ потеря времени
  };

  // хорошие привычки
  static const Map<String, IconData> goodHabitIcons = {
    "JOGGING": Icons.run_circle_outlined, // 🏃 бег
    "YOGA": UniconsLine.flower, // 🌸 йога
    "MEDITATION":
        UniconsLine.brightness, // ☀️ медитация (символ внутреннего света)
    "EATING": UniconsLine.utensils, // 🍴 питание
    "GYM": UniconsLine.dumbbell,
    "HARDENING": UniconsLine.cloud_showers_alt,
    "WORKOUT": Icons.sports_gymnastics_rounded,
    // 🏋️ спортзал
  };

  String pluralizeDays(int days) {
    final n = days % 100;
    if (n >= 11 && n <= 19) {
      return "$days дней";
    }
    switch (n % 10) {
      case 1:
        return "$days день";
      case 2:
      case 3:
      case 4:
        return "$days дня";
      default:
        return "$days дней";
    }
  }

  /// универсальный хелпер
  static IconData getHabitIcon(String type, {bool isGood = false}) {
    if (isGood) {
      return goodHabitIcons[type] ?? Icons.help_outline;
    } else {
      return badHabitIcons[type] ?? Icons.help_outline;
    }
  }
}
