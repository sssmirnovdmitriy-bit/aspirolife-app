import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:organizer/components/app_constants.dart';

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CountdownText extends StatefulWidget {
  final DateTime startDate;

  const CountdownText({super.key, required this.startDate});

  @override
  _CountdownTextState createState() => _CountdownTextState();
}

class _CountdownTextState extends State<CountdownText> {
  late Timer _timer;
  late DateTime _currentDateTime;

  @override
  void initState() {
    super.initState();
    _currentDateTime = DateTime.now();
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _currentDateTime = DateTime.now();
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel(); // Останавливаем таймер, когда виджет уничтожается
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final difference = widget.startDate.difference(
      _currentDateTime,
    ); // Разница между текущей датой и startDate

    String text;
    if (difference.isNegative) {
      text = "Миссия началась"; // Если миссия уже началась
    } else {
      final hours = difference.inHours;
      final minutes = difference.inMinutes % 60;
      text = "До новой миссии: \n${hours}ч ${minutes}мин";
    }

    return Text(
      text,
      textAlign: TextAlign.end,
      style: GoogleFonts.unbounded(
        fontSize: 12,
        color: Colors.grey, // Примерный цвет
      ),
    );
  }
}
