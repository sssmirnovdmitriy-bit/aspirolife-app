// Разовая (non-consumable) покупка книги — отдельно от Pro-подписки.
// Product ID должен точно совпадать с тем, что заведено в App Store Connect
// и Google Play Console, и с тем, что импортировано в RevenueCat.
const String bookProductId = 'com.aspiroapp.aspirolife.book_mir_ne_lyubit_bednyh';

// Entitlement в RevenueCat, привязанный к этому продукту.
const String bookEntitlementId = 'Book';

const String bookTitle = 'Мир не любит бедных';
const String bookDescription =
    'Книга о том, как перестать быть бедным и начать управлять деньгами.';

// Путь к файлу книги внутри приложения (bundled asset).
const String bookAssetPath = 'assets/books/mir_ne_lyubit_bednyh.pdf';
