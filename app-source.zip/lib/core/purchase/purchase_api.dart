import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:organizer/core/purchase/store_config.dart';

class PurchaseApi {
  static Future init() async {
    await Purchases.setLogLevel(LogLevel.verbose);

    PurchasesConfiguration configuration =
        PurchasesConfiguration(StoreConfig.instance.apiKey)
          ..appUserID = null
          ..purchasesAreCompletedBy = const PurchasesAreCompletedByRevenueCat();

    await Purchases.configure(configuration);

    // Принудительная синхронизация
    try {
      debugPrint('🔄 Syncing purchases...');
      await Purchases.syncPurchases();
      await Future.delayed(const Duration(seconds: 1));
    } catch (e) {
      debugPrint('⚠️ Sync warning: $e');
    }

    try {
      debugPrint('\n========================================');
      debugPrint('🚀 REVENUECAT INITIALIZATION');
      debugPrint('========================================');
      debugPrint('🔑 API Key: ${StoreConfig.instance.apiKey}');
      debugPrint('📱 Store: ${StoreConfig.instance.store}');

      final customerInfo = await Purchases.getCustomerInfo();
      debugPrint('\n✅ Customer Info:');
      debugPrint('   User ID: ${customerInfo.originalAppUserId}');
      debugPrint(
        '   All Entitlements: ${customerInfo.entitlements.all.keys.toList()}',
      );
      debugPrint(
        '   Active Entitlements: ${customerInfo.entitlements.active.keys.toList()}',
      );

      final offerings = await Purchases.getOfferings();
      debugPrint('\n📦 OFFERINGS:');
      debugPrint('   Total offerings: ${offerings.all.length}');
      debugPrint(
        '   Current offering: ${offerings.current?.identifier ?? "NOT SET"}',
      );

      if (offerings.all.isEmpty) {
        debugPrint('\n❌ NO OFFERINGS FOUND!');
        debugPrint('\n⚠️ This usually means:');
        debugPrint('   1. Shared Secret not configured in RevenueCat');
        debugPrint('   2. Products not synced from App Store Connect');
        debugPrint('   3. Need to wait 5-10 minutes after configuration');
        debugPrint('\n📋 Expected products:');
        debugPrint('   • com.aspiroapp.aspirolife.Monthly');
        debugPrint('   • com.aspiroapp.aspirolife.Annual');
      } else {
        debugPrint('\n✅ Offerings loaded successfully:');
        offerings.all.forEach((key, offering) {
          final isCurrent = key == offerings.current?.identifier;
          debugPrint(
            '${isCurrent ? "⭐" : "  "} $key (${offering.availablePackages.length} packages)',
          );

          for (var package in offering.availablePackages) {
            debugPrint('      📦 ${package.identifier}');
            debugPrint('         Product: ${package.storeProduct.identifier}');
            debugPrint('         Title: ${package.storeProduct.title}');
            debugPrint('         Price: ${package.storeProduct.priceString}');
          }
        });
      }

      debugPrint('========================================\n');
    } catch (e, stackTrace) {
      debugPrint('\n❌ INITIALIZATION ERROR:');
      debugPrint('Error: $e');
      if (e is PlatformException) {
        debugPrint('Code: ${e.code}');
        debugPrint('Message: ${e.message}');
        debugPrint('Details: ${e.details}');
      }
      debugPrint('Stack: $stackTrace\n');
    }
  }

  static Future<List<Offering>> fetchOffers() async {
    try {
      debugPrint('🔄 Fetching offerings...');

      final offerings = await Purchases.getOfferings();
      debugPrint('Available offerings: ${offerings.all.keys.toList()}');

      final targetOffering =
          offerings.current ?? offerings.all['standart.offerings'];

      if (targetOffering != null) {
        debugPrint('✅ Using offering: ${targetOffering.identifier}');
        debugPrint('Packages: ${targetOffering.availablePackages.length}');
        return [targetOffering];
      } else {
        debugPrint('❌ No suitable offering found');
        return [];
      }
    } catch (e) {
      debugPrint('❌ Error fetching offers: $e');
      return [];
    }
  }
}
