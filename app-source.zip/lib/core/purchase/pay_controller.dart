import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/purchase/paywall.dart';
import 'package:organizer/core/purchase/purchase_api.dart';
import 'package:organizer/core/purchase/purchase_constants.dart';
import 'package:purchases_flutter/purchases_flutter.dart';

final payController = ChangeNotifierProvider(((ref) => PayController()));

class PayController extends ChangeNotifier {
  bool hasSubscription = false;
  bool isPayLoading = false;
  bool isCheckingSubscription = false;

  PayController();

  Future fetchOffers() async {
    final offers = await PurchaseApi.fetchOffers();

    if (offers.isNotEmpty) {
      debugPrint('First offer: ${offers.first.identifier}');
    } else {
      debugPrint("no offers");
    }
  }

  void payLoading(bool value, BuildContext context) {
    isPayLoading = value;
    notifyListeners();
  }

  Future<void> purchasePackage(Package package, BuildContext context) async {
    payLoading(true, context);
    try {
      final purchaseParams = PurchaseParams.package(package);
      final purchaseResult = await Purchases.purchase(purchaseParams);

      debugPrint(
        'Purchase successful: ${purchaseResult.customerInfo.entitlements.all.keys}',
      );

      // Проверяем статус подписки из customerInfo результата покупки
      final customerInfo = purchaseResult.customerInfo;
      final entitlement = customerInfo.entitlements.all[entitlementID];

      debugPrint('Entitlement after purchase: ${entitlement?.identifier}');
      debugPrint('Is active after purchase: ${entitlement?.isActive}');

      if (entitlement != null && entitlement.isActive) {
        hasSubscription = true;
        notifyListeners();

        if (context.mounted) {
          AppNotifications.showSuccess(context, "Подписка успешно оформлена!");
        }
      } else {
        debugPrint('⚠️ Warning: Purchase completed but entitlement not active');
        // Даем время на синхронизацию и проверяем еще раз
        await Future.delayed(Duration(seconds: 2));
        await checkSubscription();

        if (context.mounted) {
          if (hasSubscription) {
            AppNotifications.showSuccess(
              context,
              "Подписка успешно оформлена!",
            );
          } else {
            AppNotifications.showError(
              context,
              'Покупка завершена, но подписка не активирована. Попробуйте восстановить покупки.',
            );
          }
        }
      }
    } on PlatformException catch (e) {
      debugPrint("Purchase error: ${e.code} - ${e.message}");

      if (context.mounted) {
        final errorCode = PurchasesErrorHelper.getErrorCode(e);
        if (errorCode != PurchasesErrorCode.purchaseCancelledError) {
          AppNotifications.showError(context, 'Ошибка покупки: ${e.message}');
        }
      }
    } catch (e) {
      debugPrint("Purchase unexpected error: $e");
      if (context.mounted) {
        AppNotifications.showError(context, 'Непредвиденная ошибка: $e');
      }
    }
    payLoading(false, context);
  }

  Future<void> restorePurchase(BuildContext context) async {
    payLoading(true, context);
    try {
      final customerInfo = await Purchases.restorePurchases();

      debugPrint('Restore successful: ${customerInfo.entitlements.all.keys}');
      debugPrint('All entitlements after restore:');
      customerInfo.entitlements.all.forEach((key, entitlement) {
        debugPrint('  - $key: isActive=${entitlement.isActive}');
      });

      // Проверяем статус подписки из customerInfo результата восстановления
      final entitlement = customerInfo.entitlements.all[entitlementID];

      if (entitlement != null && entitlement.isActive) {
        hasSubscription = true;
        notifyListeners();

        if (context.mounted) {
          Navigation.goBack(context);
          AppNotifications.showSuccess(
            context,
            "Покупки успешно восстановлены!",
          );
        }
      } else {
        hasSubscription = false;
        notifyListeners();

        if (context.mounted) {
          AppNotifications.showError(context, 'Активные покупки не найдены');
        }
      }
    } catch (e) {
      debugPrint("Restore error: $e");
      if (context.mounted) {
        AppNotifications.showError(context, 'Ошибка восстановления покупок');
      }
    }
    payLoading(false, context);
  }

  Future<void> checkSubscription({bool restore = false}) async {
    isCheckingSubscription = true;
    if (!restore) {
      // Только если это не первый запуск
      Future.microtask(() => notifyListeners());
    } else {
      notifyListeners();
    }

    try {
      final customerInfo = await Purchases.getCustomerInfo();

      debugPrint('\n========================================');
      debugPrint('🔍 CHECKING SUBSCRIPTION STATUS');
      debugPrint('========================================');
      debugPrint('Looking for entitlement: $entitlementID');
      debugPrint(
        'All available entitlements: ${customerInfo.entitlements.all.keys.toList()}',
      );

      customerInfo.entitlements.all.forEach((key, entitlement) {
        debugPrint('\nEntitlement: $key');
        debugPrint('  - isActive: ${entitlement.isActive}');
        debugPrint('  - willRenew: ${entitlement.willRenew}');
        debugPrint('  - productIdentifier: ${entitlement.productIdentifier}');
        debugPrint('  - expirationDate: ${entitlement.expirationDate}');
      });

      final entitlement = customerInfo.entitlements.all[entitlementID];

      if (entitlement != null) {
        debugPrint('\n✅ Found entitlement: $entitlementID');
        debugPrint('Is active: ${entitlement.isActive}');
        hasSubscription = entitlement.isActive;
      } else {
        debugPrint('\n❌ Entitlement not found: $entitlementID');
        hasSubscription = false;
      }

      debugPrint('Final hasSubscription: $hasSubscription');
      debugPrint('========================================\n');
    } catch (e) {
      debugPrint("❌ checkSubscription error: $e");
      if (!restore) {
        // Сохраняем текущее значение при ошибке
      }
    } finally {
      isCheckingSubscription = false;
      notifyListeners();
    }
  }

  void setHasSubscription(bool value) {
    hasSubscription = value;
    notifyListeners();
  }

  void showPlans(BuildContext context) async {
    try {
      CustomerInfo customerInfo = await Purchases.getCustomerInfo();

      if (customerInfo.entitlements.all[entitlementID] != null &&
          customerInfo.entitlements.all[entitlementID]?.isActive == true) {
        debugPrint("User already has active subscription");
        if (context.mounted) {
          AppNotifications.showSuccess(
            context,
            'У вас уже есть активная подписка',
          );
        }
        return;
      }

      Offerings? offerings;
      try {
        offerings = await Purchases.getOfferings();
      } on PlatformException catch (e) {
        debugPrint('Error fetching offerings: ${e.message}');
      }

      if (offerings == null || offerings.current == null) {
        debugPrint("No offerings available");
        if (context.mounted) {
          AppNotifications.showError(
            context,
            'Предложения временно недоступны',
          );
        }
      } else {
        if (context.mounted) {
          await showModalBottomSheet(
            useRootNavigator: true,
            isDismissible: !isPayLoading,
            enableDrag: !isPayLoading,
            isScrollControlled: true,
            backgroundColor: AppConstants.whiteColor,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
            ),
            context: context,
            builder: (BuildContext context) {
              return Paywall(offering: offerings!.current!);
            },
          );
        }
      }
    } catch (e) {
      debugPrint('Error in showPlans: $e');
    }
  }
}
