//TO DO: add the entitlement ID from the RevenueCat dashboard that is activated upon successful in-app purchase for the duration of the purchase.
const entitlementID = 'Pro';

//TO DO: add your subscription terms and conditions
const footerText =
    "Your subscription will automatically renew each period 24-hours before the end of the current period. \nYour credit card will be charged through your Apple ID unless auto-renew is turned off at least 24-hours before the end of the current period. You can turn off auto-renew and cancel the subscription at any time from your Apple ID settings. You do not need to subscribe to use the app.";

const footerTextRu =
    "Ваша подписка будет автоматически продлеваться за 24 часа до окончания текущего периода. С вашего аккаунта Apple ID будет списана сумма оплаты, если автопродление не отключено как минимум за 24 часа до конца текущего периода. Вы можете в любое время отключить автопродление и отменить подписку в настройках вашего Apple ID. Подписка не требуется для использования приложения.";

//TO DO: add the Apple API key for your app from the RevenueCat dashboard: https://app.revenuecat.com
const appleApiKey = 'appl_cKXwSSTsURbZqPtbQlBauifaRgZ';

const googleApiKey = 'goog_xErTlYibmiTWCmxxwSGoeZeuRdl';
