import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/purchase/pay_controller.dart';
import 'package:organizer/core/purchase/purchase_constants.dart';
import 'package:purchases_flutter/models/offering_wrapper.dart';
import 'package:url_launcher/url_launcher_string.dart';

class Paywall extends ConsumerStatefulWidget {
  final Offering offering;
  const Paywall({Key? key, required this.offering}) : super(key: key);

  @override
  _PaywallState createState() => _PaywallState();
}

class _PaywallState extends ConsumerState<Paywall> {
  int? selectedIndex;

  @override
  Widget build(BuildContext context) {
    var model = ref.watch(payController);
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppConstants.bgColor, AppConstants.bgGreyColor],
        ),
      ),
      child: SafeArea(
        child:
            model.isPayLoading
                ? Center(
                  child: CircularProgressIndicator(
                    color: AppConstants.darkGreenColor,
                    strokeWidth: 2,
                  ),
                )
                : SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Закрыть кнопка
                        Align(
                          alignment: Alignment.topRight,
                          child: IconButton(
                            onPressed: () => Navigator.pop(context),
                            icon: Icon(
                              Icons.close,
                              color: AppConstants.whiteColor,
                              size: 20,
                            ),
                          ),
                        ),

                        // Иконка премиум
                        Container(
                          padding: EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [
                                AppConstants.darkGreenColor,
                                AppConstants.ligthYellowColor,
                              ],
                            ),
                          ),
                          child: Icon(
                            Icons.workspace_premium,
                            size: 28,
                            color: AppConstants.bgColor,
                          ),
                        ),

                        SizedBox(height: 12),

                        // Заголовок
                        Text(
                          "AspiroLife Pro",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            height: 1.2,
                          ),
                        ),

                        SizedBox(height: 6),

                        // Подзаголовок
                        Text(
                          "Получи полный доступ ко всем функциям",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.unbounded(
                            color: AppConstants.greyColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w400,
                          ),
                        ),

                        SizedBox(height: 16),

                        // Преимущества
                        _buildFeatureItem(
                          Icons.list,
                          "Неограниченное создание привычек",
                        ),
                        SizedBox(height: 8),
                        _buildFeatureItem(
                          Icons.monetization_on_outlined,
                          "Полный доступ к Финансовому блоку",
                        ),
                        SizedBox(height: 8),
                        _buildFeatureItem(
                          Icons.menu_book_rounded,
                          "Дополнительное обучение",
                        ),

                        SizedBox(height: 20),

                        // Пакеты подписок
                        ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: widget.offering.availablePackages.length,
                          itemBuilder: (BuildContext context, int index) {
                            var myProductList =
                                widget.offering.availablePackages;
                            bool isSelected = selectedIndex == index;

                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  selectedIndex = index;
                                });
                              },
                              child: Container(
                                margin: EdgeInsets.only(bottom: 8),
                                padding: EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color:
                                      isSelected
                                          ? AppConstants.secondaryColor
                                          : AppConstants.bgGreyColor,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color:
                                        isSelected
                                            ? AppConstants.darkGreenColor
                                            : Colors.transparent,
                                    width: 1.5,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    // Радио кнопка
                                    Container(
                                      width: 18,
                                      height: 18,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color:
                                              isSelected
                                                  ? AppConstants.darkGreenColor
                                                  : AppConstants.greyColor,
                                          width: 1.5,
                                        ),
                                      ),
                                      child:
                                          isSelected
                                              ? Center(
                                                child: Container(
                                                  width: 8,
                                                  height: 8,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color:
                                                        AppConstants
                                                            .darkGreenColor,
                                                  ),
                                                ),
                                              )
                                              : null,
                                    ),

                                    SizedBox(width: 10),

                                    // Информация о пакете
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            myProductList[index]
                                                .storeProduct
                                                .title
                                                .replaceAll(
                                                  RegExp(r'\(.*?\)'),
                                                  '',
                                                )
                                                .trim(),
                                            style: GoogleFonts.unbounded(
                                              color: AppConstants.whiteColor,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          SizedBox(height: 2),
                                          Text(
                                            myProductList[index]
                                                .storeProduct
                                                .description,
                                            style: GoogleFonts.unbounded(
                                              color: AppConstants.greyColor,
                                              fontSize: 9,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    // Цена
                                    Text(
                                      myProductList[index]
                                          .storeProduct
                                          .priceString,
                                      style: GoogleFonts.unbounded(
                                        color: AppConstants.darkGreenColor,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),

                        SizedBox(height: 16),

                        // Кнопка подписки
                        GestureDetector(
                          onTap:
                              selectedIndex != null
                                  ? () async {
                                    await ref
                                        .read(payController)
                                        .purchasePackage(
                                          widget
                                              .offering
                                              .availablePackages[selectedIndex!],
                                          context,
                                        );
                                    Navigator.pop(context);
                                  }
                                  : null,
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              gradient:
                                  selectedIndex != null
                                      ? LinearGradient(
                                        colors: [
                                          AppConstants.darkGreenColor,
                                          AppConstants.ligthYellowColor,
                                        ],
                                      )
                                      : null,
                              color:
                                  selectedIndex == null
                                      ? AppConstants.greyColor.withOpacity(0.3)
                                      : null,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Text(
                                "Продолжить",
                                style: GoogleFonts.unbounded(
                                  color:
                                      selectedIndex != null
                                          ? AppConstants.bgColor
                                          : AppConstants.greyColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                        ),

                        SizedBox(height: 10),

                        // Восстановить покупки
                        TextButton(
                          onPressed: () async {
                            await ref
                                .read(payController)
                                .restorePurchase(context);
                          },
                          child: Text(
                            "Восстановить покупку",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.darkGreenColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),

                        SizedBox(height: 12),

                        // Footer текст
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4.0),
                          child: Text(
                            footerTextRu,
                            textAlign: TextAlign.center,
                            style: GoogleFonts.unbounded(
                              color: AppConstants.greyColor.withOpacity(0.7),
                              fontSize: 8,
                              fontWeight: FontWeight.w400,
                              height: 1.3,
                            ),
                          ),
                        ),

                        SizedBox(height: 10),

                        // Ссылки
                        RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "Подробнее в ",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.greyColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              TextSpan(
                                text: "Условиях использования",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.darkGreenColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600,
                                  decoration: TextDecoration.underline,
                                ),
                                recognizer:
                                    TapGestureRecognizer()
                                      ..onTap = () {
                                        launchUrlString(
                                          'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/',
                                        );
                                      },
                              ),
                              TextSpan(
                                text: " и ",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.greyColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              TextSpan(
                                text: "Политике конфиденциальности",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.darkGreenColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600,
                                  decoration: TextDecoration.underline,
                                ),
                                recognizer:
                                    TapGestureRecognizer()
                                      ..onTap = () {
                                        launchUrlString(
                                          'https://docs.google.com/document/d/1vxmWX3Zqmyry9fwnR95B9Fwk5fQagzWTqElCq3N72dc/edit?usp=sharing',
                                        );
                                      },
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 12),
                      ],
                    ),
                  ),
                ),
      ),
    );
  }

  Widget _buildFeatureItem(IconData icon, String text) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: AppConstants.darkGreenColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: AppConstants.darkGreenColor, size: 16),
        ),
        SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: GoogleFonts.unbounded(
              color: AppConstants.whiteColor,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }
}
