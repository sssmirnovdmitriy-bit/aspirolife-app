import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:organizer/core/purchase/book_constants.dart';

/// Разовая покупка (non-consumable) книги через RevenueCat,
/// отдельно от Pro-подписки.
class BookPurchaseService {
  Future<bool> hasBook() async {
    try {
      final info = await Purchases.getCustomerInfo();
      return info.entitlements.active.containsKey(bookEntitlementId);
    } catch (e) {
      return false;
    }
  }

  Future<StoreProduct?> fetchProduct() async {
    try {
      final products = await Purchases.getProducts([bookProductId]);
      return products.isEmpty ? null : products.first;
    } catch (e) {
      return null;
    }
  }

  /// Возвращает true при успешной покупке (или если книга уже куплена ранее).
  Future<bool> purchaseBook() async {
    try {
      final product = await fetchProduct();
      if (product == null) return false;

      final result = await Purchases.purchaseStoreProduct(product);
      return result.customerInfo.entitlements.active.containsKey(
        bookEntitlementId,
      );
    } catch (e) {
      return false;
    }
  }

  Future<bool> restorePurchases() async {
    try {
      final info = await Purchases.restorePurchases();
      return info.entitlements.active.containsKey(bookEntitlementId);
    } catch (e) {
      return false;
    }
  }
}
