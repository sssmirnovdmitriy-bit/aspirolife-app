class PayData {
  static final PayData _payData = PayData._internal();

  bool entitlementIsActive = false;
  String appUserID = '';

  factory PayData() {
    return _payData;
  }
  PayData._internal();
}

final payData = PayData();
