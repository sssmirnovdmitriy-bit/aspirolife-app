import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final navBarController = ChangeNotifierProvider(((ref) => NavBarController()));

class NavBarController extends ChangeNotifier {
  int selectedTab = 0;

  changeNavScreen(int index) {
    selectedTab = index;
    notifyListeners();
  }

  NavBarController() {}
}
