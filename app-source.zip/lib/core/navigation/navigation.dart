import 'package:flutter/material.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/models/note_model.dart';
import 'package:organizer/core/purchase/paywall.dart';
import 'package:organizer/feature/add_habbits_screen/bad/add_bh_screen_first.dart';
import 'package:organizer/feature/add_habbits_screen/bad/add_bh_screen_second.dart';
import 'package:organizer/feature/add_habbits_screen/good/add_gh_screen_first.dart';
import 'package:organizer/feature/add_habbits_screen/good/add_gh_screen_second.dart';
import 'package:organizer/feature/add_habbits_screen/my_habbit/add_my_habbit_screen.dart';
import 'package:organizer/feature/book_screen/presentation/book_screen.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/add_portfolio_screen.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/add_trade_screen.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/ai_ticker_price.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/finance_learn_screen.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/investment_screen.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/plan_screen.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/portfolio_screen.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/screens/trader_diary_screen.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/screens/gh_details_screen.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/lifestyle_add_yeargoal.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/lifestyle_entertainment_screen.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/lifestyle_hobby_screen.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/lifestyle_balance_wheel_screen.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/lifestyle_psychology_screen.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/lifestyle_your_mission_screen.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/survey_screen.dart';
import 'package:organizer/feature/one_habbit_analytics_screen/presentation/habbit_analytics_screen.dart';
import 'package:organizer/feature/organizer_screen/presentation/screens/add_note_screen.dart';
import 'package:organizer/feature/organizer_screen/presentation/screens/analytics_screen.dart';
import 'package:organizer/feature/organizer_screen/presentation/screens/notes_screen.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/add_task_screen.dart';
import 'package:organizer/feature/settings_screen/settings_screen.dart';
import 'package:purchases_flutter/object_wrappers.dart';

class Navigation {
  static goBack(BuildContext context) {
    return Navigator.of(context).pop();
  }

  static goToAddBhScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const AddBhScreenFirst()));
  }

  static goToAddGhScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const AddGhScreenFirst()));
  }

  static goToAnalyticsScreen(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const HabitsAnalyticsScreen()),
    );
  }

  static goToPlanScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const PlanScreen()));
  }

  static goToAiYourMissionScreen(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const AiYourMissionScreen()),
    );
  }

  static goToAiTickerScreen(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const AiTickerPriceScreen()),
    );
  }

  static goToTraderDiaryScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const TraderDiaryScreen()));
  }

  static goToAddTradeScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const AddTradeScreen()));
  }

  static goToFinanceLearnScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const FinanceLearnScreen()));
  }

  static goToBookScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const BookScreen()));
  }

  static goToHobbyScreen(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const LifestyleHobbyScreen()),
    );
  }

  static goToEntertainmentScreen(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const LifestyleEntertainmentScreen(),
      ),
    );
  }

  static goToBalanceWheelScreen(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const LifestyleBalanceWheelScreen(),
      ),
    );
  }

  static goToSettingsScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const SettingsScreen()));
  }

  static goToPsychologyScreen(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const LifestylePsychologyScreen(),
      ),
    );
  }

  static goToSurveyScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const SurveyScreen()));
  }

  static goToAddYearGoalScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const AddYearGoalScreen()));
  }

  static goToInvestmentScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const InvestmentScreen()));
  }

  static goToPortfolioScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const PortfolioScreen()));
  }

  static goToAddPortfolioScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const AddPortfolioScreen()));
  }

  static goToNotesScreen(BuildContext context) {
    return Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => NotesScreen()));
  }

  static goToAddMyHabbit(BuildContext context, bool isGoodHabbit) {
    return Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => AddMyHabbitScreen(isGoodHabbit)),
    );
  }

  static goToAddBhScreenSecond(BuildContext context, HabbitModel habit) {
    return Navigator.of(context).push(
      MaterialPageRout