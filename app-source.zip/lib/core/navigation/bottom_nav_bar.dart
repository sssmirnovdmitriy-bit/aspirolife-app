import 'dart:async';
import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation_controller.dart';
import 'package:organizer/core/purchase/pay_controller.dart';
import 'package:organizer/core/services/money_counter/money_count_controller.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/bad_habbits_screen.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';
import 'package:organizer/feature/finances_screen/presentation/finances_screen.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/good_habbits_screen.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/lifestyle_screen.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/organizer_screen.dart';

class CustomNavigationBar extends ConsumerStatefulWidget {
  CustomNavigationBar({super.key});

  @override
  CustomNavigationBarState createState() => CustomNavigationBarState();
}

class CustomNavigationBarState extends ConsumerState<CustomNavigationBar> {
  _changeTab(int index) {
    setState(() {
      ref.read(navBarController).selectedTab = index;
    });
  }

  @override
  void initState() {
    super.initState();
    _initAccount();
  }

  /// Checks internet connectivity by pinging google.com
  /// Returns true when connection is established
  Future<bool> _checkInternetConnection() async {
    final dio = Dio();
    try {
      final response = await dio.get(
        'https://www.google.com',
        options: Options(
          receiveTimeout: const Duration(seconds: 3),
          sendTimeout: const Duration(seconds: 3),
        ),
      );
      dio.close();
      return response.statusCode == 200;
    } catch (e) {
      dio.close();
      return false;
    }
  }

  /// Waits for internet connection by pinging google.com every 3 seconds
  /// Returns when connection is established
  Future<void> _waitForInternetConnection() async {
    while (true) {
      final hasConnection = await _checkInternetConnection();
      if (hasConnection) {
        return;
      }
      await Future.delayed(const Duration(seconds: 3));
    }
  }

  void _initAccount() async {
    // Wait for internet connection before initializing
    await _waitForInternetConnection();

    await ref.read(payController).checkSubscription();
    await ref.read(bhController).getMyActiveBadHabbits();
    await ref.read(ghController).getMyActiveGoodHabbits();
    await ref
        .read(organizerController)
        .getAllDailyMissionsByDate(ref, DateTime.now());
    await ref.read(organizerController).getAllTasksByDate(DateTime.now());
    await ref
        .read(organizerController)
        .getAllEntertainmentsByDate(DateTime.now());
    await ref.read(moneyCountController).getMyMoneySavings(ref);
    await ref.read(financesController).getBooks();
    await ref.read(financesController).readRealInvestments();
    await ref.read(financesController).getPortfolios();
    await ref.read(financesController).firstInitFinancesVideos();
    await ref.read(financesController).getTickers();
    await ref.read(lifeStyleController).getAllYearGoals();
    await ref.read(lifeStyleController).getAllHobbies();
    await ref.read(surveyController).initializeSurvey();
  }

  final List _pagesReg = [
    BadHabbitsScreen(),
    GoodHabbitsScreen(),
    LifestyleScreen(),
    FinancesScreen(),
  ];

  static const List<_NavTabData> _tabs = [
    _NavTabData(
      activeIcon: Icons.cancel_rounded,
      inactiveIcon: Icons.cancel_outlined,
      label: "Плохие\nпривычки",
    ),
    _NavTabData(
      activeIcon: Icons.check_circle_rounded,
      inactiveIcon: Icons.check_circle_outline_rounded,
      label: "Полезные\nпривычки",
    ),
    _NavTabData(
      activeIcon: Icons.eco_rounded,
      inactiveIcon: Icons.eco_outlined,
      label: "Лайфстайл",
    ),
    _NavTabData(
      activeIcon: Icons.account_balance_wallet_rounded,
      inactiveIcon: Icons.account_balance_wallet_outlined,
      label: "Финансы",
    ),
  ];

  Widget _buildTabItem(int index, bool isActive) {
    final data = _tabs[index];
    return Padding(
      padding: const EdgeInsets.only(top: 6.0, bottom: 4),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutBack,
            padding: EdgeInsets.symmetric(
              horizontal: isActive ? 14 : 8,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color:
                  isActive
                      ? AppConstants.darkGreenColor.withOpacity(0.16)
                      : Colors.transparent,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              isActive ? data.activeIcon : data.inactiveIcon,
              size: isActive ? 25 : 22,
              color:
                  isActive ? AppConstants.darkGreenColor : AppConstants.greyColor,
            ),
          ),
          const SizedBox(height: 3),
          SizedBox(
            height: 26,
            child: Text(
              data.label,
              textAlign: TextAlign.center,
              style: GoogleFonts.unbounded(
                fontSize: 9.5,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
                color:
                    isActive
                        ? AppConstants.darkGreenColor
                        : AppConstants.greyColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    var selectedTab = ref.watch(navBarController).selectedTab;
    return Scaffold(
      backgroundColor: AppConstants.bgGreyColor.withOpacity(0.7),
      body: selectedTab == -1 ? OrganizerScreen() : _pagesReg[selectedTab],
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _changeTab(-1);
        },
        shape: CircleBorder(),
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppConstants.darkGreenColor,
            boxShadow: [
              BoxShadow(
                color: AppConstants.darkGreenColor.withOpacity(0.35),
                blurRadius: 12,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Center(
            child: Icon(
              selectedTab == -1
                  ? Icons.calendar_month_rounded
                  : Icons.calendar_month_outlined,
              color: AppConstants.bgColor,
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: AnimatedBottomNavigationBar.builder(
        splashSpeedInMilliseconds: 1,
        height: 62,
        hideAnimationCurve: null,
        itemCount: _pagesReg.length,
        tabBuilder: (index, isActive) => _buildTabItem(index, isActive),
        hideAnimationController: null,
        backgroundColor: const Color.fromARGB(255, 27, 29, 28),
        activeIndex: selectedTab,
        gapLocation: GapLocation.center,
        notchSmoothness: NotchSmoothness.softEdge,
        leftCornerRadius: 22,
        rightCornerRadius: 22,
        elevation: 10,
        onTap: (index) => _changeTab(index),
      ),
    );
  }
}

class _NavTabData {
  final IconData activeIcon;
  final IconData inactiveIcon;
  final String label;

  const _NavTabData({
    required this.activeIcon,
    required this.inactiveIcon,
    required this.label,
  });
}
