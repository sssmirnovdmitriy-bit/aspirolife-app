import 'package:flutter/material.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:overlay_support/overlay_support.dart';

class AppNotifications {
  static showError(BuildContext context, String message) {
    StandartSnackBar.showAndDontRemoveUntil(
      context,
      message,
      SnackBarStatus.warning(),
      const Duration(seconds: 10),
    );
  }

  static showSuccess(BuildContext context, String message) {
    StandartSnackBar.showAndDontRemoveUntil(
      context,
      message,
      SnackBarStatus.success(),
      const Duration(seconds: 4),
    );
  }

  static showConnectionError(BuildContext context) {
    StandartSnackBar.showAndDontRemoveUntil(
      context,
      'Потеряно интернет соединение',
      SnackBarStatus.warning(),
      const Duration(seconds: 4),
    );
  }

  static showConnectionSuccess(BuildContext context) {
    StandartSnackBar.showAndDontRemoveUntil(
      context,
      'Соединение восстановлено',
      SnackBarStatus.success(),
      Duration(seconds: 5),
    );
  }
}

class StandartSnackBar {
  static void show(BuildContext context, String text, SnackBarStatus status) {
    showOverlayNotification((context) {
      return SafeArea(
        child: GestureDetector(
          onHorizontalDragEnd: (DragEndDetails drag) {
            if (drag.primaryVelocity == null) return;
            if (drag.primaryVelocity! < 0) {
              OverlaySupportEntry.of(context)?.dismiss(animate: true);
            }
          },
          onVerticalDragUpdate: (details) {
            if (details.delta.direction <= 0) {
              OverlaySupportEntry.of(context)?.dismiss();
            }
          },
          onLongPress: () {},
          // onTap: () {
          //   OverlaySupportEntry.of(context)?.dismiss();
          // },
          child: Container(
            margin: const EdgeInsets.fromLTRB(15, 15, 15, 0),
            padding: const EdgeInsets.fromLTRB(15, 10, 15, 10),
            width: MediaQuery.of(context).size.width - 20,
            decoration: BoxDecoration(
              color: AppConstants.whiteColor,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(width: 1, color: Colors.grey),
              // boxShadow: shadow,
            ),
            child: Material(
              color: Colors.transparent,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(status.icon, color: status.color, size: 30),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: MediaQuery.of(context).size.width - 120,
                    child: Text(
                      text,
                      maxLines: 2,
                      style: const TextStyle(
                        color: AppConstants.bgColor,
                        fontSize: 16,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }, duration: const Duration(seconds: 1));
  }

  static void showAndDontRemoveUntil(
    BuildContext context,
    String text,
    SnackBarStatus status,
    Duration duration,
  ) {
    showOverlayNotification((context) {
      return SafeArea(
        child: GestureDetector(
          onHorizontalDragEnd: (DragEndDetails drag) {
            if (drag.primaryVelocity == null) return;
            if (drag.primaryVelocity! < 0) {
              OverlaySupportEntry.of(context)?.dismiss(animate: true);
            }
          },
          onVerticalDragUpdate: (details) {
            if (details.delta.direction <= 0) {
              OverlaySupportEntry.of(context)?.dismiss();
            }
          },
          onLongPress: () {},
          child: Container(
            padding: const EdgeInsets.fromLTRB(15, 10, 5, 10),
            width: MediaQuery.of(context).size.width - 20,
            height: 52,
            decoration: BoxDecoration(
              color: AppConstants.secondaryColor,
              borderRadius: BorderRadius.circular(10),
              // boxShadow: shadow,
            ),
            child: Material(
              color: Colors.transparent,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(status.icon, color: status.color, size: 24),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.64,
                    child: Text(
                      text,
                      maxLines: 2,
                      style: const TextStyle(
                        color: AppConstants.whiteColor,
                        fontSize: 12,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                  Spacer(),
                  IconButton(
                    iconSize: 16,
                    splashRadius: 10,
                    onPressed: () {
                      OverlaySupportEntry.of(context)?.dismiss(animate: true);
                    },
                    icon: Icon(Icons.close, color: AppConstants.whiteColor),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }, duration: duration);
  }
}

class SnackBarStatus {
  SnackBarStatus(this.icon, this.color);

  final IconData icon;
  final Color color;

  static SnackBarStatus success() {
    return SnackBarStatus(Icons.done, Colors.green);
  }

  static SnackBarStatus warning() {
    return SnackBarStatus(Icons.error, Colors.red);
  }

  static SnackBarStatus message() {
    return SnackBarStatus(Icons.sms_rounded, Colors.yellow.shade800);
  }

  static SnackBarStatus internetResultSuccess() {
    return SnackBarStatus(Icons.check_circle, Colors.white);
  }

  static SnackBarStatus loading() {
    return SnackBarStatus(Icons.info, Colors.white);
  }
}
