import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/habbit_model.dart';

enum HabitTypes { SMOKING, ALCOHOL, SOCIALS, DRUGS, GAMBLING, TIMELOSS }

enum GoodHabitTypes {
  JOGGING,
  YOGA,
  EATING,
  GYM,
  MEDITATION,
  WORKOUT,
  HARDENING,
}

List<HabbitModel> badHabbitsRu = [
  HabbitModel(
    habbitName: "Курение",
    habbitType: HabitTypes.SMOKING.name,
    habbitDescription:
        "Курение вызывает никотиновую зависимость, негативно влияет на лёгкие, сердце и сосуды.",
    imagePath: AppConstants.smokingIcon,
    animationPath: AppConstants.smokingAnim,
    isGoodHabbit: false,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Курение на самом деле не убивает, оно настолько истощает организм, что курильщику легче заразиться болезнями с летальным исходом",
    ],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText: "Пейте больше воды, так никотин выведется быстрее",
        notificationText: "",
        isCompleted: false,
      ),
    ],
  ),
  HabbitModel(
    habbitName: "Алкоголь",
    habbitType: HabitTypes.ALCOHOL.name,
    habbitDescription:
        "Алкоголь разрушает печень, мозг и нервную систему. Вызывает психологическую и физическую зависимость.",
    imagePath: AppConstants.alcoholIcon,
    animationPath: AppConstants.alcoholAnim,
    isGoodHabbit: false,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Даже умеренные дозы алкоголя увеличивают риск рака и заболеваний сердца.",
      "Алкоголь ухудшает качество сна и усиливает тревожность.",
    ],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText: "Выпейте вместо алкоголя травяной чай или воду с лимоном.",
        notificationText: "",
        isCompleted: false,
      ),
    ],
  ),

  HabbitModel(
    habbitName: "Соцсети",
    habbitType: HabitTypes.SOCIALS.name,
    habbitDescription:
        "Социальные сети вызывают зависимость, отвлекают от реальной жизни и усиливают тревожность.",
    imagePath: AppConstants.socialsIcon,
    animationPath: AppConstants.phoneAnim,
    isGoodHabbit: false,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Чем больше времени вы проводите в соцсетях, тем ниже уровень счастья и удовлетворённости жизнью.",
      "Скроллинг снижает концентрацию и ухудшает память.",
    ],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText: "Удалите хотя бы одно приложение соцсетей с телефона.",
        notificationText: "",
        isCompleted: false,
      ),
    ],
  ),
  HabbitModel(
    habbitName: "Наркотики",
    habbitType: HabitTypes.DRUGS.name,
    habbitDescription:
        "Наркотики мгновенно ломают здоровье, психику и судьбу. Это путь в никуда.",
    imagePath: AppConstants.drugsIcon,
    animationPath: AppConstants.drugsAnim,
    isGoodHabbit: false,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Даже однократный приём может вызвать привыкание и тяжёлые последствия.",
      "Наркотики разрушают не только тело, но и социальные связи, карьеру и будущее.",
    ],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText:
            "Запишите 3 причины, почему вы хотите отказаться от наркотиков.",
        notificationText: "",
        isCompleted: false,
      ),
    ],
  ),
  HabbitModel(
    habbitName: "Лудомания",
    habbitType: HabitTypes.GAMBLING.name,
    habbitDescription:
        "Азартные игры вызывают сильную зависимость и приводят к финансовому, психологическому и социальному краху.",
    imagePath: AppConstants.casinoIcon,
    animationPath: AppConstants.casinoAnim,
    isGoodHabbit: false,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Лудомания — это не игра, а болезнь, которая требует лечения.",
      "Большинство игроков никогда не выигрывают в долгосрочной перспективе.",
    ],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText:
            "Удалите или заблокируйте доступ к игровым сайтам и приложениям.",
        notificationText: "",
        isCompleted: false,
      ),
    ],
  ),
  HabbitModel(
    habbitName: "Прокрастинация",
    habbitType: HabitTypes.TIMELOSS.name,
    habbitDescription:
        "Прокрастинация крадёт время и лишает вас энергии для настоящих достижений.",
    imagePath: AppConstants.clockIcon,
    animationPath: AppConstants.calendarAnim,
    isGoodHabbit: false,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Прокрастинация связана с повышенной тревожностью и сниженной самооценкой.",
      "Каждый раз, откладывая задачу, вы усиливаете стресс и чувство вины.",
    ],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText:
            "Выделите 15 минут и начните делать задачу, которую откладывали.",
        notificationText: "",
        isCompleted: false,
      ),
    ],
  ),
];

List<HabbitModel> goodHabbitsRu = [
  HabbitModel(
    habbitName: "Бег",
    habbitType: GoodHabitTypes.JOGGING.name,
    habbitDescription:
        "Бег укрепляет сердце, помогает кровообращению и способствует уменьшению сердечно-сосудистых проблем",
    imagePath: AppConstants.joggingIcon,
    animationPath: AppConstants.joggingAnim,
    isGoodHabbit: true,
    endDate: null,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Курение на самом деле не убивает, оно настолько истощает организм, что курильщику легче заразиться болезнями с летальным исходом",
    ],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText: "Пейте больше воды, так никотин выведется быстрее",
        notificationText: "",
        isCompleted: false,
      ),
    ],
  ),
  HabbitModel(
    habbitName: "Йога",
    habbitType: GoodHabitTypes.YOGA.name,
    habbitDescription:
        "Йога улучшает гибкость, снижает уровень стресса и укрепляет мышцы.",
    imagePath: AppConstants.yogaIcon,
    animationPath: AppConstants.yogaAnim,
    isGoodHabbit: true,
    endDate: null,
    aiSuggestion: "",
    points: 100,
    facts: ["Занятия йогой помогают улучшить осанку и качество сна."],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText: "Позанимайтесь йогой 20 минут",
        notificationText: "Пора на коврик!",
        isCompleted: false,
      ),
    ],
  ),
  HabbitModel(
    habbitName: "Медитация",
    habbitType: GoodHabitTypes.MEDITATION.name,
    habbitDescription:
        "Медитация снижает уровень стресса и помогает расслабиться",
    imagePath: AppConstants.yogaIcon,
    animationPath: AppConstants.meditationAnim,
    isGoodHabbit: true,
    endDate: null,
    aiSuggestion: "",
    points: 100,
    facts: ["Занятия медитацией помогают улучшить качество жизни"],
    dailyMissions: [
      DailyMission(
        points: 4,
        missionText: "Позанимайтесь медитацией 20 минут",
        notificationText: "Пора расслабиться!",
        isCompleted: false,
      ),
    ],
  ),
  HabbitModel(
    habbitName: "Питание",
    habbitType: GoodHabitTypes.EATING.name,
    habbitDescription:
        "Сбалансированное питание улучшает самочувствие и укрепляет иммунитет.",
    imagePath: AppConstants.eatingIcon,
    animationPath: AppConstants.foodAnim,
    isGoodHabbit: true,
    endDate: null,
    aiSuggestion: "",
    points: 100,
    facts: [
      "Употребление овощей ежедневно снижает риск хронических заболеваний.",
    ],
    dailyMissions: [],
  ),
  HabbitModel(
    habbitName: "Спортзал",
    habbitType: GoodHabitTypes.GYM.name,
    habbitDescription:
        "Тренировки помогают набирать мышечную массу и сжигать лишние калории.",
    imagePath: AppConstants.gymIcon,
    animationPath: AppConstants.gymAnim,
    isGoodHabbit: true,
    endDate: null,
    aiSuggestion: "",
    points: 100,
    facts: ["Регулярные силовые тренировки замедляют старение мышечной ткани."],
    dailyMissions: [],
  ),
  HabbitModel(
    habbitName: "Воркаут",
    habbitType: GoodHabitTypes.WORKOUT.name,
    habbitDescription:
        "Тренировки помогают держать тонус и сжигать лишние калории.",
    imagePath: AppConstants.gymIcon,
    animationPath: AppConstants.gymAnim,
    isGoodHabbit: true,
    endDate: null,
    aiSuggestion: "",
    points: 100,
    facts: ["Регулярные силовые тренировки замедляют старение мышечной ткани."],
    dailyMissions: [],
  ),
  HabbitModel(
    habbitName: "Закаливание",
    habbitType: GoodHabitTypes.HARDENING.name,
    habbitDescription: "Закаливание - это основа для баланса организма",
    imagePath: AppConstants.gymIcon,
    animationPath: AppConstants.gymAnim,
    isGoodHabbit: true,
    endDate: null,
    aiSuggestion: "",
    points: 100,
    facts: ["Регулярные силовые тренировки замедляют старение мышечной ткани."],
    dailyMissions: [],
  ),
];
