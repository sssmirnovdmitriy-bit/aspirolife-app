import 'package:organizer/feature/finances_screen/data/models/portfolio_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class PortfolioDatabase {
  static final PortfolioDatabase _instance = PortfolioDatabase._internal();
  factory PortfolioDatabase() => _instance;

  PortfolioDatabase._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    final path = join(await getDatabasesPath(), 'portfolio.db');
    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute(_createTableSql);
      },
    );
    return _database!;
  }

  static const String _createTableSql = '''
    CREATE TABLE portfolio (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tickerName TEXT NOT NULL,
      stocksCount INTEGER,
      averagePrice REAL,
      totalPrice REAL NOT NULL,
      price REAL NOT NULL,
      percent REAL NOT NULL,
      createdDate TEXT NOT NULL
    );
  ''';

  // === CRUD методы ===

  Future<void> upsertOrMergePortfolio(PortfolioModel newEntry) async {
    final db = await database;

    // Найти запись по tickerName
    final existingList = await db.query(
      'portfolio',
      where: 'tickerName = ?',
      whereArgs: [newEntry.tickerName],
    );

    if (existingList.isEmpty) {
      // Не найдено — вставить
      await insertPortfolio(newEntry);
    } else {
      // Найдена — объединить
      final existing = PortfolioModel.fromJson(existingList.first);

      final int totalCount =
          (existing.stocksCount ?? 0) + (newEntry.stocksCount ?? 0);
      final double combinedTotalPrice =
          existing.totalPrice + newEntry.totalPrice;

      final double newAveragePrice =
          totalCount > 0
              ? combinedTotalPrice / totalCount
              : newEntry.averagePrice ?? 0;

      final updated = PortfolioModel(
        id: existing.id,
        tickerName: existing.tickerName,
        stocksCount: totalCount,
        averagePrice: newAveragePrice,
        totalPrice: combinedTotalPrice,
        price: newEntry.price, // обновляем текущую цену
        percent: newEntry.percent, // обновляем % изменения
        createdDate: DateTime.now(), // обновляем дату
      );

      await updatePortfolio(updated);
    }
  }

  Future<int> insertPortfolio(PortfolioModel model) async {
    final db = await database;
    return await db.insert('portfolio', model.toJson());
  }

  Future<List<PortfolioModel>> getAllPortfolios() async {
    final db = await database;
    final result = await db.query('portfolio', orderBy: 'createdDate DESC');
    return result.map((e) => PortfolioModel.fromJson(e)).toList();
  }

  Future<int> deletePortfolio(int id) async {
    final db = await database;
    return await db.delete('portfolio', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> updatePortfolio(PortfolioModel model) async {
    final db = await database;
    return await db.update(
      'portfolio',
      model.toJson(),
      where: 'id = ?',
      whereArgs: [model.id],
    );
  }
}
