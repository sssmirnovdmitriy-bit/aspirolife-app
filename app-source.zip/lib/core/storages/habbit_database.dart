import 'package:organizer/core/models/habbit_model.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:convert';

class HabbitDatabaseService {
  static const String _tableName = 'habits';

  Future<Database> get database async {
    return openDatabase(
      'habbit_database.db',
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
        CREATE TABLE habits (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          habbitName TEXT,
          habbitType TEXT,
          habbitDescription TEXT,
          startDate TEXT,
          endDate TEXT,
          isGoodHabbit INTEGER,
          aiSuggestion TEXT,
          points INTEGER,
          imagePath TEXT,
          animationPath TEXT,
          facts TEXT,
          additionalInfo TEXT,
          streak INTEGER,
          oneValuePrice INTEGER,
          habbitUseCount INTEGER
        )
      ''');

        await db.execute('''
        CREATE TABLE daily_missions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          habbitId INTEGER,
          startDate TEXT,
          endDate TEXT,
          missionText TEXT,
          notificationText TEXT,
          isCompleted INTEGER,
          points INTEGER,
          videoUrl TEXT,
          textInfo TEXT,
          FOREIGN KEY (habbitId) REFERENCES habits (id) ON DELETE CASCADE
        )
      ''');
      },
    );
  }

  Future<void> saveHabbit(HabbitModel habbit) async {
    final db = await database;

    // Сохраняем привычку
    int habbitId = await db.insert('habits', {
      'habbitName': habbit.habbitName,
      'habbitType': habbit.habbitType,
      'habbitDescription': habbit.habbitDescription,
      'startDate': habbit.startDate?.toIso8601String(),
      'endDate': habbit.endDate?.toIso8601String(),
      'isGoodHabbit': habbit.isGoodHabbit ? 1 : 0,
      'aiSuggestion': habbit.aiSuggestion,
      'points': habbit.points,
      'imagePath': habbit.imagePath,
      'animationPath': habbit.animationPath,
      'facts': jsonEncode(habbit.facts),
      'additionalInfo': jsonEncode(habbit.additionalInfo ?? {}),
      'streak': habbit.streak,
      'oneValuePrice': habbit.oneValuePrice,
      'habbitUseCount': habbit.habbitUseCount,
    }, conflictAlgorithm: ConflictAlgorithm.replace);

    // Сохраняем миссии
    for (final mission in habbit.dailyMissions) {
      await db.insert('daily_missions', {
        'habbitId': habbitId,
        'startDate': mission.startDate?.toIso8601String(),
        'endDate': mission.endDate?.toIso8601String(),
        'missionText': mission.missionText,
        'notificationText': mission.notificationText,
        'isCompleted': mission.isCompleted ? 1 : 0,
        'points': mission.points,
        'videoUrl': mission.videoUrl,
        'textInfo': mission.textInfo,
      });
    }
  }

  Future<List<HabbitModel>> getAllHabbits() async {
    final db = await database;

    final List<Map<String, dynamic>> habits = await db.query('habits');

    List<HabbitModel> result = [];

    for (var map in habits) {
      int id = map['id'];

      final List<Map<String, dynamic>> missionMaps = await db.query(
        'daily_missions',
        where: 'habbitId = ?',
        whereArgs: [id],
      );

      final dailyMissions =
          missionMaps
              .map(
                (m) => DailyMission(
                  id: m['id'],
                  startDate:
                      m['startDate'] != null
                          ? DateTime.parse(m['startDate'])
                          : null,
                  endDate:
                      m['endDate'] != null
                          ? DateTime.parse(m['endDate'])
                          : null,
                  missionText: m['missionText'],
                  notificationText: m['notificationText'],
                  isCompleted: m['isCompleted'] == 1,
                  points: m['points'],
                  videoUrl: m['videoUrl'],
                  textInfo: m['textInfo'],
                ),
              )
              .toList();

      result.add(
        HabbitModel(
          id: map['id'],
          habbitName: map['habbitName'],
          habbitType: map['habbitType'],
          habbitDescription: map['habbitDescription'],
          startDate:
              map['startDate'] != null
                  ? DateTime.parse(map['startDate'])
                  : null,
          endDate:
              map['endDate'] != null ? DateTime.parse(map['endDate']) : null,
          isGoodHabbit: map['isGoodHabbit'] == 1,
          aiSuggestion: map['aiSuggestion'],
          points: map['points'],
          imagePath: map['imagePath'],
          animationPath: map['animationPath'],
          facts: List<String>.from(jsonDecode(map['facts'])),
          dailyMissions: dailyMissions,
          additionalInfo: jsonDecode(map['additionalInfo'] ?? '{}'),
          streak: map['streak'],
          oneValuePrice: map['oneValuePrice'],
          habbitUseCount: map['habbitUseCount'],
        ),
      );
    }

    return result;
  }

  Future<void> deleteHabbitById(int id) async {
    final db = await database;
    await db.delete('habits', where: 'id = ?', whereArgs: [id]);
    // благодаря ON DELETE CASCADE, миссии удалятся автоматически
  }

  Future<void> updateHabbitStreakInDB(HabbitModel habbitModel) async {
    final db = await database;
    await db.update(
      'habits',
      {'streak': habbitModel.streak},
      where: 'id = ?',
      whereArgs: [habbitModel.id],
    );
  }

  Future<void> completeMission(DailyMission mission) async {
    // Обновляем миссию как выполненную
    mission.isCompleted = true;
    // Сохраняем изменения в базе данных (если нужно)
    final db = await database;
    await db.update(
      'daily_missions',
      {'isCompleted': true},
      where: 'id = ?',
      whereArgs: [mission.id],
    );
  }

  Future<void> uncompleteMission(DailyMission mission) async {
    mission.isCompleted = false;

    final db = await database;
    await db.update(
      'daily_missions',
      {'isCompleted': 0}, // снимаем выполнение
      where: 'id = ?',
      whereArgs: [mission.id],
    );
  }

  Future<DailyMission?> getDailyMissionByDate({
    required int habbitId,
    required DateTime targetDate,
  }) async {
    final db = await database;

    // Форматируем дату как строку yyyy-MM-dd для точного совпадения
    final dateStr = targetDate.toIso8601String().split('T').first;

    final result = await db.query(
      'daily_missions',
      where: 'habbitId = ? AND date(startDate) = ?',
      whereArgs: [habbitId, dateStr],
      limit: 1,
    );

    if (result.isNotEmpty) {
      return DailyMission.fromJson(result.first);
    } else {
      return null;
    }
  }
}
