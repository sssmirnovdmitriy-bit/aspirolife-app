import 'package:organizer/core/models/note_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class NoteDatabase {
  static final NoteDatabase instance = NoteDatabase._init();
  static Database? _database;

  NoteDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('notes.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
    CREATE TABLE notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      text TEXT NOT NULL,
      editDate TEXT NOT NULL
    )
    ''');
  }

  /// Добавление заметки
  Future<int> create(NoteModel note) async {
    final db = await instance.database;
    return await db.insert('notes', note.toJson());
  }

  /// Получение заметки по id
  Future<NoteModel?> readNote(int id) async {
    final db = await instance.database;

    final maps = await db.query(
      'notes',
      columns: ['id', 'text', 'editDate'],
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return NoteModel.fromJson(maps.first);
    } else {
      return null;
    }
  }

  /// Получение всех заметок
  Future<List<NoteModel>> readAllNotes() async {
    final db = await instance.database;

    final result = await db.query('notes', orderBy: 'editDate DESC');

    return result.map((json) => NoteModel.fromJson(json)).toList();
  }

  /// Обновление заметки
  Future<int> update(NoteModel note) async {
    final db = await instance.database;

    return db.update(
      'notes',
      note.toJson(),
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  /// Удаление заметки
  Future<int> delete(int id) async {
    final db = await instance.database;

    return await db.delete('notes', where: 'id = ?', whereArgs: [id]);
  }

  /// Закрытие базы
  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
