import 'package:organizer/core/models/hobby_model.dart';
import 'package:organizer/core/storages/mock_hobbies.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HobbyDatabase {
  static final HobbyDatabase _instance = HobbyDatabase._internal();
  factory HobbyDatabase() => _instance;

  HobbyDatabase._internal();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDatabase();
    return _db!;
  }

  Future<Database> _initDatabase() async {
    final path = join(await getDatabasesPath(), 'hobbies.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE hobbies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hobbyName TEXT NOT NULL,
            isCompleted INTEGER NOT NULL
          )
        ''');
      },
      onOpen: (db) async {
        await _seedMockHobbies(db);
      },
    );
  }

  Future<void> _seedMockHobbies(Database db) async {
    final prefs = await SharedPreferences.getInstance();
    final isSeeded = prefs.getBool('hobbiesSeeded') ?? false;
    if (isSeeded) return;

    for (final hobby in mockHobbies) {
      await db.insert('hobbies', hobby.toMap());
    }
    await prefs.setBool('hobbiesSeeded', true);
  }

  Future<List<HobbyModel>> getAllHobbies() async {
    final db = await database;
    final maps = await db.query('hobbies');
    return maps.map((e) => HobbyModel.fromMap(e)).toList();
  }

  Future<void> insertHobby(HobbyModel hobby) async {
    final db = await database;
    await db.insert('hobbies', hobby.toMap());
  }

  Future<void> updateHobby(HobbyModel hobby) async {
    final db = await database;
    await db.update(
      'hobbies',
      hobby.toMap(),
      where: 'id = ?',
      whereArgs: [hobby.id],
    );
  }

  Future<void> deleteHobby(int id) async {
    final db = await database;
    await db.delete('hobbies', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAllHobbies() async {
    final db = await database;
    await db.delete('hobbies');
  }
}
