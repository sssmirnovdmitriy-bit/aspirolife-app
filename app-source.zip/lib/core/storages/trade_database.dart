import 'dart:io';
import 'package:organizer/core/models/trade_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class TradeDatabase {
  static final TradeDatabase _instance = TradeDatabase._internal();
  factory TradeDatabase() => _instance;
  TradeDatabase._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('trade.db');
    return _database!;
  }

  Future<Database> _initDB(String fileName) async {
    Directory dir = await getApplicationDocumentsDirectory();
    String path = join(dir.path, fileName);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tickerName TEXT NOT NULL,
        isBuy INTEGER NOT NULL,
        price1 REAL NOT NULL,
        price2 REAL NOT NULL,
        commision REAL NOT NULL,
        result REAL
      )
    ''');
  }

  Future<int> insertTrade(TradeModel trade) async {
    final db = await database;
    return await db.insert('trades', trade.toJson());
  }

  Future<List<TradeModel>> getAllTrades() async {
    final db = await database;
    final result = await db.query('trades');
    return result.map((json) => TradeModel.fromJson(json)).toList();
  }

  Future<int> updateTrade(int id, TradeModel trade) async {
    final db = await database;
    return await db.update(
      'trades',
      trade.toJson(),
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteTrade(int id) async {
    final db = await database;
    return await db.delete('trades', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAll() async {
    final db = await database;
    await db.delete('trades');
  }
}
