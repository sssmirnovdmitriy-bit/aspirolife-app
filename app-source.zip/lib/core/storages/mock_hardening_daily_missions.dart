import 'package:organizer/core/models/habbit_model.dart';

/// FAST (активные, жёсткие) миссии для закаливания
List<DailyMission> hardeningDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Прими холодный душ 1 минуту.',
    notificationText: 'Воля тренируется под холодной водой!',
    isCompleted: false,
    points: 10,
    videoUrl: "https://rutube.ru/video/61060d23ee5e19f8f094935df6c04f74/?r=a/",
  ),
  DailyMission(
    missionText: 'Облейся холодной водой с головой.',
    notificationText: 'Мощный заряд бодрости!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сделай 3 цикла контрастного душа (холод/горячо).',
    notificationText: 'Закали сосуды — укрепи здоровье.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Погрузись в таз или ванну с холодной водой на 30 секунд.',
    notificationText: 'Холод — твой союзник.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Окунись в реку или озеро, если есть возможность.',
    notificationText: 'Проверка духа и тела!',
    isCompleted: false,
    points: 20,
  ),
  DailyMission(
    missionText: 'Прими ледяной душ сразу после тренировки.',
    notificationText: 'Холод ускоряет восстановление.',
    isCompleted: false,
    points: 15,
  ),
  DailyMission(
    missionText: 'Сделай 2 минуты холодного душа без перерывов.',
    notificationText: 'Сила духа растёт в дискомфорте.',
    isCompleted: false,
    points: 15,
  ),
  DailyMission(
    missionText: 'Сходи в баню и выйди на улицу охлаждаться.',
    notificationText: 'Огненно-холодная комбинация!',
    isCompleted: false,
    points: 15,
  ),
  DailyMission(
    missionText: 'Зимой постой на улице без куртки 2 минуты.',
    notificationText: 'Воздушная закалка повышает выносливость.',
    isCompleted: false,
    points: 20,
  ),
  DailyMission(
    missionText: 'Прими душ лёжа под холодной водой 2 минуты.',
    notificationText: 'Максимальное погружение.',
    isCompleted: false,
    points: 20,
  ),
  DailyMission(
    missionText:
        'Сделай дыхательное упражнение Вима Хофа перед холодным душем.',
    notificationText: 'Дыхание усилит эффект холода.',
    isCompleted: false,
    points: 20,
  ),
  DailyMission(
    missionText: 'Пройди босиком по снегу или льду 1 минуту.',
    notificationText: 'Экстремальный вариант для смелых.',
    isCompleted: false,
    points: 25,
  ),
  DailyMission(
    missionText: 'Сделай серию 5 подходов: 20 сек холод/20 сек горячая вода.',
    notificationText: 'Закалка сосудов на максимум!',
    isCompleted: false,
    points: 20,
  ),
  DailyMission(
    missionText: 'Спроси у друга — кто дольше выдержит холодный душ.',
    notificationText: 'Закалка + челлендж = мотивация.',
    isCompleted: false,
    points: 15,
  ),
  DailyMission(
    missionText: 'Окунись в прорубь (если доступно).',
    notificationText: 'Классическая проверка силы духа.',
    isCompleted: false,
    points: 30,
  ),
];

/// SLOW (лёгкие, мягкие) миссии для закаливания
List<DailyMission> hardeningDailyMissionsSlowRu = [
  DailyMission(
    missionText: 'Заверши умывание холодной водой.',
    notificationText: 'Начни мягко — освежись.',
    isCompleted: false,
    points: 5,
    videoUrl: "https://rutube.ru/video/61060d23ee5e19f8f094935df6c04f74/?r=a/",
  ),
  DailyMission(
    missionText: 'Заканчивай душ прохладной водой 20–30 секунд.',
    notificationText: 'Маленький шаг к большой закалке.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Пройдись босиком по полу или траве 2 минуты.',
    notificationText: 'Закаляй стопы — активируй энергию тела.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сделай лёгкий контраст: горячая вода, затем прохладная.',
    notificationText: 'Мягкая тренировка сосудов.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'После душа постой у открытого окна 1 минуту.',
    notificationText: 'Холодный воздух — естественный закал.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Опусти руки в холодную воду на 30 секунд.',
    notificationText: 'Простая адаптация к холоду.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Заканчивай мытьё ног прохладной водой.',
    notificationText: 'Мягкое привыкание к холоду.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Умой лицо холодной водой 3 раза подряд.',
    notificationText: 'Бодрость на весь день.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сделай дыхательное упражнение: вдох — холодный воздух.',
    notificationText: 'Закалка через дыхание.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Погуляй босиком по балкону/улице 2–3 минуты.',
    notificationText: 'Закалка через стопы.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Снизь температуру душа на 1 деление.',
    notificationText: 'Маленький шаг — большой результат.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Вместо горячего чая выпей прохладную воду.',
    notificationText: 'Закалка и изнутри.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Подержи стопы в прохладной воде 1 минуту.',
    notificationText: 'Мягкая подготовка организма.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сделай 10 глубоких вдохов на прохладном воздухе.',
    notificationText: 'Свежесть и спокойствие.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Выйди на улицу без куртки на 1 минуту (осенью/весной).',
    notificationText: 'Привыкай к перепадам температур.',
    isCompleted: false,
    points: 10,
  ),
];
