import 'package:organizer/core/models/habbit_model.dart';

List<DailyMission> alcoholDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Сегодня ни капли алкоголя. Начни с решимости.',
    notificationText: 'Ты сделал выбор — держись!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Избавься от всего алкоголя дома. Убери искушение.',
    notificationText: 'Избавься от соблазнов прямо сейчас!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сообщи близким, что ты бросаешь пить. Поддержка важна.',
    notificationText: 'Твое окружение — твоя опора.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Когда захочешь выпить — выпей воду или сок.',
    notificationText: 'Замени вредное полезным!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Записывай, когда появляется желание выпить и что его вызвало.',
    notificationText: 'Осознанность — первый шаг к свободе.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Займись физической активностью: спорт, танцы или прогулка.',
    notificationText: 'Двигайся к новой жизни!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'В момент желания выпить — сделай дыхательную практику.',
    notificationText: 'Спокойствие — твоя сила.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Посмотри видео о вреде алкоголя. Убедись в правильности выбора.',
    notificationText: 'Знание — мотивация.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Займи руки: собери пазл, рисуй, лопай пупырку.',
    notificationText: 'Чем заняты руки — тем свободнее разум.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Подумай, на что потратишь деньги, сэкономленные на алкоголе.',
    notificationText: 'Новая цель — новый стимул!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Составь список причин, почему ты отказываешься от алкоголя.',
    notificationText: 'Всегда помни, зачем ты это делаешь.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Избегай вечеринок, где будет алкоголь.',
    notificationText: 'Среда важна. Береги себя.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Поощри себя чем-то приятным и полезным вместо алкоголя.',
    notificationText: 'Ты достоин награды!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Веди календарь трезвости. Радуйся каждому дню.',
    notificationText: 'Ты на пути к лучшей версии себя.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Поговори с кем-то, кто уже отказался от алкоголя.',
    notificationText: 'Опыт — источник вдохновения.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сними видео, где расскажешь, зачем бросаешь пить.',
    notificationText: 'Твоя история — твоя мотивация.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Питайся правильно и пей много воды.',
    notificationText: 'Забота о теле = забота о себе.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Представь, как улучшается твоё здоровье без алкоголя.',
    notificationText: 'Ты уже стал лучше, чем вчера.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Повторяй: “Я свободен от зависимости.”',
    notificationText: 'Слова программируют реальность.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Отметь день победы. Ты сделал мощный шаг!',
    notificationText: 'Горжусь тобой. Ты сильнее, чем думаешь!',
    isCompleted: false,
    points: 20,
  ),
];

List<DailyMission> alcoholDailyMissionsSlowRu = [
  DailyMission(
    missionText: 'Сегодня максимум 4 порции алкоголя.',
    notificationText: 'Контроль — начало пути.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сократи до 3 порций алкоголя за день.',
    notificationText: 'Уже меньше. Так держать!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Не более 2 порций сегодня. Замени третью — водой.',
    notificationText: 'Ты всё ближе к свободе.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '1 порция — максимум. Остальное — сила воли.',
    notificationText: 'Твоя сила — в отказе.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Ни капли алкоголя сегодня. Первый чистый день!',
    notificationText: 'Ты свободен от токсинов!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Оставайся трезвым второй день подряд.',
    notificationText: 'Ты уже на верном пути.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Запиши, что тебе помогает держаться.',
    notificationText: 'Оставь подсказки для будущего себя.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сделай что-то приятное без алкоголя: кино, прогулка, спорт.',
    notificationText: 'Ты можешь отдыхать без бутылки.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Раздели свои успехи с близкими.',
    notificationText: 'Поддержка укрепляет результат.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Вспомни, как ты чувствовал себя после алкоголя. Запиши.',
    notificationText: 'Сравни с тем, как ты чувствуешь себя сейчас.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сегодня снова ноль. Ты уже почти победил.',
    notificationText: 'Ты стал сильнее, чем ты думал.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Последний день испытания. Подарок себе — трезвость.',
    notificationText: 'Ты прошёл путь. Горжусь тобой!',
    isCompleted: false,
    points: 20,
  ),
];
