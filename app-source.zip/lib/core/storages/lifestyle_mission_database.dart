import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class LifestyleMission {
  final int? id;
  final String text;
  final String date; // можно хранить в ISO-строке (yyyy-MM-dd)

  LifestyleMission({this.id, required this.text, required this.date});

  Map<String, dynamic> toMap() {
    return {'id': id, 'text': text, 'date': date};
  }

  factory LifestyleMission.fromMap(Map<String, dynamic> map) {
    return LifestyleMission(
      id: map['id'],
      text: map['text'],
      date: map['date'],
    );
  }
}

class LifestyleMissionDatabase {
  static final LifestyleMissionDatabase instance =
      LifestyleMissionDatabase._init();
  static Database? _database;

  LifestyleMissionDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('lifestyle_mission.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE mission (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT NOT NULL,
        date TEXT NOT NULL
      )
    ''');
  }

  /// Сохранить миссию (заменяет старую)
  Future<void> saveMission(LifestyleMission mission) async {
    final db = await instance.database;

    // очищаем таблицу
    await db.delete('mission');

    // вставляем новую
    await db.insert('mission', mission.toMap());
  }

  /// Получить текущую миссию (если есть)
  Future<LifestyleMission?> getMission() async {
    final db = await instance.database;
    final result = await db.query('mission', limit: 1);
    if (result.isNotEmpty) {
      return LifestyleMission.fromMap(result.first);
    }
    return null;
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
