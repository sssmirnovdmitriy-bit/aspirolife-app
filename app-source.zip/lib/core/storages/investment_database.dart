import 'package:organizer/core/models/investment_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class InvestmentDatabase {
  static final InvestmentDatabase _instance = InvestmentDatabase._internal();
  factory InvestmentDatabase() => _instance;
  InvestmentDatabase._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('investments.db');
    return _database!;
  }

  Future<Database> _initDB(String fileName) async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, fileName);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE investments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT NOT NULL,
        value REAL NOT NULL,
        type TEXT NOT NULL
      )
    ''');
  }

  Future<int> insertInvestment(InvestmentModel investment) async {
    final db = await database;
    return await db.insert('investments', investment.toMap());
  }

  Future<List<InvestmentModel>> getAllInvestments() async {
    final db = await database;
    final result = await db.query('investments');
    return result.map((map) => InvestmentModel.fromMap(map)).toList();
  }

  Future<int> updateInvestment(InvestmentModel investment) async {
    final db = await database;
    return await db.update(
      'investments',
      investment.toMap(),
      where: 'id = ?',
      whereArgs: [investment.id],
    );
  }

  Future<int> deleteInvestment(int id) async {
    final db = await database;
    return await db.delete('investments', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAll() async {
    final db = await database;
    await db.delete('investments');
  }
}
