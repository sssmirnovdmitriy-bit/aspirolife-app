import 'package:organizer/core/models/habbit_model.dart';

List<DailyMission> joggingDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Надень удобную одежду и сделай быструю пробежку 5 минут.',
    notificationText: 'Начало положено — ты в движении!',
    isCompleted: false,
    points: 10,
    textInfo:
        'Подготовка к бегу. \nКомфортная одежда и обувь — залог регулярных тренировок.',
  ),
  DailyMission(
    missionText: 'Разомнись перед пробежкой: суставная гимнастика 5 минут.',
    notificationText: 'Разминка — залог безопасного бега.',
    isCompleted: false,
    points: 10,
    textInfo: '\nРазминка снижает риск травм и подготавливает тело.',
  ),
  DailyMission(
    missionText: 'Выбери маршрут и пробеги 1 км в удобном темпе.',
    notificationText: 'Дистанция преодолена — ты справился!',
    isCompleted: false,
    points: 10,
    textInfo:
        '\nПрограмма первых недель. Беги в разговорном темпе, не гонись за скоростью.',
  ),
  DailyMission(
    missionText: 'После бега сделай растяжку ног и спины.',
    notificationText: 'Восстановление — часть успеха.',
    isCompleted: false,
    points: 10,
    textInfo:
        '\nПодготовка к бегу. Растяжка помогает мышцам восстановиться и снижает крепатуру.',
  ),
  DailyMission(
    missionText: 'Веди дневник пробежек: дата, дистанция, самочувствие.',
    notificationText: 'Отслеживание прогресса мотивирует.',
    isCompleted: false,
    points: 10,
    textInfo:
        '\nТрекинг и поддержка. Ведение дневника помогает увидеть свой рост.',
  ),
  DailyMission(
    missionText: 'Попробуй бегать под музыку или подкаст.',
    notificationText: 'Ритм и вдохновение — твои спутники.',
    isCompleted: false,
    points: 10,
    textInfo:
        '\nЛайфхаки. \n- Музыка помогает держать темп и получать удовольствие.',
  ),
  DailyMission(
    missionText: 'Найди красивое место для пробежки — парк, набережную.',
    notificationText: 'Бег на природе заряжает энергией.',
    isCompleted: false,
    points: 10,
    textInfo: '\n- Приятный маршрут повышает мотивацию выйти на пробежку.',
  ),
  DailyMission(
    missionText: 'Прочитай статью о пользе бега для здоровья.',
    notificationText: 'Чем больше знаешь — тем выше мотивация.',
    isCompleted: false,
    points: 10,
    textInfo:
        '\nБег улучшает работу сердца, снижает стресс и даёт гормональную перезагрузку.',
  ),
  DailyMission(
    missionText: 'Поставь цель: 3 пробежки за неделю.',
    notificationText: 'Цель делает путь осознанным.',
    isCompleted: false,
    points: 10,
    textInfo:
        '\nМягкий старт с конкретной целью формирует устойчивую привычку.',
  ),
  DailyMission(
    missionText: 'Поблагодари себя за усилия и сделай себе маленький подарок.',
    notificationText: 'Каждая пробежка — шаг к лучшей версии тебя.',
    isCompleted: false,
    points: 10,
    textInfo: '\nПозитивное подкрепление усиливает мотивацию.',
  ),
  DailyMission(
    missionText: 'Пригласи друга или члена семьи на совместную пробежку.',
    notificationText: 'Вместе — веселее и проще.',
    isCompleted: false,
    points: 10,
    textInfo: '\nСоциальная вовлеченность помогает удерживаться в привычке.',
  ),
  DailyMission(
    missionText: 'Представь, каким ты будешь через месяц регулярных пробежек.',
    notificationText: 'Визуализация помогает держать курс.',
    isCompleted: false,
    points: 10,
    textInfo: '\nПредставление результата помогает пережить сложные дни.',
  ),
  DailyMission(
    missionText: 'Сделай дыхательную практику перед пробежкой.',
    notificationText: 'Спокойное дыхание — ровный ритм бега.',
    isCompleted: false,
    points: 10,
    textInfo: '\nДыхание и пульс. Правильное дыхание снижает утомляемость.',
  ),
  DailyMission(
    missionText: 'Начни отмечать дни с бегом в календаре.',
    notificationText: 'Каждая отметка — повод для гордости.',
    isCompleted: false,
    points: 10,
    textInfo: '\nВидимый прогресс укрепляет привычку.',
  ),
  DailyMission(
    missionText: 'Напиши, почему ты решил начать бегать.',
    notificationText: 'Вспоминай свою мотивацию в трудные дни.',
    isCompleted: false,
    points: 10,
    textInfo: '\nОсознанность помогает сохранять фокус на цели.',
  ),
  DailyMission(
    missionText: 'Посмотри видео о технике бега для начинающих.',
    notificationText: 'Правильная техника — меньше травм, больше пользы.',
    isCompleted: false,
    points: 10,
    textInfo: '\nТехника снижает нагрузку на суставы и повышает эффективность.',
  ),
  DailyMission(
    missionText: 'Вспомни, как ты чувствовал себя после первой пробежки.',
    notificationText: 'Энергия и гордость — вот что даёт бег.',
    isCompleted: false,
    points: 10,
    textInfo: '\nЭмоциональные воспоминания усиливают закрепление привычки.',
  ),
  DailyMission(
    missionText: 'Составь план пробежек на следующую неделю.',
    notificationText: 'План помогает не отклоняться от цели.',
    isCompleted: false,
    points: 10,
    textInfo: '\nПланирование тренировок. План — ключ к регулярности.',
  ),
  DailyMission(
    missionText: 'Повторяй: “Я в форме. Я сильный. Я бегаю с радостью.”',
    notificationText: 'Аффирмации создают нужный настрой.',
    isCompleted: false,
    points: 10,
    textInfo: '\nЛайфхак. Аффирмации повышают самооценку и уверенность.',
  ),
  DailyMission(
    missionText: 'Отметь день бега. Ты не пропустил — ты молодец!',
    notificationText: 'Ещё один шаг к здоровью сделан.',
    isCompleted: false,
    points: 20,
    textInfo: '\nНаграды усиливают положительное подкрепление.',
  ),
];

List<DailyMission> joggingDailyMissionsSlowRu = [
  DailyMission(
    missionText: 'Прогуляйся быстрым шагом 5 минут на свежем воздухе.',
    notificationText: 'Первый шаг сделан — ты молодец!',
    isCompleted: false,
    points: 5,
    textInfo:
        'Программа первых недель. Начинай с прогулок — это мягкий вход в активность.',
  ),
  DailyMission(
    missionText: 'Найди удобную обувь для ходьбы или бега.',
    notificationText: 'Комфорт — важная часть движения.',
    isCompleted: false,
    points: 5,
    textInfo: '\nПодготовка к бегу. Удобная обувь снижает усталость и травмы.',
  ),
  DailyMission(
    missionText: 'Почитай статью о пользе бега и ходьбы.',
    notificationText: 'Теория укрепляет мотивацию.',
    isCompleted: false,
    points: 5,
    textInfo: '\nДаже малая активность улучшает здоровье и настроение.',
  ),
  DailyMission(
    missionText:
        'Сделай мягкую разминку: круги плечами, шеей, вращения стопами.',
    notificationText: 'Подготовка тела важна перед нагрузкой.',
    isCompleted: false,
    points: 5,
    textInfo: '\nДаже лёгкая разминка улучшает подвижность.',
  ),
  DailyMission(
    missionText: 'Прогуляйся 10 минут, чередуя медленный и быстрый шаг.',
    notificationText: 'Прогулка с переменным ритмом — это уже тренировка.',
    isCompleted: false,
    points: 5,
    textInfo:
        '\nМягкий старт. Интервалы активируют сердечно-сосудистую систему.',
  ),
  DailyMission(
    missionText: 'Запиши своё настроение до и после прогулки.',
    notificationText: 'Следить за эффектом — это вдохновляет.',
    isCompleted: false,
    points: 5,
    textInfo: '\nЭмоциональное отслеживание укрепляет мотивацию.',
  ),
  DailyMission(
    missionText: 'Выбери приятный маршрут — пусть прогулка станет ритуалом.',
    notificationText: 'Твое пространство — твоя зона силы.',
    isCompleted: false,
    points: 5,
    textInfo: '\nЛайфхаки: \n- Эстетика повышает шансы на повторение действия.',
  ),
  DailyMission(
    missionText: 'Сделай вдох-выдох по схеме: 4 секунды вдох, 4 — выдох.',
    notificationText: 'Осознанное дыхание помогает телу и уму.',
    isCompleted: false,
    points: 5,
    textInfo: '\n- Управление дыханием успокаивает и стабилизирует пульс.',
  ),
  DailyMission(
    missionText: 'Подумай, зачем тебе эта привычка. Пропиши 3 причины.',
    notificationText: 'Твоя цель — твоя энергия.',
    isCompleted: false,
    points: 5,
    textInfo: '\n- Четкое “зачем” придаёт устойчивости действиям.',
  ),
  DailyMission(
    missionText: 'Пройди 1 остановку пешком вместо транспорта.',
    notificationText: 'Ты уже активнее, чем был вчера.',
    isCompleted: false,
    points: 5,
    textInfo:
        '\nВстроенная активность. Маленькие шаги складываются в привычку.',
  ),
  DailyMission(
    missionText: 'Добавь в календарь “движение” 2 раза на этой неделе.',
    notificationText: 'Планирование — половина успеха.',
    isCompleted: false,
    points: 5,
    textInfo: '\nКалендарь помогает удерживать фокус.',
  ),
  DailyMission(
    missionText: 'Наблюдай за ощущениями тела во время прогулки.',
    notificationText: 'Осознанность делает каждое движение ценным.',
    isCompleted: false,
    points: 5,
    textInfo: '\nОсознанность укрепляет связь “тело–ум”.',
  ),
  DailyMission(
    missionText: 'Поздоровайся с прохожими во время прогулки.',
    notificationText: 'Быть на связи с миром — приятно.',
    isCompleted: false,
    points: 5,
    textInfo: '\nСоциальное взаимодействие улучшает настроение.',
  ),
  DailyMission(
    missionText: 'Двигайся под музыку дома — потанцуй 3–5 минут.',
    notificationText: 'Любая активность — вклад в здоровье.',
    isCompleted: false,
    points: 5,
    textInfo:
        '\nСпонтанное движение снижает барьер перед “настоящими тренировками”.',
  ),
  DailyMission(
    missionText: 'Перед сном сделай растяжку ног и поясницы.',
    notificationText: 'Восстановление — важная часть движения.',
    isCompleted: false,
    points: 5,
    textInfo: '\nРастяжка снижает напряжение после активности.',
  ),
  DailyMission(
    missionText:
        'Посмотри вдохновляющий ролик о людях, которые начали с малого.',
    notificationText: 'Истории — мощный мотиватор.',
    isCompleted: false,
    points: 5,
    textInfo: '\nПримеры других людей снижают страх и создают веру в успех.',
  ),
  DailyMission(
    missionText: 'Оцени: что тебе понравилось в движении на этой неделе?',
    notificationText: 'Фокус на хорошем закрепляет привычку.',
    isCompleted: false,
    points: 5,
    textInfo: '\nПоложительные эмоции связываются с действием.',
  ),
  DailyMission(
    missionText: 'Устрой мини-день без транспорта — только ходьба.',
    notificationText: 'Ты стал ближе к новой версии себя.',
    isCompleted: false,
    points: 10,
    textInfo: '\nДень без транспорта активирует тело естественным образом.',
  ),
  DailyMission(
    missionText: 'Пройди 15 минут в своём темпе и с ровным дыханием.',
    notificationText: 'Ты уже в ритме. Молодец!',
    isCompleted: false,
    points: 10,
    textInfo: '\nКомфортное движение — основа выносливости.',
  ),
  DailyMission(
    missionText: 'Поделись своими успехами с кем-то — даже маленькими.',
    notificationText: 'Разделённая радость — двойная радость.',
    isCompleted: false,
    points: 10,
    textInfo: '\nПоддержка других укрепляет твою внутреннюю мотивацию.',
  ),
];
