import 'package:organizer/core/models/year_goal_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class YearGoalDatabase {
  static final YearGoalDatabase instance = YearGoalDatabase._init();
  static Database? _database;

  YearGoalDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('year_goals.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE year_goals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        startDate TEXT NOT NULL,
        isCompleted INTEGER NOT NULL
      )
    ''');
  }

  Future<int> createGoal(YearGoalModel goal) async {
    final db = await instance.database;
    return await db.insert('year_goals', goal.toJson());
  }

  Future<YearGoalModel?> readGoal(int id) async {
    final db = await instance.database;
    final maps = await db.query('year_goals', where: 'id = ?', whereArgs: [id]);

    if (maps.isNotEmpty) {
      return YearGoalModel.fromJson(maps.first);
    } else {
      return null;
    }
  }

  Future<List<YearGoalModel>> readAllGoals() async {
    final db = await instance.database;
    final result = await db.query('year_goals');
    return result.map((json) => YearGoalModel.fromJson(json)).toList();
  }

  Future<int> updateGoal(YearGoalModel goal) async {
    final db = await instance.database;
    return await db.update(
      'year_goals',
      goal.toJson(),
      where: 'id = ?',
      whereArgs: [goal.id],
    );
  }

  Future<int> deleteGoal(int id) async {
    final db = await instance.database;
    return await db.delete('year_goals', where: 'id = ?', whereArgs: [id]);
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
