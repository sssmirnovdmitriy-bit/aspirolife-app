import 'package:organizer/core/models/task_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class TaskService {
  static final TaskService _instance = TaskService._internal();
  factory TaskService() => _instance;
  TaskService._internal();

  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final path = join(await getDatabasesPath(), 'tasks.db');
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
    CREATE TABLE tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      priority INTEGER NOT NULL,
      text TEXT NOT NULL,
      timeStart TEXT,
      isCompleted INTEGER NOT NULL,
      isPinned INTEGER NOT NULL DEFAULT 0
    )
  ''');
  }

  // 🟢 Create
  Future<int> insertTask(TaskModel task) async {
    final database = await db;
    return await database.insert('tasks', task.toMap());
  }

  // 🟡 Read all
  Future<List<TaskModel>> getAllTasks() async {
    final database = await db;
    final List<Map<String, dynamic>> maps = await database.query(
      'tasks',
      orderBy: 'isPinned DESC, priority DESC, timeStart ASC',
    );
    return maps.map((map) => TaskModel.fromMap(map)).toList();
  }

  // 🟡 Read by ID
  Future<TaskModel?> getTaskById(int id) async {
    final database = await db;
    final List<Map<String, dynamic>> maps = await database.query(
      'tasks',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) {
      return TaskModel.fromMap(maps.first);
    }
    return null;
  }

  Future<void> pinTask(int id, bool value) async {
    final database = await db;
    await database.update(
      'tasks',
      {'isPinned': value ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // 🟡 Read by Date
  Future<TaskModel?> getTaskByDate(DateTime date) async {
    final database = await db;
    final dateString = date.toIso8601String().substring(0, 10); // только дата
    final List<Map<String, dynamic>> maps = await database.query(
      'tasks',
      where: 'substr(timeStart, 1, 10) = ?',
      whereArgs: [dateString],
    );
    if (maps.isNotEmpty) {
      return TaskModel.fromMap(maps.first);
    }
    return null;
  }

  // 🟠 Update
  Future<int> updateTask(TaskModel task) async {
    final database = await db;
    return await database.update(
      'tasks',
      task.toMap(),
      where: 'id = ?',
      whereArgs: [task.id],
    );
  }

  // 🔴 Delete
  Future<int> deleteTask(int id) async {
    final database = await db;
    return await database.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }

  // ✅ Отметить как завершенную
  Future<void> markTaskCompleted(int id, int value) async {
    final database = await db;
    await database.update(
      'tasks',
      {'isCompleted': value},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<TaskModel>> getTasksByDate(DateTime date) async {
    final database = await db;
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    final maps = await database.query(
      'tasks',
      where: 'timeStart >= ? AND timeStart < ?',
      whereArgs: [startOfDay.toIso8601String(), endOfDay.toIso8601String()],
      orderBy:
          'isPinned DESC, priority DESC, timeStart ASC', // 🔺 добавил сортировку
    );

    return maps.map((map) => TaskModel.fromMap(map)).toList();
  }
}
