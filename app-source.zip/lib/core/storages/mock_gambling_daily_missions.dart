import 'package:organizer/core/models/habbit_model.dart';

List<DailyMission> gamblingDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Сегодня ни одной ставки. Начни с твердого "нет".',
    notificationText: 'Ты хозяин своей воли!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Удалите все приложения для ставок и игр с телефона.',
    notificationText: 'Удали соблазн — обрети свободу.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сообщи близким о своём решении прекратить играть.',
    notificationText: 'Поддержка укрепляет силу духа.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Когда появится желание играть — займись чем-то другим: спортом, чтением, уборкой.',
    notificationText: 'Замени вредное полезным.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Веди дневник триггеров: когда и почему захотел играть.',
    notificationText: 'Осознанность — ключ к свободе.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Составь список всех последствий, которые вызвали игры в твоей жизни.',
    notificationText: 'Честный взгляд помогает двигаться дальше.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Ограничь доступ к деньгам — убери карты, установи лимиты.',
    notificationText: 'Финансовая защита — твоя броня.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Посмотри видео или почитай статью о вреде азартных игр.',
    notificationText: 'Знание — мощный аргумент против зависимости.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Напиши список того, что ты хочешь достичь, отказавшись от игр.',
    notificationText: 'Цель придаёт смысл усилиям.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Побалуй себя чем-то приятным за день без игры.',
    notificationText: 'Ты заслужил награду!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Найди форум или группу, где поддерживают отказ от игр.',
    notificationText: 'Ты не один в этой борьбе.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Представь, как меняется твоя жизнь без лудомании.',
    notificationText: 'Каждый день без ставок — шаг к свободе.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Сделай дыхательную практику, когда почувствуешь стресс или тягу к игре.',
    notificationText: 'Спокойствие помогает сохранить контроль.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Создай визуальный трекер дней без игр — и отмечай каждый день.',
    notificationText: 'Видимый прогресс мотивирует.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Напиши письмо себе будущему: "Почему я перестал играть".',
    notificationText: 'Письмо — мощное напоминание о твоём пути.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Изучи, как работает зависимость — пойми своего "врага".',
    notificationText: 'Чем больше знаешь, тем сильнее ты.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Вспомни день, когда ты проиграл и пожалел. Закрепи этот урок.',
    notificationText: 'Память — защита от повторений.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сделай план на неделю без азартных игр.',
    notificationText: 'Чёткий план — меньше соблазнов.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Повторяй: “Я свободен от азартных игр. Я контролирую свою жизнь.”',
    notificationText: 'Аффирмации укрепляют твой настрой.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Отметь день победы. Ты не играл, и это — победа!',
    notificationText: 'Ты доказал: ты сильнее привычки.',
    isCompleted: false,
    points: 20,
  ),
];
