import 'package:organizer/core/models/entertainment_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class EntertainmentDatabase {
  static final EntertainmentDatabase instance = EntertainmentDatabase._init();
  static Database? _database;

  EntertainmentDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('entertainment.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
    CREATE TABLE entertainment (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      text TEXT NOT NULL,
      description TEXT NOT NULL,
      plannedDate TEXT NOT NULL,
      isCompleted INTEGER NOT NULL
    )
    ''');
  }

  Future<int> create(EntertainmentModel model) async {
    final db = await instance.database;
    return await db.insert('entertainment', model.toJson());
  }

  Future<EntertainmentModel?> read(int id) async {
    final db = await instance.database;

    final maps = await db.query(
      'entertainment',
      columns: ['id', 'text', 'description', 'plannedDate', 'isCompleted'],
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return EntertainmentModel.fromJson(maps.first);
    } else {
      return null;
    }
  }

  Future<List<EntertainmentModel>> readAll() async {
    final db = await instance.database;

    final result = await db.query('entertainment');

    return result.map((json) => EntertainmentModel.fromJson(json)).toList();
  }

  Future<int> update(EntertainmentModel model) async {
    final db = await instance.database;

    return db.update(
      'entertainment',
      model.toJson(),
      where: 'id = ?',
      whereArgs: [model.id],
    );
  }

  Future<int> delete(int id) async {
    final db = await instance.database;

    return await db.delete('entertainment', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<EntertainmentModel>> readByDate(DateTime date) async {
    final db = await instance.database;

    // начало и конец выбранного дня
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    final result = await db.query(
      'entertainment',
      where: 'plannedDate >= ? AND plannedDate < ?',
      whereArgs: [startOfDay.toIso8601String(), endOfDay.toIso8601String()],
    );

    return result.map((json) => EntertainmentModel.fromJson(json)).toList();
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
