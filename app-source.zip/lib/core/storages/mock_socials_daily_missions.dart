import 'package:organizer/core/models/habbit_model.dart';

List<DailyMission> socialMediaDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Сегодня полностью избегай соцсетей. Ни минуты!',
    notificationText: 'Никаких соцсетей сегодня — ты справишься!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Удалите приложения соцсетей со смартфона.',
    notificationText: 'Меньше соблазнов — больше свободы.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Выключи уведомления от мессенджеров и приложений.',
    notificationText: 'Тишина — лучший друг продуктивности.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Займись офлайн-активностью: прогулка, книга, спорт.',
    notificationText: 'Живи реальной жизнью!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Вместо скролла — запиши 3 цели на день.',
    notificationText: 'Цели > ленты новостей.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Каждый раз, как тянешься к телефону — сделай 10 приседаний.',
    notificationText: 'Телефон — триггер, а ты — в форме.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Заведи бумажный дневник: фиксируй эмоции и успехи.',
    notificationText: 'Пиши — это освобождает.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Проведи вечер без экрана: ни телефона, ни ноутбука.',
    notificationText: 'Цени тишину и покой.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Подумай: что ты теряешь в соцсетях и что обретёшь без них?',
    notificationText: 'Ты выбираешь свою жизнь.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Поблагодари себя. Ты — на пути к осознанности.',
    notificationText: 'Ты молодец!',
    isCompleted: false,
    points: 20,
  ),
];

List<DailyMission> socialMediaDailyMissionsSlowRu = [
  DailyMission(
    missionText: 'Ограничь использование соцсетей до 2 часов.',
    notificationText: 'Держи себя в руках — 2 часа максимум.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сегодня — не больше 90 минут в соцсетях.',
    notificationText: 'Уменьшаем ещё — держись!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Соцсети — максимум 1 час.',
    notificationText: 'Свобода ближе, чем ты думаешь.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Ограничь себя 45 минутами соцсетей.',
    notificationText: 'Ты отлично справляешься!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '30 минут — и ни секундой больше.',
    notificationText: 'Это уже почти “без них”.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '15 минут на соцсети. Проверяй только по делу.',
    notificationText: 'Ты почти у цели!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сегодня не заходи в соцсети вообще.',
    notificationText: 'Ты освободился!',
    isCompleted: false,
    points: 20,
  ),
];
