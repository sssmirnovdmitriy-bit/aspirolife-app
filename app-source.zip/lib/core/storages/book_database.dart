import 'package:organizer/core/models/book_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class BookDatabase {
  static final BookDatabase instance = BookDatabase._init();
  static Database? _database;

  BookDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('books.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT NOT NULL,
        description TEXT NOT NULL,
        isRead INTEGER NOT NULL
      )
    ''');
  }

  Future<int> create(BookModel book) async {
    final db = await instance.database;
    return await db.insert('books', book.toMap());
  }

  Future<List<BookModel>> readAllBooks() async {
    final db = await instance.database;
    final result = await db.query('books');
    return result.map((map) => BookModel.fromMap(map)).toList();
  }

  Future<List<BookModel>> readReadBooks() async {
    final db = await instance.database;
    final result = await db.query('books', where: 'isRead = ?', whereArgs: [1]);
    return result.map((map) => BookModel.fromMap(map)).toList();
  }

  Future<List<BookModel>> readUnreadBooks() async {
    final db = await instance.database;
    final result = await db.query('books', where: 'isRead = ?', whereArgs: [0]);
    return result.map((map) => BookModel.fromMap(map)).toList();
  }

  Future<int> update(BookModel book) async {
    final db = await instance.database;
    return await db.update(
      'books',
      book.toMap(),
      where: 'id = ?',
      whereArgs: [book.id],
    );
  }

  Future<int> delete(int id) async {
    final db = await instance.database;
    return await db.delete('books', where: 'id = ?', whereArgs: [id]);
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
