import 'package:organizer/core/models/transaction_item_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class TransactionDatabase {
  static final TransactionDatabase instance = TransactionDatabase._init();
  static Database? _database;

  TransactionDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('transactions.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
  CREATE TABLE transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    value REAL NOT NULL,
    type TEXT NOT NULL
  )
''');
  }

  Future<int> create(TransactionItem item) async {
    final db = await instance.database;
    return await db.insert('transactions', item.toMap());
  }

  Future<List<TransactionItem>> readAll() async {
    final db = await instance.database;
    final result = await db.query('transactions');
    return result.map((map) => TransactionItem.fromMap(map)).toList();
  }

  Future<List<TransactionItem>> readIncomes() async {
    final db = await instance.database;
    final result = await db.query(
      'transactions',
      where: 'type = ?',
      whereArgs: ['INCOME'],
    );
    return result.map((map) => TransactionItem.fromMap(map)).toList();
  }

  Future<List<TransactionItem>> readExpenses() async {
    final db = await instance.database;
    final result = await db.query(
      'transactions',
      where: 'type = ?',
      whereArgs: ['EXPENSE'],
    );
    return result.map((map) => TransactionItem.fromMap(map)).toList();
  }

  Future<List<TransactionItem>> readInvestments() async {
    final db = await instance.database;
    final result = await db.query(
      'transactions',
      where: 'type = ?',
      whereArgs: ['INVESTMENT'],
    );
    return result.map((map) => TransactionItem.fromMap(map)).toList();
  }

  Future<int> update(TransactionItem item) async {
    final db = await instance.database;
    return await db.update(
      'transactions',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<int> delete(int id) async {
    final db = await instance.database;
    return await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
