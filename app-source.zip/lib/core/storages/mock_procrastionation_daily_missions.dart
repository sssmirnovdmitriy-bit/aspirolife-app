import 'package:organizer/core/models/habbit_model.dart';

List<DailyMission> procrastinationDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Начни день с самого сложного задания.',
    notificationText: 'Главное — не откладывать. Начни!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Планируй день по методу 3 главных задач.',
    notificationText: 'Три задачи — три победы.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Работай по таймеру: 25 мин работа / 5 отдых.',
    notificationText: 'Техника “Помодоро” в деле.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Отключи уведомления на 2 часа.',
    notificationText: 'Меньше шума — больше дела.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Запиши список дел и отмечай выполненное.',
    notificationText: 'Ты движешься вперёд.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Награди себя за выполненное. Маленькая радость — мотивация.',
    notificationText: 'Ты заслужил награду!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Начни делать задачу, даже если не хочется — 2 минуты.',
    notificationText: 'Начал — значит, почти сделал.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Составь анти-прокрастинационный список: что отвлекает?',
    notificationText: 'Выяви врага, чтобы победить.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Сделай ревизию задач на неделе. Что реально важно?',
    notificationText: 'Определи приоритеты.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Ты молодец! Сегодня ты не прокрастинировал.',
    notificationText: 'Двигайся дальше — у тебя всё получится!',
    isCompleted: false,
    points: 20,
  ),
];

List<DailyMission> procrastinationDailyMissionsSlowRu = [
  DailyMission(
    missionText: 'Выбери одно простое дело и сделай его за 2 минуты.',
    notificationText: 'Маленькое дело — это уже движение.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Напиши список дел, которые ты откладывал(а). Без давления.',
    notificationText: 'Просто выложи всё из головы.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Установи таймер на 5 минут и начни одно важное дело.',
    notificationText: '5 минут — это не страшно. Главное — начать.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Отключи уведомления на 2 часа.',
    notificationText: 'Тишина помогает сосредоточиться.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сделай “дело дня” до 12:00. Любое.',
    notificationText: 'Утро — твой стартовый капитал.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Проведи 10 минут без экрана: просто посиди или прогуляйся.',
    notificationText: 'Разгрузи мозг — ему нужен перерыв.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText:
        'Раздели большое дело на 3-4 маленьких. Начни с самого простого.',
    notificationText: 'Слона едят по кусочкам.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Похвали себя за любую выполненную задачу — даже мелочь.',
    notificationText: 'Прогресс есть. И это важно.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Найди “почему”: зачем тебе делать это дело?',
    notificationText: 'Мотивация начинается с смысла.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText:
        'Создай своё правило: “Сначала дело, потом YouTube/игры/лента”.',
    notificationText: 'Система важнее силы воли.',
    isCompleted: false,
    points: 10,
  ),
];
