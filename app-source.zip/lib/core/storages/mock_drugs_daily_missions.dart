import 'package:organizer/core/models/habbit_model.dart';

List<DailyMission> drugsDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Полный отказ сегодня. Ни грамма, ни попытки.',
    notificationText: 'Это решающий день. Сила с тобой.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Избавься от всего, что связано с веществами.',
    notificationText: 'Удали, сожги, выброси. Сначала разум — потом победа.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Расскажи близкому человеку. Поддержка — это важно.',
    notificationText: 'Ты не один в этом пути.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Запишись к психологу или в группу поддержки.',
    notificationText: 'Профессионалы помогут.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Физическая активность вместо веществ.',
    notificationText: 'Выход — в движении.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Пей много воды. Тело очищается.',
    notificationText: 'Детокс начинается.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Почитай истории тех, кто справился.',
    notificationText: 'Мотивация есть в реальных историях.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Пиши, что чувствуешь. Вылей всё на бумагу.',
    notificationText: 'Эмоции — не враги.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Создай фразу: “Я свободен от этого”. Повторяй её.',
    notificationText: 'Аффирмации закрепляют веру.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Поздравь себя. Это огромный шаг.',
    notificationText: 'Ты на пути к новой жизни.',
    isCompleted: false,
    points: 20,
  ),
];

List<DailyMission> drugsDailyMissionsSlowRu = [
  DailyMission(
    missionText: 'Запиши три причины, почему ты хочешь отказаться.',
    notificationText: 'Осознанность — первый шаг к свободе.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Определи свои триггеры. Когда чаще всего тянет?',
    notificationText: 'Понимание = контроль.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Выбери один день без вещества — просто один.',
    notificationText: 'Маленькая победа сегодня — большой шаг завтра.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Замени привычку: прогулка, спорт, творчество.',
    notificationText: 'Новое поведение — новая личность.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText:
        'Посмотри документальный фильм или интервью на тему зависимости.',
    notificationText: 'Вдохновись чужим опытом преодоления.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Обратись к другу или близкому — просто поговори.',
    notificationText: 'Поддержка рядом.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сделай список “Что я теряю из-за зависимости”.',
    notificationText: 'Честность с собой — уже прогресс.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '1 час тишины: без телефона, без стимуляции.',
    notificationText: 'Вернись к себе.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Напиши: “Какой я без этого?” — и опиши лучшую версию себя.',
    notificationText: 'Ты уже двигаешься к ней.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сделай маленький подарок себе за прогресс.',
    notificationText: 'Ты заслужил(а) заботу.',
    isCompleted: false,
    points: 10,
  ),
];
