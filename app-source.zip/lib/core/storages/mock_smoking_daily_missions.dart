import 'package:organizer/core/models/habbit_model.dart';

List<DailyMission> smokingDailyMissionsFastRu = [
  DailyMission(
    missionText: 'Сегодня не кури ни одной сигареты. Начни с сильного решения.',
    notificationText: 'Ты принял решение — держись!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Избавься от всего, что связано с курением (зажигалки, пепельницы, сигареты).',
    notificationText: 'Избавься от соблазнов прямо сейчас!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Расскажи друзьям и близким, что ты бросаешь. Поддержка важна.',
    notificationText: 'Скажи миру, что ты начинаешь новую жизнь.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Замени сигареты: каждый раз, когда захочется — выпей воду.',
    notificationText: 'Жажда — твой союзник в борьбе с привычкой!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Веди дневник желаний покурить. Отмечай, что провоцирует тебя.',
    notificationText: 'Отслеживание — ключ к контролю.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Займись физической активностью. Прогулка, тренировка или растяжка.',
    notificationText: 'Двигайся — сигареты останутся позади.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'В момент желания покурить — сделай 10 глубоких вдохов.',
    notificationText: 'Дыши глубже, чтобы дышалось легче.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Посмотри видео или почитай статьи о вреде курения.',
    notificationText: 'Убедись, что ты делаешь правильный выбор.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Найди замену рукам — держи жвачку, антистресс или ручку.',
    notificationText: 'Чем заняты руки — тем спокойнее голова.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Подумай, куда пойдут деньги, сэкономленные на сигаретах.',
    notificationText: 'Финансовая мотивация — мощный стимул!',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Составь список причин, почему ты хочешь бросить. Перечитай его.',
    notificationText: 'Вспомни, зачем ты начал.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Избегай алкоголя и кофе — они часто провоцируют желание курить.',
    notificationText: 'Избегай триггеров. Контроль — в твоих руках.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Побалуй себя чем-то полезным вместо сигареты — фруктом, орехами.',
    notificationText: 'Заменяй вредное на полезное.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Веди подсчёт дней без сигарет — радуйся прогрессу.',
    notificationText: 'Ты уже далеко продвинулся — не сдавайся.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Поговори с человеком, который уже бросил. Получи советы.',
    notificationText: 'Опыт других — твоя опора.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Сделай фото или видео, где ты говоришь, почему хочешь бросить.',
    notificationText: 'Запиши своё “почему” и возвращайся к нему.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Проведи “детокс-день”: пей много воды и ешь свежие продукты.',
    notificationText: 'Очищай тело — забудь о токсинах.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Подумай о здоровье: лёгкие, сердце, кожа — всё становится лучше.',
    notificationText: 'Каждый день ты восстанавливаешься.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText: 'Создай обет: “Я не курю. Я свободен.” Повторяй про себя.',
    notificationText: 'Аффирмации — это сила.',
    isCompleted: false,
    points: 10,
  ),
  DailyMission(
    missionText:
        'Отметь сегодня, как победу. Ты сделал то, что многие не решаются!',
    notificationText: 'Ты победитель. Горжусь тобой!',
    isCompleted: false,
    points: 20,
  ),
];

List<DailyMission> smokingDailyMissionsSlowRu = [
  DailyMission(
    missionText: 'Сегодня твоя цель — 20 сигарет. Не превышай это число.',
    notificationText: 'Начинаем путь — 20 сигарет максимум!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сегодня курим не больше 19 сигарет. Контроль — сила.',
    notificationText: 'Снижаем на 1. Осталось 19!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Цель дня: максимум 18 сигарет.',
    notificationText: 'Плавно идём вниз. Только 18!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сегодня максимум 17 сигарет. Ты справишься!',
    notificationText: 'Уверенно уменьшаем — 17 штук.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Держим себя: не более 16 сигарет в день.',
    notificationText: '16 — и ни одной больше!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '15 сигарет сегодня. Не поддавайся привычке.',
    notificationText: 'Чёткая цель: 15 сигарет.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText:
        'Ограничь себя до 14 сигарет. Самодисциплина — твой инструмент.',
    notificationText: '14 сигарет — путь продолжается.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сегодня — 13 сигарет. Ещё один шаг.',
    notificationText: 'Уже минус 7 от старта!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Максимум 12 сигарет за день.',
    notificationText: 'Меньше — лучше. 12 сегодня.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Сегодня 11 сигарет — не больше.',
    notificationText: 'Ты сокращаешь цепи зависимости.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Ограничь себя до 10 сигарет.',
    notificationText: 'Дошли до половины — гордись собой!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '9 сигарет сегодня. Уже чувствуется свобода!',
    notificationText: 'Осталось меньше, чем кажется.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '8 сигарет в день — не больше.',
    notificationText: 'Ты на правильном пути.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Максимум 7 сигарет сегодня.',
    notificationText: 'Всё под контролем — осталось чуть-чуть.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Не более 6 сигарет в день.',
    notificationText: 'Ты уже внизу лестницы!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '5 сигарет сегодня. Ты почти бросил.',
    notificationText: '5 — и всё ближе к 0!',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: 'Твоя цель — 4 сигареты. Остальное — сила воли.',
    notificationText: 'Ты сильнее этой привычки.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '3 сигареты максимум. Всё идёт по плану.',
    notificationText: 'Финишная прямая.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '2 сигареты в день — и ты почти свободен.',
    notificationText: 'Ты уже почти бросил.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '1 сигарета. Только одна. Только если совсем тяжело.',
    notificationText: 'Последний шаг.',
    isCompleted: false,
    points: 5,
  ),
  DailyMission(
    missionText: '0 сигарет сегодня. Это день, когда ты стал некурящим.',
    notificationText: 'Ты свободен. Горжусь тобой!',
    isCompleted: false,
    points: 20,
  ),
  DailyMission(
    missionText: 'Ты отлично держишься! Старайся не курить',
    notificationText: 'Ты свободен. Горжусь тобой!',
    isCompleted: false,
    points: 20,
  ),
];
