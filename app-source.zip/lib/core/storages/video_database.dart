import 'dart:io';
import 'package:organizer/core/models/video_model.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class VideoDatabase {
  static final VideoDatabase _instance = VideoDatabase._internal();
  factory VideoDatabase() => _instance;
  VideoDatabase._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('videos.db');
    return _database!;
  }

  Future<Database> _initDB(String fileName) async {
    Directory documentsDir = await getApplicationDocumentsDirectory();
    String path = join(documentsDir.path, fileName);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE videos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT NOT NULL,
        isWatched INTEGER NOT NULL,
        watchedDate TEXT
      )
    ''');
  }

  Future<int> insertVideo(VideoModel video) async {
    final db = await database;
    return await db.insert('videos', video.toJson());
  }

  Future<List<VideoModel>> getAllVideos() async {
    final db = await database;
    final result = await db.query('videos');
    return result.map((json) => VideoModel.fromJson(json)).toList();
  }

  Future<int> updateVideo(VideoModel video) async {
    final db = await database;
    return await db.update(
      'videos',
      video.toJson(),
      where: 'id = ?',
      whereArgs: [video.id],
    );
  }

  Future<int> deleteVideo(int id) async {
    final db = await database;
    return await db.delete('videos', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAll() async {
    final db = await database;
    await db.delete('videos');
  }
}
