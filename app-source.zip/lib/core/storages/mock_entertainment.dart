import 'package:organizer/core/models/entertainment_model.dart';

final List<EntertainmentModel> mockEntertainments = [
  EntertainmentModel(
    text: "Чтение книги",
    description:
        "Развивает воображение, расширяет словарный запас и повышает концентрацию.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Просмотр документального фильма",
    description:
        "Даёт новые знания, расширяет кругозор и повышает уровень эрудиции.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Игра в шахматы",
    description: "Тренирует стратегическое мышление, память и концентрацию.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Настольные игры с друзьями",
    description: "Укрепляет социальные связи, развивает коммуникацию и логику.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Пение в караоке",
    description: "Снимает стресс, улучшает настроение и дыхательную систему.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Игра на гитаре",
    description: "Развивает мелкую моторику, музыкальный слух и креативность.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Рисование",
    description:
        "Тренирует внимание к деталям, помогает выразить эмоции и развивает креативность.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Фотографирование природы",
    description:
        "Учишься видеть красоту вокруг, прокачиваешь креативность и внимательность.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Йога",
    description: "Укрепляет тело, улучшает гибкость и снижает уровень стресса.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Прогулка по парку",
    description:
        "Поднимает настроение, улучшает кровообращение и даёт заряд энергии.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Бег",
    description:
        "Повышает выносливость, тренирует сердце и помогает справляться со стрессом.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Катание на велосипеде",
    description:
        "Развивает мышцы ног, координацию и укрепляет дыхательную систему.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Поход в музей",
    description: "Обогащает культурный опыт и расширяет кругозор.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Посещение театра",
    description:
        "Развивает эмоциональное восприятие, учит сопереживать и вдохновляет.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Рисование граффити",
    description: "Прокачивает креативность и уверенность в самовыражении.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Занятие танцами",
    description: "Развивает пластику, ритм и помогает сжигать калории.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Катание на роликах",
    description: "Тренирует равновесие, координацию и мышцы ног.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Путешествие по новому городу",
    description:
        "Расширяет кругозор, делает человека более открытым к новому опыту.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Игра в баскетбол",
    description: "Развивает командный дух, координацию и выносливость.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Футбол с друзьями",
    description: "Прокачивает скорость, реакцию и умение работать в команде.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Поход в горы",
    description:
        "Закаляет тело, учит преодолевать трудности и дарит спокойствие.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Рыбалка",
    description:
        "Развивает терпение, наблюдательность и приносит умиротворение.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Поход в кино",
    description:
        "Даёт эмоциональную разрядку, развивает эмпатию и воображение.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Кулинарный эксперимент",
    description:
        "Развивает креативность, улучшает навыки готовки и дарит удовольствие.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Настольный теннис",
    description: "Тренирует реакцию, внимание и координацию движений.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Садоводство",
    description:
        "Учит заботе, расслабляет и помогает чувствовать контакт с природой.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Поход в аквапарк",
    description: "Поднимает настроение, снимает стресс и дарит заряд бодрости.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Катание на коньках",
    description: "Развивает чувство баланса и укрепляет мышцы.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Слушание подкаста",
    description: "Расширяет знания, мотивирует и тренирует внимательность.",
    plannedDate: DateTime.now(),
  ),
  EntertainmentModel(
    text: "Медитация",
    description:
        "Снижает тревожность, улучшает концентрацию и внутреннее спокойствие.",
    plannedDate: DateTime.now(),
  ),
];
