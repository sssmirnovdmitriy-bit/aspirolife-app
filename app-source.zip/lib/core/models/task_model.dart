class TaskModel {
  int? id;
  final String text;
  int priority;
  DateTime? timeStart;
  bool isCompleted;
  bool isPinned; // 🔺 новое поле

  TaskModel({
    this.id,
    required this.text,
    required this.priority,
    this.timeStart,
    this.isCompleted = false,
    this.isPinned = false,
  });

  // Конвертация в Map для SQLite
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'text': text,
      'priority': priority,
      'timeStart': timeStart?.toIso8601String(),
      'isCompleted': isCompleted ? 1 : 0,
      'isPinned': isPinned ? 1 : 0, // 🔺 сохраняем
    };
  }

  // Создание из Map после запроса из SQLite
  factory TaskModel.fromMap(Map<String, dynamic> map) {
    return TaskModel(
      id: map['id'],
      text: map['text'],
      priority: map['priority'],
      timeStart:
          map['timeStart'] != null ? DateTime.parse(map['timeStart']) : null,
      isCompleted: map['isCompleted'] == 1,
      isPinned: map['isPinned'] == 1, // 🔺 читаем
    );
  }
}
