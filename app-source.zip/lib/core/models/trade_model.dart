class TradeModel {
  String tickerName;
  bool isBuy;
  double price1;
  double price2;
  double commision;
  double? result;

  TradeModel({
    required this.tickerName,
    required this.isBuy,
    required this.price1,
    required this.price2,
    required this.commision,
    this.result,
  });

  /// Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'tickerName': tickerName,
      'isBuy': isBuy ? 1 : 0,
      'price1': price1,
      'price2': price2,
      'commision': commision,
      'result': result,
    };
  }

  /// Создание из JSON
  factory TradeModel.fromJson(Map<String, dynamic> json) {
    return TradeModel(
      tickerName: json['tickerName'],
      isBuy: json['isBuy'] == 1,
      price1: (json['price1'] as num).toDouble(),
      price2: (json['price2'] as num).toDouble(),
      commision: (json['commision'] as num).toDouble(),
      result:
          json['result'] != null ? (json['result'] as num).toDouble() : null,
    );
  }
}
