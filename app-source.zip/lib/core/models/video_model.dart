class VideoModel {
  int? id;
  String url;
  bool isWatched;
  DateTime? watchedDate;

  VideoModel({
    this.id,
    required this.url,
    required this.isWatched,
    this.watchedDate,
  });

  /// Преобразование в Map для sqflite
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'url': url,
      'isWatched': isWatched ? 1 : 0,
      'watchedDate': watchedDate?.toIso8601String(),
    };
  }

  /// Создание объекта из Map
  factory VideoModel.fromJson(Map<String, dynamic> json) {
    return VideoModel(
      id: json['id'],
      url: json['url'],
      isWatched: json['isWatched'] == 1,
      watchedDate:
          json['watchedDate'] != null
              ? DateTime.parse(json['watchedDate'])
              : null,
    );
  }
}
