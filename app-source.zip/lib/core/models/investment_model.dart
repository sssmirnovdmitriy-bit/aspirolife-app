enum InvestmentItemType { ACTIVE, PASSIVE, INCOME, EXPENSE }

class InvestmentModel {
  final int? id;
  final String text;
  final double value;
  final String type;

  InvestmentModel({
    this.id,
    required this.text,
    required this.value,
    required this.type,
  });

  Map<String, dynamic> toMap() {
    return {'id': id, 'text': text, 'value': value, 'type': type};
  }

  factory InvestmentModel.fromMap(Map<String, dynamic> map) {
    return InvestmentModel(
      id: map['id'],
      text: map['text'],
      value: map['value'],
      type: map['type'],
    );
  }
}
