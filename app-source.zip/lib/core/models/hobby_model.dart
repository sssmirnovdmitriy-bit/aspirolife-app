class HobbyModel {
  int? id;
  String hobbyName;
  bool isCompleted;

  HobbyModel({this.id, required this.hobbyName, this.isCompleted = false});

  /// Преобразование из Map (из базы данных) в модель
  factory HobbyModel.fromMap(Map<String, dynamic> map) {
    return HobbyModel(
      id: map['id'] as int?,
      hobbyName: map['hobbyName'] as String,
      isCompleted: map['isCompleted'] == 1, // SQLite не знает bool, только int
    );
  }

  /// Преобразование модели в Map (для сохранения в базу данных)
  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'hobbyName': hobbyName,
      'isCompleted': isCompleted ? 1 : 0, // bool → int
    };
    if (id != null) {
      map['id'] = id;
    }
    return map;
  }

  @override
  String toString() {
    return 'HobbyModel{id: $id, hobbyName: $hobbyName, isCompleted: $isCompleted}';
  }
}
