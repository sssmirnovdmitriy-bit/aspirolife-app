class YearGoalModel {
  final int? id;
  final String title;
  final String? description;
  final DateTime startDate;
  bool isCompleted;

  YearGoalModel({
    this.id,
    required this.title,
    this.description,
    required this.startDate,
    required this.isCompleted,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'startDate': startDate.toIso8601String(),
    'isCompleted': isCompleted ? 1 : 0,
  };

  factory YearGoalModel.fromJson(Map<String, dynamic> json) => YearGoalModel(
    id: json['id'] as int?,
    title: json['title'],
    description: json['description'],
    startDate: DateTime.parse(json['startDate']),
    isCompleted: json['isCompleted'] == 1,
  );
}
