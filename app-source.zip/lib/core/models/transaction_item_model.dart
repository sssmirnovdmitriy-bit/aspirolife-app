enum TransactionItemType { INCOME, EXPENSE, INVESTMENT }

class TransactionItem {
  final int? id;
  final String text;
  final double value;
  final String type;

  TransactionItem({
    this.id,
    required this.text,
    required this.value,
    required this.type,
  });

  Map<String, dynamic> toMap() {
    return {'id': id, 'text': text, 'value': value, 'type': type};
  }

  factory TransactionItem.fromMap(Map<String, dynamic> map) {
    return TransactionItem(
      id: map['id'],
      text: map['text'],
      value: map['value'],
      type: map['type'],
    );
  }
}
