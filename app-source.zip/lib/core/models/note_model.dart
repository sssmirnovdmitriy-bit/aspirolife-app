class NoteModel {
  final int? id;
  final String text;
  final DateTime editDate;

  NoteModel({this.id, required this.text, required this.editDate});

  Map<String, dynamic> toJson() {
    return {'id': id, 'text': text, 'editDate': editDate.toIso8601String()};
  }

  factory NoteModel.fromJson(Map<String, dynamic> json) {
    return NoteModel(
      id: json['id'] as int?,
      text: json['text'] as String,
      editDate: DateTime.parse(json['editDate'] as String),
    );
  }

  NoteModel copyWith({int? id, String? text, DateTime? editDate}) {
    return NoteModel(
      id: id ?? this.id,
      text: text ?? this.text,
      editDate: editDate ?? this.editDate,
    );
  }
}
