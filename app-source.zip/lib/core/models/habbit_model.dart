import 'dart:convert';

enum HabbitTypes { BAD, GOOD }

class HabbitModel {
  int? id; // Добавляем поле id
  final String habbitName;
  final String habbitType;
  final String habbitDescription;
  DateTime? startDate;
  DateTime? endDate;
  final bool isGoodHabbit;
  final String aiSuggestion;
  final int points;
  final String imagePath;
  final String animationPath;
  final List<String> facts;
  final List<DailyMission> dailyMissions;
  final Map<String, dynamic>? additionalInfo;
  int? streak; // Стрик добавлен как обычное поле
  int? oneValuePrice;
  int? habbitUseCount;

  HabbitModel({
    this.id, // Убедитесь, что id передается в конструктор
    required this.habbitName,
    required this.habbitType,
    required this.habbitDescription,
    this.startDate,
    this.endDate,
    required this.isGoodHabbit,
    required this.aiSuggestion,
    required this.points,
    required this.imagePath,
    required this.animationPath,
    required this.facts,
    required this.dailyMissions,
    this.streak,
    this.oneValuePrice,
    this.habbitUseCount,
    this.additionalInfo,
  });

  // Пример метода для обновления данных
  HabbitModel copyWith({
    int? id,
    String? habbitName,
    String? habbitType,
    String? habbitDescription,
    DateTime? startDate,
    DateTime? endDate,
    bool? isGoodHabbit,
    String? aiSuggestion,
    int? points,
    String? imagePath,
    String? animationPath,
    List<String>? facts,
    List<DailyMission>? dailyMissions,
    int? streak,
    int? oneValuePrice,
    int? habbitUseCount,
    Map<String, dynamic>? additionalInfo,
  }) {
    return HabbitModel(
      id: id ?? this.id,
      habbitName: habbitName ?? this.habbitName,
      habbitType: habbitType ?? this.habbitType,
      habbitDescription: habbitDescription ?? this.habbitDescription,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      isGoodHabbit: isGoodHabbit ?? this.isGoodHabbit,
      aiSuggestion: aiSuggestion ?? this.aiSuggestion,
      points: points ?? this.points,
      imagePath: imagePath ?? this.imagePath,
      animationPath: animationPath ?? this.animationPath,
      facts: facts ?? this.facts,
      dailyMissions: dailyMissions ?? this.dailyMissions,
      streak: streak ?? this.streak,
      oneValuePrice: oneValuePrice ?? this.oneValuePrice,
      habbitUseCount: habbitUseCount ?? this.habbitUseCount,
      additionalInfo: additionalInfo ?? this.additionalInfo,
    );
  }
}

class DailyMission {
  int? id;
  DateTime? startDate;
  DateTime? endDate;
  String missionText;
  String notificationText;
  bool isCompleted;
  int points;
  String? videoUrl;
  String? textInfo;

  DailyMission({
    this.id,
    this.startDate,
    this.endDate,
    required this.missionText,
    required this.notificationText,
    required this.isCompleted,
    required this.points,
    this.videoUrl,
    this.textInfo,
  });

  factory DailyMission.fromJson(Map<String, dynamic> json) {
    return DailyMission(
      id: json['id'],
      startDate:
          json['startDate'] != null ? DateTime.parse(json['startDate']) : null,
      endDate: json['endDate'] != null ? DateTime.parse(json['endDate']) : null,
      missionText: json['missionText'],
      videoUrl: json['videoUrl'],
      textInfo: json['textInfo'],
      notificationText: json['notificationText'],
      isCompleted: json['isCompleted'] == 1,
      points: json['points'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startDate': startDate?.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
      'videoUrl': videoUrl,
      'textInfo': textInfo,
      'missionText': missionText,
      'notificationText': notificationText,
      'isCompleted': isCompleted ? 1 : 0,
      'points': points,
    };
  }
}
