class BookModel {
  final int? id;
  final String text; // Название книги
  final String description; // Описание
  bool isRead; // true — прочитано, false — нет

  BookModel({
    this.id,
    required this.text,
    required this.description,
    required this.isRead,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'text': text,
      'description': description,
      'isRead': isRead ? 1 : 0,
    };
  }

  factory BookModel.fromMap(Map<String, dynamic> map) {
    return BookModel(
      id: map['id'],
      text: map['text'],
      description: map['description'],
      isRead: map['isRead'] == 1,
    );
  }
}
