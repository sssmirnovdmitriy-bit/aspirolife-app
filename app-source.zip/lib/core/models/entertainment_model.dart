class EntertainmentModel {
  int? id;
  final String text;
  String description;
  DateTime plannedDate;
  bool isCompleted;

  EntertainmentModel({
    this.id,
    required this.text,
    required this.description,
    required this.plannedDate,
    this.isCompleted = false,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'text': text,
      'description': description,
      'plannedDate': plannedDate.toIso8601String(),
      'isCompleted': isCompleted ? 1 : 0,
    };
  }

  factory EntertainmentModel.fromJson(Map<String, dynamic> json) {
    return EntertainmentModel(
      id: json['id'],
      text: json['text'],
      description: json['description'],
      plannedDate: DateTime.parse(json['plannedDate']),
      isCompleted: json['isCompleted'] == 1,
    );
  }
}
