import 'dart:convert';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

class RecomendationsService {
  final List<String> _recomendations;
  late List<int> _shuffledIndices;
  int _currentIndex = 0;
  DateTime? _lastShownDate;

  static const String _indexKey = 'recomendationIndex';
  static const String _dateKey = 'recomendationLastDate';
  static const String _orderKey = 'recomendationShuffleOrder';

  RecomendationsService(this._recomendations);

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();

    final savedDate = prefs.getString(_dateKey);
    _lastShownDate = savedDate != null ? DateTime.tryParse(savedDate) : null;

    _currentIndex = prefs.getInt(_indexKey) ?? 0;

    final orderJson = prefs.getString(_orderKey);
    if (orderJson != null) {
      _shuffledIndices = List<int>.from(jsonDecode(orderJson));
    } else {
      _shuffledIndices = _generateShuffledOrder();
      await prefs.setString(_orderKey, jsonEncode(_shuffledIndices));
    }

    final today = DateTime.now();
    if (_lastShownDate == null || !_isSameDay(today, _lastShownDate!)) {
      await _advanceIndex(prefs);
    }
  }

  String getTodayRecomendation() {
    return _recomendations[_shuffledIndices[_currentIndex]];
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  List<int> _generateShuffledOrder() {
    final order = List<int>.generate(_recomendations.length, (i) => i);
    order.shuffle(Random());
    return order;
  }

  Future<void> _advanceIndex(SharedPreferences prefs) async {
    _currentIndex++;
    if (_currentIndex >= _recomendations.length) {
      _currentIndex = 0;
      _shuffledIndices = _generateShuffledOrder();
      await prefs.setString(_orderKey, jsonEncode(_shuffledIndices));
    }
    _lastShownDate = DateTime.now();
    await prefs.setInt(_indexKey, _currentIndex);
    await prefs.setString(_dateKey, _lastShownDate!.toIso8601String());
  }
}
