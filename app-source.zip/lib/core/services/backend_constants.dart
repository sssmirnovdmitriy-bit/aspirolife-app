// Наш собственный бэкенд (Railway), прячет ключи Claude и TwelveData
// от клиентского кода. Исходники: github.com/sssmirnovdmitriy-bit/aspirolife-backend
const String BACKEND_BASE_URL = 'https://aspirolife-backend-production.up.railway.app';

// Общий секрет между приложением и бэкендом (не платёжный ключ — просто
// защита от левых запросов к нашему серверу).
const String APP_SHARED_SECRET =
    '1f41fc31507844dd6d13bc210c71e75b89285a39a9ec9825ecf30198db1021b3';
