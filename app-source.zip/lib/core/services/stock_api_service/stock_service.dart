import 'package:dio/dio.dart';
import 'package:organizer/core/services/backend_constants.dart';
import 'package:organizer/core/services/stock_api_service/ticker_model.dart';

String ERROR = '';

// Котировки идут через наш бэкенд (Railway), а не напрямую в TwelveData —
// так ключ TwelveData никогда не попадает в собранное приложение.
class StockService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: BACKEND_BASE_URL,
      headers: {
        'x-app-secret': APP_SHARED_SECRET,
        'Content-Type': 'application/json',
      },
    ),
  );

  Future<List<TickerTimeSeries>> getTickerPrices() async {
    try {
      final response = await _dio.get('/v1/stock-prices');
      final List<dynamic> result = response.data['result'];

      return result
          .map(
            (item) => TickerTimeSeries.fromJson(
              item['symbol'],
              item as Map<String, dynamic>,
            ),
          )
          .toList();
    } catch (e) {
      throw Exception('Ошибка запроса к API: $e');
    }
  }
}
