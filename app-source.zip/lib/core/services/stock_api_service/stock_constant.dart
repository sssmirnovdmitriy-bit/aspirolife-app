// Ключ TwelveData больше не хранится в приложении — запросы идут
// через свой бэкенд (см. lib/core/services/backend_constants.dart).
List<String> TICKER_NAMES = [
  'AAPL',
  'MSFT',
  'GOOGL',
  'AMZN',
  'TSLA',
  'NVDA',
  'META',
  'AMD',
];
