class TimeSeriesValue {
  final String datetime;
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;

  TimeSeriesValue({
    required this.datetime,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  factory TimeSeriesValue.fromJson(Map<String, dynamic> json) {
    return TimeSeriesValue(
      datetime: json['datetime'],
      open: double.parse(json['open']),
      high: double.parse(json['high']),
      low: double.parse(json['low']),
      close: double.parse(json['close']),
      volume: int.parse(json['volume']),
    );
  }
}

class TickerTimeSeries {
  final String symbol;
  final List<TimeSeriesValue> values;
  final String status;

  TickerTimeSeries({
    required this.symbol,
    required this.values,
    required this.status,
  });

  factory TickerTimeSeries.fromJson(String symbol, Map<String, dynamic> json) {
    return TickerTimeSeries(
      symbol: symbol,
      values:
          (json['values'] as List)
              .map((e) => TimeSeriesValue.fromJson(e))
              .toList(),
      status: json['status'],
    );
  }
}
