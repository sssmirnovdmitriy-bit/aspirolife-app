import 'package:dio/dio.dart';
import 'package:organizer/core/services/backend_constants.dart';

String ERROR = '';

// AI-запросы идут через наш бэкенд (Railway), а не напрямую в Claude —
// так ключ Anthropic никогда не попадает в собранное приложение.
// Имя класса оставлено прежним, чтобы не трогать вызовы в контроллерах.
class OpenAIService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: BACKEND_BASE_URL,
      headers: {
        'x-app-secret': APP_SHARED_SECRET,
        'Content-Type': 'application/json',
      },
    ),
  );

  //РАСКЛАД НА ДЕНЬ
  Future<String?> fetchTickerInfo(String ticker, int days) async {
    try {
      final response = await _dio.post(
        '/v1/ticker-analysis',
        data: {'ticker': ticker, 'days': days},
      );
      return response.data['text']?.toString();
    } catch (e) {
      ERROR =
          "Мне не удалось обработать вашу ситуацию! Возможно, я не доступен в Вашей стране без VPN";
      return null;
    }
  }

  Future<String?> fetchMissionByBirthday(String dateBirth) async {
    try {
      final response = await _dio.post(
        '/v1/mission',
        data: {'dateBirth': dateBirth},
      );
      return response.data['text']?.toString();
    } catch (e) {
      ERROR =
          "Мне не удалось обработать вашу ситуацию! Возможно, я не доступен в Вашей стране без VPN";
      return null;
    }
  }
}
