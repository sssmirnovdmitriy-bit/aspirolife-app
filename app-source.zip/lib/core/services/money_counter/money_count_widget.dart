import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/services/money_counter/money_count_controller.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';

class MoneyCountWidget extends ConsumerWidget {
  final bool isGoodHabbit;
  const MoneyCountWidget({super.key, required this.isGoodHabbit});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var bhModel = ref.watch(bhController);
    var ghModel = ref.watch(ghController);
    var moneyCountModel = ref.watch(moneyCountController);
    return (bhModel.myActiveBadHabbits.isNotEmpty ||
            ghModel.myActiveGoodHabbits.isNotEmpty)
        ? Container(
          width: MediaQuery.of(context).size.width,

          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      "Ваш доход растет!",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 12,
                      ),
                    ),
                    Spacer(),
                    Container(
                      decoration: BoxDecoration(
                        color: AppConstants.bgColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Text(
                          "+ ${moneyCountModel.currentMonthMoneySavings}/мес",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.darkGreenColor,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Container(
                      decoration: BoxDecoration(
                        color: AppConstants.bgColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Text(
                          "+ ${moneyCountModel.currentYearMoneySavings}/год",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.darkGreenColor,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.94,
                  child: Text(
                    isGoodHabbit
                        ? "При внедрение полезных привычек увеличивается ваш доход"
                        : "При отказе от вредных привычек, Вы начинаете экономить",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.greyColor,
                      fontSize: 10,
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
        : SizedBox();
  }
}
