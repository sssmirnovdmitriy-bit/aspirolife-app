import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';
import 'package:collection/collection.dart';

final moneyCountController = ChangeNotifierProvider(
  ((ref) => MoneyCountController()),
);

class MoneyCountController extends ChangeNotifier {
  String currentMonthMoneySavings = '-';
  String currentYearMoneySavings = '-';

  String currentSavedMoney = '-';

  MoneyCountController() {}

  Future<void> getMyMoneySavings(WidgetRef ref) async {
    var activeHabbits = ref.read(bhController).myActiveBadHabbits;
    int monthSavings = 0;
    int yearSavings = 0;
    int savedMoney = 0;
    if (activeHabbits.isNotEmpty) {
      for (var habbit in activeHabbits) {
        if (habbit.oneValuePrice != null && habbit.habbitUseCount != null) {
          monthSavings += habbit.oneValuePrice! * habbit.habbitUseCount! * 30;
          yearSavings += habbit.oneValuePrice! * habbit.habbitUseCount! * 365;

          final firstCompletedMission = habbit.dailyMissions.firstWhereOrNull(
            (e) => e.isCompleted,
          );

          final startDate = firstCompletedMission?.startDate;
          if (startDate != null) {
            final daysPassed = max(
              1,
              DateTime.now().difference(startDate).inDays,
            );
            savedMoney += habbit.oneValuePrice! * daysPassed;
          }
        }
      }
    }
    currentMonthMoneySavings = monthSavings.toString();
    currentYearMoneySavings = yearSavings.toString();
    currentSavedMoney = savedMoney.toString();
    notifyListeners();
  }
}
