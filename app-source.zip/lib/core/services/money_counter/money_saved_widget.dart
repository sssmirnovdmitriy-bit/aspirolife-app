import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/services/money_counter/money_count_controller.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';

class MoneySavedWidget extends ConsumerWidget {
  const MoneySavedWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var bhModel = ref.watch(bhController);
    var ghModel = ref.watch(ghController);
    var moneyCountModel = ref.watch(moneyCountController);
    return (bhModel.myActiveBadHabbits.isNotEmpty ||
            ghModel.myActiveGoodHabbits.isNotEmpty)
        ? Container(
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            color: AppConstants.secondaryColor.withOpacity(0.6),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(height: 4),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.67,
                  child: Text(
                    "Благодаря отказу от вредных привычек и внедрению полезных, Вы уже заработали эту сумму",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.greyColor,
                      fontSize: 10,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
                Spacer(),
                Container(
                  decoration: BoxDecoration(
                    color: AppConstants.bgColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "+ ${moneyCountModel.currentSavedMoney}",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.darkGreenColor,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
        : SizedBox();
  }
}
