// services/survey_data_service.dart

import 'dart:convert';
import 'package:organizer/feature/lifestyle_screen/data/lifesphere_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SurveyDataService {
  static const String _surveyKey = 'lifestyle_survey_results';
  static const String _selectedSpheresKey = 'selected_spheres';

  // Получение списка всех сфер жизни
  static List<LifeSphere> getLifeSpheres() {
    return [
      LifeSphere(
        id: 1,
        title: 'Физическое состояние',
        emoji: '💪',
        description:
            'Как ты ощущаешь своё тело и уровень энергии в течение дня? Есть ли у тебя силы, живость, ресурс?',
        supportingQuestions: [
          'Как ты ощущаешь своё тело?',
          'Какой у тебя уровень энергии?',
          'Есть ли у тебя силы и живость?',
        ],
      ),
      LifeSphere(
        id: 2,
        title: 'Отношения с собой',
        emoji: '🤗',
        description:
            'Что происходит внутри? Умеешь ли ты быть к себе бережным(ой)? Как ты справляешься с эмоциями, критикуешь ли себя, поддерживаешь? Есть ли в тебе устойчивость и принятие?',
        supportingQuestions: [
          'Умеешь ли быть к себе бережным?',
          'Как справляешься с эмоциями?',
          'Есть ли устойчивость и принятие?',
        ],
      ),
      LifeSphere(
        id: 3,
        title: 'Отношения с партнёром',
        emoji: '💕',
        description:
            'Насколько ты чувствуешь близость, поддержку, открытость в отношениях? Есть ли ощущение «мы» и одновременно свобода быть собой?',
        supportingQuestions: [
          'Чувствуешь ли близость и поддержку?',
          'Есть ли ощущение «мы»?',
          'Можешь ли быть собой в отношениях?',
        ],
      ),
      LifeSphere(
        id: 4,
        title: 'Социальные связи и дружба',
        emoji: '👥',
        description:
            'Есть ли рядом люди, с которыми ты чувствуешь тепло, поддержку, можешь быть собой? Или чувствуешь одиночество, изоляцию?',
        supportingQuestions: [
          'Есть ли рядом поддерживающие люди?',
          'Можешь ли быть собой с друзьями?',
          'Чувствуешь ли одиночество?',
        ],
      ),
      LifeSphere(
        id: 5,
        title: 'Работа и реализация',
        emoji: '🎯',
        description:
            'Насколько ты ощущаешь, что твоя деятельность тебя наполняет, развивает, приносит смысл? Или чувствуешь выгорание, бессмысленность?',
        supportingQuestions: [
          'Наполняет ли тебя твоя деятельность?',
          'Приносит ли работа смысл?',
          'Чувствуешь ли выгорание?',
        ],
      ),
      LifeSphere(
        id: 6,
        title: 'Финансовое положение',
        emoji: '💰',
        description:
            'Насколько ты чувствуешь стабильность, безопасность и свободу в распоряжении деньгами? Есть ли тревога, страх будущего или наоборот — уверенность и покой?',
        supportingQuestions: [
          'Чувствуешь ли финансовую стабильность?',
          'Есть ли тревога о деньгах?',
          'Ощущаешь ли финансовую свободу?',
        ],
      ),
      LifeSphere(
        id: 7,
        title: 'Свободное время и отдых',
        emoji: '🌴',
        description:
            'Есть ли в твоей жизни время на отдых, расслабление, спонтанность, удовольствие? Или ты живёшь в режиме «надо» и не умеешь останавливаться?',
        supportingQuestions: [
          'Есть ли время на отдых?',
          'Умеешь ли расслабляться?',
          'Живёшь ли в режиме "надо"?',
        ],
      ),
      LifeSphere(
        id: 8,
        title: 'Личностный рост и саморазвитие',
        emoji: '🌱',
        description:
            'Как ты ощущаешь своё развитие? Учишься ли новому, ставишь цели, расширяешь горизонты? Или чувствуешь застой и скуку?',
        supportingQuestions: [
          'Ощущаешь ли своё развитие?',
          'Учишься ли новому?',
          'Чувствуешь ли застой?',
        ],
      ),
    ];
  }

  // Сохранение результатов опроса
  static Future<void> saveSurveyResults(LifestyleSurveyResult result) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = jsonEncode(result.toJson());
    await prefs.setString(_surveyKey, jsonString);
  }

  // Получение результатов опроса
  static Future<LifestyleSurveyResult?> getSurveyResults() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_surveyKey);

    if (jsonString != null) {
      final jsonMap = jsonDecode(jsonString);
      return LifestyleSurveyResult.fromJson(jsonMap);
    }

    return null;
  }

  // Сохранение выбранных сфер для работы
  static Future<void> saveSelectedSpheres(List<int> sphereIds) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _selectedSpheresKey,
      sphereIds.map((id) => id.toString()).toList(),
    );
  }

  // Получение выбранных сфер
  static Future<List<int>> getSelectedSpheres() async {
    final prefs = await SharedPreferences.getInstance();
    final stringList = prefs.getStringList(_selectedSpheresKey);

    if (stringList != null) {
      return stringList.map((s) => int.parse(s)).toList();
    }

    return [];
  }

  // Проверка, пройден ли опрос
  static Future<bool> isSurveyCompleted() async {
    final result = await getSurveyResults();
    return result != null;
  }

  // Очистка данных опроса (для тестирования)
  static Future<void> clearSurveyData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_surveyKey);
    await prefs.remove(_selectedSpheresKey);
  }

  // Проверка, нужно ли показать повторный опрос (через месяц)
  static Future<bool> shouldShowRepeatedSurvey() async {
    final result = await getSurveyResults();
    if (result == null) return false;

    final now = DateTime.now();
    final lastSurvey = result.completedAt;
    final difference = now.difference(lastSurvey).inDays;

    return difference >= 30; // Показывать через месяц
  }
}
