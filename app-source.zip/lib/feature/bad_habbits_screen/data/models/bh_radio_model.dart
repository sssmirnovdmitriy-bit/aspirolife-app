import 'package:organizer/core/models/habbit_model.dart';

class BhRadioModel {
  bool isSelected;
  final HabbitModel habbit;

  BhRadioModel(this.isSelected, this.habbit);
}
