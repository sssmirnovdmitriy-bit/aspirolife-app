import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/storages/habbit_database.dart';

final bhController = ChangeNotifierProvider(((ref) => BhController()));

class BhController extends ChangeNotifier {
  List<HabbitModel> myActiveBadHabbits = [];

  BhController() {}

  Future<void> getMyActiveBadHabbits() async {
    myActiveBadHabbits.clear();
    final habbitDatabaseService = HabbitDatabaseService();
    var response = await habbitDatabaseService.getAllHabbits();
    for (var element in response) {
      if (element.isGoodHabbit == false) {
        myActiveBadHabbits.add(element);
      }
    }
    notifyListeners();
  }

  Future<void> deleteHabbit(HabbitModel habbit) async {
    final habbitDatabaseService = HabbitDatabaseService();

    await habbitDatabaseService.deleteHabbitById(habbit.id!);

    await getMyActiveBadHabbits();
  }

  Future<void> confirmMission(
    BuildContext context,
    DailyMission mission,
    HabbitModel habbit,
  ) async {
    final habbitDatabaseService = HabbitDatabaseService();

    if (mission.isCompleted) {
      // если уже выполнена → отменяем
      await habbitDatabaseService.uncompleteMission(mission);
    } else {
      // если не выполнена → подтверждаем
      AppNotifications.showSuccess(context, "Миссия выполнена - так держать!");
      await habbitDatabaseService.completeMission(mission);
      await updateStreak(habbit, DateTime.now());
    }

    await getMyActiveBadHabbits();
  }

  Future<void> updateStreak(
    HabbitModel habbitModel,
    DateTime currentDate,
  ) async {
    int newStreak = 0;
    bool streakBroken = false;

    // Проверяем все DailyMission для текущей привычки
    for (final mission in habbitModel.dailyMissions) {
      final missionDate = mission.startDate;

      if (missionDate != null &&
          missionDate.isBefore(currentDate) &&
          !mission.isCompleted) {
        streakBroken =
            true; // Если миссия не выполнена до текущей даты, стрик обнуляется
        break;
      }

      // Если миссия выполнена и в пределах текущего дня
      if (missionDate != null &&
          missionDate.isBefore(currentDate) &&
          mission.isCompleted) {
        newStreak++;
      }
    }

    // Если стрик был сломан, обнуляем его
    if (streakBroken) {
      newStreak = 0;
    }

    // Обновляем стрик для конкретной привычки
    habbitModel.streak = newStreak;

    // Обновляем информацию в базе данных о текущем стрике
    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.updateHabbitStreakInDB(habbitModel);
    await getMyActiveBadHabbits();
  }
}
