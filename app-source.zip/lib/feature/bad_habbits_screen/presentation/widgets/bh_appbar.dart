import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/widgets/add_bh_button.dart';

class BhAppbar extends StatelessWidget {
  const BhAppbar({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "Плохие привычки",
          style: GoogleFonts.unbounded(
            color: AppConstants.whiteColor,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
        AddBHButton(),
      ],
    );
  }
}
