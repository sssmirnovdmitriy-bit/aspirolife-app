import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/animated_gradient_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/purchase/pay_controller.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';

class AddBHButton extends ConsumerWidget {
  const AddBHButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasSubscription = ref.watch(payController).hasSubscription;
    final bhModel = ref.watch(bhController);
    final shouldShowLock =
        !hasSubscription && bhModel.myActiveBadHabbits.length >= 2;

    return AnimatedButton(
      onTap: () async {
        if (hasSubscription) {
          Navigation.goToAddBhScreen(context);
        } else {
          if (bhModel.myActiveBadHabbits.length < 2) {
            Navigation.goToAddBhScreen(context);
          } else {
            AppNotifications.showError(
              context,
              "Чтобы добавить больше 2 привычек нужна подписка Pro",
            );
          }
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color: AppConstants.bgGreyColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (shouldShowLock) ...[
                Icon(Icons.lock, color: AppConstants.darkGreenColor, size: 16),
                SizedBox(width: 4),
              ],
              Text(
                "Добавить",
                style: GoogleFonts.unbounded(
                  color: AppConstants.darkGreenColor,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
