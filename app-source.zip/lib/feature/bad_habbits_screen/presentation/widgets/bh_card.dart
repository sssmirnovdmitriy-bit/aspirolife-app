import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/animated_gradient_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/countdown_text.dart';
import 'package:organizer/components/typewritter_widget.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';

class BhCard extends ConsumerWidget {
  final HabbitModel habbitModel;
  final void Function()? onTap;
  final void Function()? onTapStats;
  const BhCard({
    super.key,
    required this.habbitModel,
    this.onTap,
    this.onTapStats,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentDate = DateTime.now();

    // Вычисляем количество дней, прошедших с начала привычки
    final duration = currentDate.difference(habbitModel.startDate!);
    final dayIndex = duration.inDays;

    // Получаем миссию для текущего дня
    final missionForToday =
        dayIndex < habbitModel.dailyMissions.length
            ? habbitModel.dailyMissions[dayIndex]
            : habbitModel.dailyMissions.last;

    return Slidable(
      endActionPane: ActionPane(
        motion: BehindMotion(),
        children: [
          SlidableAction(
            borderRadius: BorderRadius.circular(4),
            onPressed: (context) async {
              await ref.read(bhController).deleteHabbit(habbitModel);
            },
            backgroundColor: Colors.transparent,
            foregroundColor: Colors.red,
            icon: Icons.delete_rounded,
            label: "удалить",
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: AppConstants.secondaryColor.withOpacity(0.6),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(10),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: AppConstants.bgColor,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Icon(
                            AppConstants.getHabitIcon(
                              habbitModel.habbitType,
                              isGood: false,
                            ),
                            size: 18,
                            color: AppConstants.darkGreenColor,
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            habbitModel.habbitName,
                            style: GoogleFonts.unbounded(
                              color: AppConstants.whiteColor,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          Text(
                            "отслеживается: ${AppConstants().pluralizeDays(DateTime.now().difference(habbitModel.startDate!).inDays + 1)}",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.greyColor,
                              fontSize: 9,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      (missionForToday.textInfo != null ||
                              missionForToday.videoUrl != null)
                          ? SizedBox(width: 8)
                          : SizedBox(),
                      (missionForToday.textInfo != null ||
                              missionForToday.videoUrl != null)
                          ? AnimatedButton(
                            onTap: onTap,
                            child: Container(
                              decoration: BoxDecoration(
                                color: AppConstants.bgGreyColor,
                                shape: BoxShape.circle,
                              ),
                              child: const Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Icon(
                                  Icons.arrow_forward,
                                  color: AppConstants.whiteColor,
                                ),
                              ),
                            ),
                          )
                          : SizedBox(),
                    ],
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(
                    left: 8.0,
                    right: 8,
                    bottom: 8,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Задача на сегодня:",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.greyColor,
                          fontSize: 10,
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "○",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.darkGreenColor,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(width: 8),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.85,
                            child: Text(
                              textAlign: TextAlign.start,
                              missionForToday.missionText,
                              style: GoogleFonts.unbounded(
                                color: AppConstants.darkGreenColor,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Padding(
                //   padding: const EdgeInsets.all(8.0),
                //   child: Row(
                //     crossAxisAlignment: CrossAxisAlignment.center,
                //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //     children: [
                //       SizedBox(
                //         width: MediaQuery.of(context).size.width * 0.5,
                //         child: Text(
                //           "Подтвердите активность привычки ",
                //           style: GoogleFonts.unbounded(
                //             color: AppConstants.whiteColor,
                //             fontSize: 12,
                //           ),
                //         ),
                //       ),
                //       if (!currentMission.isCompleted)
                //         Padding(
                //           padding: const EdgeInsets.all(8.0),
                //           child: AnimatedButton(
                //             onTap: () async {
                //               await ref
                //                   .read(bhController)
                //                   .confirmMission(currentMission, habbitModel);
                //               await ref
                //                   .read(moneyCountController)
                //                   .getMyMoneySavings(ref);
                //             },
                //             child: Container(
                //               decoration: BoxDecoration(
                //                 color: AppConstants.darkGreenColor,
                //                 borderRadius: BorderRadius.circular(20),
                //               ),
                //               child: Padding(
                //                 padding: const EdgeInsets.all(10.0),
                //                 child: Text(
                //                   "Подтвердить",
                //                   style: GoogleFonts.unbounded(
                //                     color: AppConstants.bgColor,
                //                   ),
                //                 ),
                //               ),
                //             ),
                //           ),
                //         ),
                //
                //     ],
                //   ),
                // ),
              ],
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 30, 29, 29),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10),
                bottomRight: Radius.circular(10),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: AnimatedButton(
                onTap: onTapStats,
                child: Padding(
                  padding: EdgeInsets.all(4.0),
                  child: Row(
                    children: [
                      Icon(
                        Icons.stacked_bar_chart,
                        color: AppConstants.greyColor,
                        size: 16,
                      ),
                      SizedBox(width: 10),
                      Text(
                        "Посмотреть аналитику",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.greyColor,
                          fontSize: 10,
                        ),
                      ),
                      Spacer(),
                      Icon(
                        Icons.arrow_forward,
                        color: AppConstants.greyColor,
                        size: 16,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
