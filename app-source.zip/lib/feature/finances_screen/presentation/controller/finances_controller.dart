import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/core/models/book_model.dart';
import 'package:organizer/core/models/investment_model.dart';
import 'package:organizer/core/models/trade_model.dart';
import 'package:organizer/core/models/transaction_item_model.dart';
import 'package:organizer/core/models/video_model.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/services/gpt_service/gpt_service.dart';
import 'package:organizer/core/services/stock_api_service/stock_constant.dart';
import 'package:organizer/core/services/stock_api_service/stock_service.dart';
import 'package:organizer/core/services/stock_api_service/ticker_model.dart';
import 'package:organizer/core/storages/book_database.dart';
import 'package:organizer/core/storages/investment_database.dart';
import 'package:organizer/core/storages/mock_videos.dart';
import 'package:organizer/core/storages/portfolio_database.dart';
import 'package:organizer/core/storages/trade_database.dart';
import 'package:organizer/core/storages/transaction_database.dart';
import 'package:organizer/core/storages/video_database.dart';
import 'package:organizer/feature/finances_screen/data/models/investment_radiomodel.dart';
import 'package:organizer/feature/finances_screen/data/models/portfolio_model.dart';
import 'package:organizer/feature/finances_screen/data/models/ticker_radiomodel.dart';

final financesController = ChangeNotifierProvider(
  ((ref) => FinancesController()),
);

class FinancesController extends ChangeNotifier {
  List<TransactionItem> incomes = [];
  List<TransactionItem> expenses = [];
  List<TransactionItem> investments = [];

  List<InvestmentModel> realInvestmentsActive = [];
  List<InvestmentModel> realInvestmentsPassive = [];
  List<InvestmentModel> realInvestmentsIncome = [];
  List<InvestmentModel> realInvestmentsExpense = [];
  double investmentSummary = 0;

  List<TradeModel> trades = [];

  List<BookModel> mergedBooks = [];
  List<BookModel> readBooks = [];

  List<VideoModel> videos = [];

  List<TickerTimeSeries> tickers = [];

  List<PortfolioModel> portfolios = [];

  double sumIncome = 0;
  double sumExpenses = 0;

  TickerRadioModel? chosenTicker;
  List<TickerRadioModel> myTickers = [
    TickerRadioModel(false, TICKER_NAMES[0]),
    TickerRadioModel(false, TICKER_NAMES[1]),
    TickerRadioModel(false, TICKER_NAMES[2]),
    TickerRadioModel(false, TICKER_NAMES[3]),
    TickerRadioModel(false, TICKER_NAMES[4]),
    TickerRadioModel(false, TICKER_NAMES[5]),
    TickerRadioModel(false, TICKER_NAMES[6]),
    TickerRadioModel(false, TICKER_NAMES[7]),
  ];

  String? aiAnswer;

  void chooseTicker(TickerRadioModel tickerModel) {
    chosenTicker = tickerModel;
    notifyListeners();
  }

  InvestmentRadiomodel? chosenInvestmentType;
  List<InvestmentRadiomodel> myInsvestmentTypes = [
    InvestmentRadiomodel(false, InvestmentItemType.ACTIVE.name, "Актив"),
    InvestmentRadiomodel(false, InvestmentItemType.PASSIVE.name, "Пассив"),
    InvestmentRadiomodel(false, InvestmentItemType.INCOME.name, "Приход"),
    InvestmentRadiomodel(false, InvestmentItemType.EXPENSE.name, "Расход"),
  ];

  void chooseInvestmentType(InvestmentRadiomodel investRadioModel) {
    chosenInvestmentType = investRadioModel;
    notifyListeners();
  }

  FinancesController() {
    readTransactions();
  }

  Future<void> addPortfolio(
    BuildContext context,
    PortfolioModel portfolio,
  ) async {
    await PortfolioDatabase().upsertOrMergePortfolio(portfolio);
    await getPortfolios();
    Navigation.goBack(context);
  }

  Future<void> getPortfolios() async {
    portfolios = await PortfolioDatabase().getAllPortfolios();
    notifyListeners();
  }

  Future<void> getTickers() async {
    tickers = await StockService().getTickerPrices();
    notifyListeners();
  }

  Future<void> addTransaction(String text, double value, String type) async {
    sumIncome = 0;
    sumExpenses = 0;
    var transaction = TransactionItem(text: text, value: value, type: type);

    await TransactionDatabase.instance.create(transaction);

    incomes = await TransactionDatabase.instance.readIncomes();
    expenses = await TransactionDatabase.instance.readExpenses();
    investments = await TransactionDatabase.instance.readInvestments();

    for (var element in incomes) {
      sumIncome += element.value;
    }

    for (var element in expenses) {
      sumExpenses += element.value;
    }

    notifyListeners();
  }

  Future<void> readTransactions() async {
    sumIncome = 0;
    sumExpenses = 0;
    incomes = await TransactionDatabase.instance.readIncomes();
    expenses = await TransactionDatabase.instance.readExpenses();
    investments = await TransactionDatabase.instance.readInvestments();

    for (var element in incomes) {
      sumIncome += element.value;
    }

    for (var element in expenses) {
      sumExpenses += element.value;
    }

    notifyListeners();
  }

  Future<void> addTrade(
    BuildContext context,
    String ticker,
    bool isBuy,
    double price1,
    double price2,
    double commision,
  ) async {
    double grossResult = isBuy ? (price2 - price1) : (price1 - price2);
    double netResult = grossResult - commision;

    var trade = TradeModel(
      tickerName: ticker,
      isBuy: isBuy,
      price1: price1,
      price2: price2,
      commision: commision,
      result: netResult,
    );

    await TradeDatabase().insertTrade(trade);
    await readTrades();
    Navigation.goBack(context);
  }

  Future<void> readTrades() async {
    trades = await TradeDatabase().getAllTrades();
    notifyListeners();
  }

  Future<void> askGPT(String ticker, int days) async {
    aiAnswer = null;
    aiAnswer = await OpenAIService().fetchTickerInfo(ticker, days);
    notifyListeners();
  }

  Future<void> addInvestment(String text, double value, String type) async {
    realInvestmentsActive.clear();
    realInvestmentsPassive.clear();
    realInvestmentsIncome.clear();
    realInvestmentsExpense.clear();
    var investement = InvestmentModel(text: text, value: value, type: type);

    await InvestmentDatabase().insertInvestment(investement);

    await readRealInvestments();
  }

  Future<void> readRealInvestments() async {
    realInvestmentsActive.clear();
    realInvestmentsPassive.clear();
    realInvestmentsIncome.clear();
    realInvestmentsExpense.clear();

    var realInvestments = await InvestmentDatabase().getAllInvestments();

    for (var element in realInvestments) {
      if (element.type == InvestmentItemType.ACTIVE.name) {
        realInvestmentsActive.add(element);
      } else if (element.type == InvestmentItemType.PASSIVE.name) {
        realInvestmentsPassive.add(element);
      } else if (element.type == InvestmentItemType.INCOME.name) {
        realInvestmentsIncome.add(element);
      } else if (element.type == InvestmentItemType.EXPENSE.name) {
        realInvestmentsExpense.add(element);
      }
    }

    double sumList(List<InvestmentModel> list) =>
        list.fold(0.0, (prev, element) => prev + element.value);

    investmentSummary =
        sumList(realInvestmentsActive) +
        sumList(realInvestmentsIncome) -
        sumList(realInvestmentsPassive) -
        sumList(realInvestmentsExpense);

    notifyListeners();
  }

  void showAddIncomeTransactionSheet(
    BuildContext context,
    Function(String, double, String) onSave,
  ) {
    final TextEditingController textController = TextEditingController();
    final TextEditingController valueController = TextEditingController();

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Добавить доход",
                style: GoogleFonts.unbounded(color: AppConstants.whiteColor),
              ),
              SizedBox(height: 20),
              Text(
                "Откуда доход?",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                controller: textController,
                hintText: "Например, основная работа",
                onChanged: (value) {},
              ),

              SizedBox(height: 20),
              Text(
                "Сумма дохода",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                keyboard: TextInputType.number,
                controller: valueController,
                hintText: "Например, 100000",
                onChanged: (value) {},
              ),

              SizedBox(height: 20),

              AnimatedButton(
                onTap: () {
                  final text = textController.text.trim();
                  final value = double.tryParse(valueController.text) ?? 0.0;

                  if (text.isNotEmpty && value != 0.0) {
                    onSave(text, value, TransactionItemType.INCOME.name);
                    Navigator.of(context).pop();
                  }
                },
                child: Container(
                  height: 44,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: AppConstants.bgGreyColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Center(
                      child: Text(
                        "Добавить",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.darkGreenColor,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
            ],
          ),
        );
      },
    );
  }

  void showAddExpenseTransactionSheet(
    BuildContext context,
    Function(String, double, String) onSave,
  ) {
    final TextEditingController textController = TextEditingController();
    final TextEditingController valueController = TextEditingController();

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Добавить расход",
                style: GoogleFonts.unbounded(color: AppConstants.whiteColor),
              ),
              SizedBox(height: 20),
              Text(
                "На что уходит?",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                controller: textController,
                hintText: "Например, подписка на музыку",
                onChanged: (value) {},
              ),

              SizedBox(height: 20),
              Text(
                "Сумма расхода",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                keyboard: TextInputType.number,
                controller: valueController,
                hintText: "Например, 100000",
                onChanged: (value) {},
              ),

              SizedBox(height: 20),

              AnimatedButton(
                onTap: () {
                  final text = textController.text.trim();
                  final value = double.tryParse(valueController.text) ?? 0.0;

                  if (text.isNotEmpty && value != 0.0) {
                    onSave(text, value, TransactionItemType.EXPENSE.name);
                    Navigator.of(context).pop();
                  }
                },
                child: Container(
                  height: 44,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: AppConstants.bgGreyColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Center(
                      child: Text(
                        "Добавить",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.darkGreenColor,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
            ],
          ),
        );
      },
    );
  }

  void showAddInvestmentTransactionSheet(
    BuildContext context,
    Function(String, double, String) onSave,
  ) {
    final TextEditingController textController = TextEditingController();
    final TextEditingController valueController = TextEditingController();

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Добавить инвестицию",
                style: GoogleFonts.unbounded(color: AppConstants.whiteColor),
              ),
              SizedBox(height: 20),
              Text(
                "Куда инвестируете?",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                controller: textController,
                hintText: "Например, акции",
                onChanged: (value) {},
              ),

              SizedBox(height: 20),
              Text(
                "Сумма инвестиций",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                keyboard: TextInputType.number,
                controller: valueController,
                hintText: "Например, 100000",
                onChanged: (value) {},
              ),

              SizedBox(height: 20),

              AnimatedButton(
                onTap: () {
                  final text = textController.text.trim();
                  final value = double.tryParse(valueController.text) ?? 0.0;

                  if (text.isNotEmpty && value != 0.0) {
                    onSave(text, value, TransactionItemType.INVESTMENT.name);
                    Navigator.of(context).pop();
                  }
                },
                child: Container(
                  height: 44,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: AppConstants.bgGreyColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Center(
                      child: Text(
                        "Добавить",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.darkGreenColor,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
            ],
          ),
        );
      },
    );
  }

  void showAddRealInvestmentTransactionSheet(
    BuildContext context,
    Function(String, double, String) onSave,
  ) {
    final TextEditingController textController = TextEditingController();
    final TextEditingController valueController = TextEditingController();

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(ctx).viewInsets.bottom,
                left: 16,
                right: 16,
                top: 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Добавить инвестицию",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                    ),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Выберите тип",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(height: 8),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.06,
                    child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: myInsvestmentTypes.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                for (var element in myInsvestmentTypes) {
                                  element.isSelected = false;
                                }
                                myInsvestmentTypes[index].isSelected = true;
                                chooseInvestmentType(myInsvestmentTypes[index]);
                              });
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(right: 4.0),
                              child: InvestmentTypeRadioItem(
                                myInsvestmentTypes[index],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    "На что уходит?",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(height: 4),
                  TextInputField(
                    radius: 10,
                    height: 44,
                    controller: textController,
                    hintText: "Например, акции",
                    onChanged: (value) {},
                  ),

                  SizedBox(height: 20),
                  Text(
                    "Сумма инвестиции",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(height: 4),
                  TextInputField(
                    radius: 10,
                    height: 44,
                    keyboard: TextInputType.number,
                    controller: valueController,
                    hintText: "Например, 100000",
                    onChanged: (value) {},
                  ),

                  SizedBox(height: 20),

                  AnimatedButton(
                    onTap: () {
                      final text = textController.text.trim();
                      final value =
                          double.tryParse(valueController.text) ?? 0.0;

                      if (text.isNotEmpty &&
                          value != 0.0 &&
                          chosenInvestmentType != null) {
                        onSave(text, value, chosenInvestmentType!.type);
                        Navigator.of(context).pop();
                      }
                    },
                    child: Container(
                      height: 44,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: AppConstants.bgGreyColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(
                          child: Text(
                            "Добавить",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.darkGreenColor,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> makeBookRead(BookModel book) async {
    BookModel newBook = BookModel(
      text: book.text,
      description: book.description,
      isRead: true,
    );
    await BookDatabase.instance.create(newBook);

    await getBooks();
  }

  Future<void> getBooks() async {
    List<BookModel> allBooks = AppConstants().books;

    List<BookModel> readBooksFromDB =
        await BookDatabase.instance.readReadBooks();

    List<BookModel> toMergeBooks =
        allBooks.map((book) {
          // Ищем прочитанную версию книги с таким же id
          final readBook = readBooksFromDB.firstWhere(
            (b) => b.text == book.text,
            orElse: () => book,
          );
          return readBook;
        }).toList();

    mergedBooks = toMergeBooks;
    readBooks = readBooksFromDB;
    notifyListeners();
  }

  Future<void> makeVideoWatched(VideoModel video) async {
    video.isWatched = true;
    video.watchedDate = DateTime.now();
    await VideoDatabase().updateVideo(video);

    await getVideos();
  }

  Future<void> getVideos() async {
    videos = await VideoDatabase().getAllVideos();
    notifyListeners();
  }

  Future<void> firstInitFinancesVideos() async {
    await getVideos();
    if (videos.isEmpty) {
      for (var video in mockFinanceVideos) {
        await VideoDatabase().insertVideo(video);
      }
      await getVideos();
    }
  }
}
