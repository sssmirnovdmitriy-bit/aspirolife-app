import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/purchase/pay_controller.dart';

class FinancesGPTSection extends ConsumerWidget {
  const FinancesGPTSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasSubscription = ref.watch(payController).hasSubscription;
    return AnimatedButton(
      onTap: () {
        if (hasSubscription) {
          Navigation.goToAiTickerScreen(context);
        } else {
          AppNotifications.showError(context, "Необходима подписка Pro");
        }
      },
      child: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: AppConstants.secondaryColor.withOpacity(0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.equalizer_rounded,
                        color: AppConstants.darkGreenColor,
                      ),
                      SizedBox(width: 4),
                      Text(
                        "Прогноз от ИИ",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 40,
                        height: 40,
                        child: LottieBuilder.asset(
                          AppConstants.messageAnim,
                          animate: true,
                        ),
                      ),
                      SizedBox(width: 10),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.7,
                        child: Text(
                          "Куда пойдет AAPL? Сколько будет стоить TSLA? Анализ от ИИ",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.darkGreenColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            hasSubscription
                ? Icon(Icons.arrow_forward_ios_rounded)
                : Icon(
                  Icons.lock,
                  size: 18,
                  color: AppConstants.darkGreenColor,
                ),
          ],
        ),
      ),
    );
  }
}
