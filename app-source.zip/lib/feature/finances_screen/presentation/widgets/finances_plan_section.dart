import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/neon_expense_chart.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';

class FinancesPlanSection extends ConsumerStatefulWidget {
  const FinancesPlanSection({super.key});

  @override
  _FinancesPlanSectionState createState() => _FinancesPlanSectionState();
}

class _FinancesPlanSectionState extends ConsumerState<FinancesPlanSection> {
  bool timePeriodMonth = true;

  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);
    return Container(
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: AppConstants.secondaryColor.withOpacity(0.6),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: [
                SizedBox(height: 10),
                Text(
                  "ваш доход:",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontSize: 14,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    (financesModel.sumIncome.round() -
                                financesModel.sumExpenses.round()) <=
                            0
                        ? Icon(Icons.arrow_drop_down_rounded, color: Colors.red)
                        : Icon(
                          Icons.arrow_drop_up_rounded,
                          color: AppConstants.darkGreenColor,
                        ),
                    Text(
                      timePeriodMonth
                          ? "${financesModel.sumIncome.round() - financesModel.sumExpenses.round()}/мес"
                          : "${(financesModel.sumIncome.round() - financesModel.sumExpenses.round()) * 12}/год",
                      style: GoogleFonts.unbounded(
                        color:
                            (financesModel.sumIncome.round() -
                                        financesModel.sumExpenses.round()) <=
                                    0
                                ? Colors.red
                                : AppConstants.darkGreenColor,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 10),
                  ],
                ),

                SizedBox(height: 14),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.7,
                        height: 44,
                        child: NeonYearlySavingsChart(isMinus: false),
                      ),
                      Spacer(),
                      AnimatedButton(
                        onTap: () {
                          setState(() {
                            timePeriodMonth = true;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color:
                                timePeriodMonth
                                    ? AppConstants.darkGreenColor
                                    : AppConstants.bgColor,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(
                              left: 10,
                              right: 10,
                              bottom: 4,
                              top: 4,
                            ),
                            child: Text(
                              "M",
                              style: TextStyle(
                                color:
                                    timePeriodMonth
                                        ? AppConstants.bgColor
                                        : AppConstants.whiteColor,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      AnimatedButton(
                        onTap: () {
                          setState(() {
                            timePeriodMonth = false;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color:
                                !timePeriodMonth
                                    ? AppConstants.darkGreenColor
                                    : AppConstants.bgColor,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(
                              left: 10,
                              right: 10,
                              bottom: 4,
                              top: 4,
                            ),
                            child: Text(
                              "Y",
                              style: TextStyle(
                                color:
                                    !timePeriodMonth
                                        ? AppConstants.bgColor
                                        : AppConstants.whiteColor,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                (financesModel.sumIncome.round() -
                            financesModel.sumExpenses.round()) <=
                        0
                    ? Text(
                      "Ваши доходы не превышают расходы",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 10,
                      ),
                    )
                    : Text(
                      "Отлично, ваши доходы превышают расходы",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 10,
                      ),
                    ),

                SizedBox(height: 14),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.45,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          "Доходы",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.45,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          "Расходы",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.45,
                        decoration: BoxDecoration(
                          color: AppConstants.darkGreenColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: SizedBox(
                          height: 44,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.arrow_drop_up_rounded,
                                color: AppConstants.darkGreenColor,
                              ),
                              Text(
                                financesModel.sumIncome.round().toString(),
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.darkGreenColor,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 10),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.45,
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: SizedBox(
                          height: 44,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.arrow_drop_down_rounded,
                                color: Colors.red,
                              ),
                              Text(
                                financesModel.sumExpenses.round().toString(),
                                style: GoogleFonts.unbounded(
                                  color: Colors.red,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 10),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 8),
                AnimatedButton(
                  onTap: () async {
                    Navigation.goToPlanScreen(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8),
                    child: Container(
                      height: 44,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: AppConstants.bgGreyColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(
                          child: Text(
                            "Добавить",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.darkGreenColor,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 8),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
