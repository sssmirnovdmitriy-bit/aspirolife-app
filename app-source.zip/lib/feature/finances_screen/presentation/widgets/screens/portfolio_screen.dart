import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';

class PortfolioScreen extends ConsumerStatefulWidget {
  const PortfolioScreen({super.key});

  @override
  _PortfolioScreenState createState() => _PortfolioScreenState();
}

class _PortfolioScreenState extends ConsumerState<PortfolioScreen> {
  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 30),
        child: AnimatedButton(
          onTap: () {
            Navigation.goToAddPortfolioScreen(context);
          },
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: AppConstants.darkGreenColor,
            ),
            child: Center(
              child: Text(
                "+ добавить",
                style: GoogleFonts.unbounded(
                  color: AppConstants.bgColor,
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor.withOpacity(0.5),
                AppConstants.bgGreyColor.withOpacity(0.3),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8),
            child: ListView(
              physics: NeverScrollableScrollPhysics(),
              children: [
                CustomAppBar(text: "Портфель"),
                SizedBox(height: 20),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.84,
                  height: 44,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: financesModel.tickers.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppConstants.bgGreyColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                Text(
                                  financesModel.tickers[index].symbol,
                                  style: GoogleFonts.unbounded(
                                    color:
                                        financesModel
                                                    .tickers[index]
                                                    .values
                                                    .first
                                                    .close <
                                                financesModel
                                                    .tickers[index]
                                                    .values
                                                    .last
                                                    .close
                                            ? Colors.red
                                            : AppConstants.darkGreenColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                                Text(
                                  "\$${financesModel.tickers[index].values.last.close.toStringAsFixed(1)}",
                                  style: GoogleFonts.unbounded(
                                    color: AppConstants.whiteColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(8),
                  child: SizedBox(
                    height: MediaQuery.of(context).size.height * 0.7,
                    child: DataTable2(
                      columnSpacing: 8,
                      horizontalMargin: 0,
                      minWidth: 420,
                      columns: [
                        DataColumn2(label: Text('Тикер'), size: ColumnSize.S),
                        DataColumn2(
                          label: Text('Количество'),
                          numeric: true,
                          size: ColumnSize.S,
                        ),
                        DataColumn(label: Text('Ср. цена'), numeric: true),
                        DataColumn(
                          label: Text('Общая стоимость'),
                          numeric: true,
                        ),
                        DataColumn(label: Text('Цена'), numeric: true),
                        DataColumn2(
                          label: Text('Процент изменения'),
                          numeric: true,
                          size: ColumnSize.S,
                        ),
                      ],
                      rows:
                          financesModel.portfolios.map((portfolio) {
                            return DataRow(
                              cells: [
                                DataCell(Text(portfolio.tickerName)),
                                DataCell(
                                  Text(portfolio.stocksCount.toString()),
                                ),
                                DataCell(
                                  Text(
                                    portfolio.averagePrice == null
                                        ? portfolio.price.toStringAsFixed(2)
                                        : portfolio.averagePrice!
                                            .toStringAsFixed(2),
                                  ),
                                ),
                                DataCell(
                                  Text(portfolio.totalPrice.toStringAsFixed(2)),
                                ),
                                DataCell(
                                  Text(portfolio.price.toStringAsFixed(2)),
                                ),
                                DataCell(
                                  Text(
                                    '${portfolio.percent.toStringAsFixed(2)}%',
                                    style: TextStyle(
                                      color:
                                          portfolio.percent > 0
                                              ? AppConstants.darkGreenColor
                                              : Colors.red,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          }).toList(),
                    ),
                  ),
                ),
                // ListView.builder(
                //   padding: EdgeInsets.zero,
                //   itemCount: financesModel.trades.length,
                //   shrinkWrap: true,
                //   physics: NeverScrollableScrollPhysics(),
                //   itemBuilder: (context, index) {
                //     return Padding(
                //       padding: const EdgeInsets.only(bottom: 8.0),
                //       child: Container(
                //         decoration: BoxDecoration(
                //           color: AppConstants.secondaryColor.withOpacity(0.6),
                //           borderRadius: BorderRadius.circular(10),
                //         ),
                //         child: Padding(
                //           padding: const EdgeInsets.all(8.0),
                //           child: Row(
                //             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                //             children: [
                //               Container(
                //                 height: 6,
                //                 width: 6,
                //                 decoration: BoxDecoration(
                //                   shape: BoxShape.circle,
                //                   color:
                //                       financesModel.trades[index].isBuy
                //                           ? AppConstants.darkGreenColor
                //                           : Colors.red,
                //                 ),
                //               ),
                //               SizedBox(width: 4),
                //               SizedBox(
                //                 width: MediaQuery.of(context).size.width * 0.14,
                //                 child: Row(
                //                   children: [
                //                     Text(
                //                       financesModel.trades[index].tickerName,
                //                       style: GoogleFonts.unbounded(
                //                         fontSize: 11,
                //                         fontWeight: FontWeight.bold,
                //                         color: AppConstants.whiteColor,
                //                       ),
                //                     ),
                //                   ],
                //                 ),
                //               ),
                //               SizedBox(
                //                 width: MediaQuery.of(context).size.width * 0.14,
                //                 child: Row(
                //                   mainAxisAlignment: MainAxisAlignment.end,
                //                   children: [
                //                     Text(
                //                       financesModel.trades[index].price1
                //                           .toStringAsFixed(0),
                //                       style: GoogleFonts.unbounded(
                //                         fontSize: 11,
                //                         fontWeight: FontWeight.bold,
                //                         color: AppConstants.whiteColor,
                //                       ),
                //                     ),
                //                   ],
                //                 ),
                //               ),
                //               SizedBox(
                //                 width: MediaQuery.of(context).size.width * 0.14,
                //                 child: Row(
                //                   mainAxisAlignment: MainAxisAlignment.end,
                //                   children: [
                //                     Text(
                //                       financesModel.trades[index].price2
                //                           .toStringAsFixed(0),
                //                       style: GoogleFonts.unbounded(
                //                         fontSize: 11,
                //                         fontWeight: FontWeight.bold,
                //                         color: AppConstants.whiteColor,
                //                       ),
                //                     ),
                //                   ],
                //                 ),
                //               ),
                //               SizedBox(
                //                 width: MediaQuery.of(context).size.width * 0.22,
                //                 child: Row(
                //                   mainAxisAlignment: MainAxisAlignment.end,
                //                   children: [
                //                     Text(
                //                       financesModel.trades[index].commision
                //                           .toStringAsFixed(0),
                //                       style: GoogleFonts.unbounded(
                //                         fontSize: 11,
                //                         fontWeight: FontWeight.bold,
                //                         color: AppConstants.whiteColor,
                //                       ),
                //                     ),
                //                   ],
                //                 ),
                //               ),
                //               SizedBox(width: 4),
                //               SizedBox(
                //                 width: MediaQuery.of(context).size.width * 0.22,
                //                 child: Row(
                //                   mainAxisAlignment: MainAxisAlignment.end,
                //                   children: [
                //                     Text(
                //                       financesModel.trades[index].result!
                //                           .round()
                //                           .toString(),
                //                       style: GoogleFonts.unbounded(
                //                         fontSize: 11,
                //                         fontWeight: FontWeight.bold,
                //                         color:
                //                             financesModel.trades[index].result! >
                //                                     0
                //                                 ? AppConstants.darkGreenColor
                //                                 : Colors.red,
                //                       ),
                //                     ),
                //                   ],
                //                 ),
                //               ),
                //             ],
                //           ),
                //         ),
                //       ),
                //     );
                //   },
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
