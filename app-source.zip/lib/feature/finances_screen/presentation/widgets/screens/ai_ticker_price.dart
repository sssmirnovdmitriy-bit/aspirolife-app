import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/components/typewritter_widget.dart';
import 'package:organizer/core/services/gpt_service/gpt_service.dart';
import 'package:organizer/feature/finances_screen/data/models/ticker_radiomodel.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';

class AiTickerPriceScreen extends ConsumerStatefulWidget {
  const AiTickerPriceScreen({super.key});

  @override
  _AiTickerPriceScreenState createState() => _AiTickerPriceScreenState();
}

class _AiTickerPriceScreenState extends ConsumerState<AiTickerPriceScreen> {
  bool isLoading = false;

  TextEditingController daysController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var tickerModel = ref.watch(financesController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  CustomAppBar(text: "ИИ анализ"),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Text(
                        "Выберите тикер*",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.08,
                    width: MediaQuery.of(context).size.width,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: tickerModel.myTickers.length,
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                for (var element in tickerModel.myTickers) {
                                  element.isSelected = false;
                                }
                                tickerModel.myTickers[index].isSelected = true;
                                ref
                                    .read(financesController)
                                    .chooseTicker(tickerModel.myTickers[index]);
                              });
                            },
                            child: TypeRadioItem(tickerModel.myTickers[index]),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Text(
                        "Количество дней инвестирования*",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  TextInputField(
                    radius: 10,
                    height: 44,
                    keyboard: TextInputType.numberWithOptions(),
                    controller: daysController,
                    hintText: "Например, 30",
                    onChanged: (value) {
                      setState(() {});
                    },
                  ),
                  SizedBox(height: 10),
                  AnimatedButton(
                    onTap: () async {
                      if (tickerModel.chosenTicker != null &&
                          daysController.text.isNotEmpty) {
                        setState(() {
                          isLoading = true;
                        });
                        await ref
                            .read(financesController)
                            .askGPT(
                              tickerModel.chosenTicker!.name,
                              int.parse(daysController.text),
                            );
                        setState(() {
                          isLoading = false;
                        });
                      }
                    },
                    child: Container(
                      height: 44,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: AppConstants.bgGreyColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(
                          child:
                              isLoading
                                  ? SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 1,
                                      color: AppConstants.darkGreenColor,
                                    ),
                                  )
                                  : Text(
                                    "Провести анализ",
                                    style: GoogleFonts.unbounded(
                                      color:
                                          (tickerModel.chosenTicker != null &&
                                                  daysController
                                                      .text
                                                      .isNotEmpty)
                                              ? AppConstants.darkGreenColor
                                              : AppConstants.greyColor,
                                      fontSize: 12,
                                    ),
                                  ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  tickerModel.aiAnswer == null
                      ? SizedBox()
                      : Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          ConstrainedBox(
                            constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.of(context).size.width * 0.94,
                            ),
                            child: TypewriterText(
                              text: tickerModel.aiAnswer!,
                              textStyle: GoogleFonts.unbounded(
                                color: AppConstants.whiteColor,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                  SizedBox(height: 500),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class TypeRadioItem extends StatelessWidget {
  final TickerRadioModel _item;
  TypeRadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.05,
      width: MediaQuery.of(context).size.height * 0.1,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.05,
            width: MediaQuery.of(context).size.height * 0.1,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color:
                  _item.isSelected
                      ? AppConstants.darkGreenColor
                      : AppConstants.secondaryColor,
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  _item.name,
                  style: GoogleFonts.unbounded(
                    color:
                        _item.isSelected
                            ? AppConstants.bgColor
                            : AppConstants.whiteColor,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
