import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/core/services/stock_api_service/ticker_model.dart';
import 'package:organizer/feature/finances_screen/data/models/portfolio_model.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';

class AddPortfolioScreen extends ConsumerStatefulWidget {
  const AddPortfolioScreen({super.key});

  @override
  _AddPortfolioScreenState createState() => _AddPortfolioScreenState();
}

class _AddPortfolioScreenState extends ConsumerState<AddPortfolioScreen> {
  TextEditingController tickerController = TextEditingController();
  TextEditingController countController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController fullPriceController = TextEditingController();

  double? price;
  double? totalPrice;
  int? count;

  TickerTimeSeries? foundTicker;

  void _searchTicker(String tickerName) async {
    tickerName = tickerName.toUpperCase();
    var tickers = ref.read(financesController).tickers;
    for (var element in tickers) {
      if (element.symbol == tickerName) {
        setState(() {
          foundTicker = element;
          price = element.values.last.close;
          priceController = TextEditingController(
            text: price!.toStringAsFixed(2),
          );
          if (count != null && count != 0) {
            totalPrice = count! * price!;
          }
        });
      }
    }
  }

  void _deleteTicker() async {
    setState(() {
      tickerController = TextEditingController();
      foundTicker = null;
      price = null;
      totalPrice = null;
      priceController = TextEditingController();
    });
  }

  @override
  void dispose() {
    countController.dispose();
    tickerController.dispose();
    fullPriceController.dispose();
    priceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 30),
        child:
            (tickerController.text.isNotEmpty &&
                    count != null &&
                    count != 0 &&
                    price != null &&
                    totalPrice != null)
                ? AnimatedButton(
                  onTap: () async {
                    await ref
                        .read(financesController)
                        .addPortfolio(
                          context,
                          PortfolioModel(
                            stocksCount: count,
                            averagePrice: totalPrice! / count!,
                            tickerName:
                                foundTicker == null
                                    ? tickerController.text
                                    : foundTicker!.symbol,
                            totalPrice: totalPrice!,
                            price: price!,
                            percent:
                                ((price! - totalPrice! / count!) /
                                    totalPrice! /
                                    count!) *
                                100,
                            createdDate: DateTime.now(),
                          ),
                        );
                  },
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.darkGreenColor,
                    ),
                    child: Center(
                      child: Text(
                        "Добавить в портфель",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                )
                : AnimatedButton(
                  onTap: () async {},
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.greyColor,
                    ),
                    child: Center(
                      child: Text(
                        "Добавить в портфель",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor.withOpacity(0.5),
                AppConstants.bgGreyColor.withOpacity(0.3),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8),
            child: ListView(
              children: [
                CustomAppBar(text: "Добавление в портфель"),
                SizedBox(height: 20),
                Text(
                  "Название тикера",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 4),
                foundTicker != null
                    ? Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppConstants.bgGreyColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              foundTicker!.symbol,
                              style: GoogleFonts.unbounded(
                                color: AppConstants.whiteColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 10,
                              ),
                            ),
                            AnimatedButton(
                              onTap: () {
                                _deleteTicker();
                              },
                              child: Icon(Icons.cancel),
                            ),
                          ],
                        ),
                      ),
                    )
                    : TextInputField(
                      radius: 10,
                      height: 44,
                      controller: tickerController,
                      hintText: "Например, AAPL",
                      onChanged: (value) {
                        _searchTicker(value);
                      },
                    ),

                SizedBox(height: 20),
                Text(
                  "Количество акций",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 4),
                TextInputField(
                  radius: 10,
                  height: 44,
                  controller: countController,
                  keyboard: TextInputType.number,
                  hintText: "Например, 30",
                  onChanged: (value) {
                    try {
                      count = int.parse(value);
                    } catch (e) {
                      totalPrice = 0;
                      count = 0;
                    }

                    if (price != null && count != null) {
                      totalPrice = count! * price!;
                      setState(() {});
                    } else {
                      totalPrice = 0;
                    }
                    setState(() {});
                  },
                ),
                SizedBox(height: 20),
                Text(
                  "Цена",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 4),
                TextInputField(
                  radius: 10,
                  height: 44,
                  keyboard: TextInputType.number,
                  controller: priceController,
                  hintText: "Например, \$205",
                  onChanged: (value) {
                    try {
                      price = double.parse(value);
                    } catch (e) {
                      totalPrice = 0;
                      price = 0;
                    }

                    if (price != null && count != null) {
                      totalPrice = count! * price!;
                    }
                    setState(() {});
                  },
                ),
                SizedBox(height: 20),
                Text(
                  "Общая стоимость",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 4),
                totalPrice != null
                    ? Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppConstants.bgGreyColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Text(
                              totalPrice != null
                                  ? totalPrice!.toStringAsFixed(2)
                                  : "Не определено",
                              style: GoogleFonts.unbounded(
                                color: AppConstants.whiteColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                    : TextInputField(
                      radius: 10,
                      height: 44,
                      keyboard: TextInputType.number,
                      controller: fullPriceController,
                      hintText: "Количество акций умножить на стоимость одной",
                      onChanged: (value) {
                        try {
                          totalPrice = double.parse(fullPriceController.text);
                        } catch (e) {}

                        setState(() {});
                      },
                    ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
