import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';

class AddTradeScreen extends ConsumerStatefulWidget {
  const AddTradeScreen({super.key});

  @override
  _AddTradeScreenState createState() => _AddTradeScreenState();
}

class _AddTradeScreenState extends ConsumerState<AddTradeScreen> {
  bool isInfoChecked1 = false;
  bool isInfoChecked2 = false;
  bool isInfoChecked3 = false;
  bool isInfoChecked4 = false;

  bool isBuy = false;

  final TextEditingController textController = TextEditingController();
  final TextEditingController price1Controller = TextEditingController();
  final TextEditingController price2Controller = TextEditingController();
  final TextEditingController comissionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 20),
        child:
            (isInfoChecked1 == true &&
                    isInfoChecked2 == true &&
                    isInfoChecked3 == true &&
                    isInfoChecked4 == true &&
                    textController.text.isNotEmpty &&
                    price1Controller.text.isNotEmpty &&
                    price2Controller.text.isNotEmpty &&
                    comissionController.text.isNotEmpty)
                ? AnimatedButton(
                  onTap: () async {
                    await ref
                        .read(financesController)
                        .addTrade(
                          context,
                          textController.text,
                          isBuy,
                          double.parse(price1Controller.text),
                          double.parse(price2Controller.text),
                          double.parse(comissionController.text),
                        );
                  },
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.darkGreenColor,
                    ),
                    child: Center(
                      child: Text(
                        "Добавить сделку",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                )
                : AnimatedButton(
                  onTap: () async {},
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.greyColor,
                    ),
                    child: Center(
                      child: Text(
                        "Добавить сделку",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8),
          child: ListView(
            children: [
              CustomAppBar(text: "Добавление сделки"),
              SizedBox(height: 20),
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.84,
                    child: Text(
                      "Зашел на развороте/пробое уровня/выходе из фигуры или канала после подтвержденя своей гипотезы?",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  Spacer(),
                  AnimatedButton(
                    onTap: () {
                      setState(() {
                        isInfoChecked1 = !isInfoChecked1;
                      });
                    },
                    child:
                        isInfoChecked1
                            ? Icon(
                              Icons.check_box,
                              color: AppConstants.darkGreenColor,
                            )
                            : Icon(Icons.check_box_outline_blank),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.84,
                    child: Text(
                      "Индикаторы подтвердили гипотезу (stoh RSI, MACD)?",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  Spacer(),
                  AnimatedButton(
                    onTap: () {
                      setState(() {
                        isInfoChecked2 = !isInfoChecked2;
                      });
                    },
                    child:
                        isInfoChecked2
                            ? Icon(
                              Icons.check_box,
                              color: AppConstants.darkGreenColor,
                            )
                            : Icon(Icons.check_box_outline_blank),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.84,
                    child: Text(
                      "Проверил на разных таймфреймах?",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  Spacer(),
                  AnimatedButton(
                    onTap: () {
                      setState(() {
                        isInfoChecked3 = !isInfoChecked3;
                      });
                    },
                    child:
                        isInfoChecked3
                            ? Icon(
                              Icons.check_box,
                              color: AppConstants.darkGreenColor,
                            )
                            : Icon(Icons.check_box_outline_blank),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.84,
                    child: Text(
                      "Установил stop-loss? Рассчитал первую цель, используя риск-менеджмент 1 к 3 и более по уровням?",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  Spacer(),
                  AnimatedButton(
                    onTap: () {
                      setState(() {
                        isInfoChecked4 = !isInfoChecked4;
                      });
                    },
                    child:
                        isInfoChecked4
                            ? Icon(
                              Icons.check_box,
                              color: AppConstants.darkGreenColor,
                            )
                            : Icon(Icons.check_box_outline_blank),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Text(
                "Название тикера",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                controller: textController,
                hintText: "Например, AAPL",
                onChanged: (value) {
                  setState(() {});
                },
              ),
              SizedBox(height: 20),
              Text(
                "Покупка или продажа?",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  AnimatedButton(
                    onTap: () {
                      setState(() {
                        isBuy = true;
                      });
                    },
                    child:
                        isBuy
                            ? Icon(
                              Icons.check_circle,
                              color: AppConstants.darkGreenColor,
                            )
                            : Icon(Icons.circle_outlined),
                  ),
                  SizedBox(width: 4),
                  Text(
                    "Покупка",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(width: 20),
                  AnimatedButton(
                    onTap: () {
                      setState(() {
                        isBuy = false;
                      });
                    },
                    child:
                        !isBuy
                            ? Icon(
                              Icons.check_circle,
                              color: AppConstants.darkGreenColor,
                            )
                            : Icon(Icons.circle_outlined),
                  ),
                  SizedBox(width: 4),
                  Text(
                    "Продажа",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Text(
                "Цена входа",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                keyboard: TextInputType.number,
                controller: price1Controller,
                hintText: "Например, 100000",
                onChanged: (value) {
                  setState(() {});
                },
              ),
              SizedBox(height: 20),
              Text(
                "Цена выхода",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                keyboard: TextInputType.number,
                controller: price2Controller,
                hintText: "Например, 100000",
                onChanged: (value) {
                  setState(() {});
                },
              ),
              SizedBox(height: 20),
              Text(
                "Коммиссия",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                keyboard: TextInputType.number,
                controller: comissionController,
                hintText: "Например, 1000",
                onChanged: (value) {
                  setState(() {});
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
