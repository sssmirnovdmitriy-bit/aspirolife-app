import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/neon_expense_chart.dart';
import 'package:organizer/core/storages/investment_database.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';

class InvestmentScreen extends ConsumerStatefulWidget {
  const InvestmentScreen({super.key});

  @override
  _InvestmentScreenState createState() => _InvestmentScreenState();
}

class _InvestmentScreenState extends ConsumerState<InvestmentScreen> {
  bool timePeriodMonth = true;
  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 30),
        child: AnimatedButton(
          onTap: () {
            ref.read(financesController).showAddRealInvestmentTransactionSheet(
              context,
              (name, value, type) async {
                await ref
                    .read(financesController)
                    .addInvestment(name, value, type);
              },
            );
          },
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: AppConstants.darkGreenColor,
            ),
            child: Center(
              child: Text(
                "Добавить",
                style: GoogleFonts.unbounded(
                  color: AppConstants.bgColor,
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor.withOpacity(0.5),
                AppConstants.bgGreyColor.withOpacity(0.3),
              ],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(left: 8.0, right: 8),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    CustomAppBar(text: "Инвестиции"),
                    SizedBox(height: 10),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: AppConstants.secondaryColor.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          SizedBox(height: 10),
                          Text(
                            "ваши инвестиции:",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.whiteColor,
                              fontSize: 14,
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              financesModel.investmentSummary <= 0
                                  ? Icon(
                                    Icons.arrow_drop_down_rounded,
                                    color: Colors.red,
                                  )
                                  : Icon(
                                    Icons.arrow_drop_up_rounded,
                                    color: AppConstants.darkGreenColor,
                                  ),
                              Text(
                                timePeriodMonth
                                    ? "${financesModel.investmentSummary.round()}/мес"
                                    : "${(financesModel.investmentSummary * 12).round()}/год",
                                style: GoogleFonts.unbounded(
                                  color:
                                      financesModel.investmentSummary <= 0
                                          ? Colors.red
                                          : AppConstants.darkGreenColor,
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 10),
                            ],
                          ),

                          SizedBox(height: 14),
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0, right: 8),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.7,
                                  height: 44,
                                  child: NeonYearlySavingsChart(isMinus: false),
                                ),
                                Spacer(),
                                AnimatedButton(
                                  onTap: () {
                                    setState(() {
                                      timePeriodMonth = true;
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color:
                                          timePeriodMonth
                                              ? AppConstants.darkGreenColor
                                              : AppConstants.bgColor,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                        left: 10,
                                        right: 10,
                                        bottom: 4,
                                        top: 4,
                                      ),
                                      child: Text(
                                        "M",
                                        style: TextStyle(
                                          color:
                                              timePeriodMonth
                                                  ? AppConstants.bgColor
                                                  : AppConstants.whiteColor,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 8),
                                AnimatedButton(
                                  onTap: () {
                                    setState(() {
                                      timePeriodMonth = false;
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color:
                                          !timePeriodMonth
                                              ? AppConstants.darkGreenColor
                                              : AppConstants.bgColor,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                        left: 10,
                                        right: 10,
                                        bottom: 4,
                                        top: 4,
                                      ),
                                      child: Text(
                                        "Y",
                                        style: TextStyle(
                                          color:
                                              !timePeriodMonth
                                                  ? AppConstants.bgColor
                                                  : AppConstants.whiteColor,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          (financesModel.sumIncome.round() -
                                      financesModel.sumExpenses.round()) <=
                                  0
                              ? Text(
                                "Ваши инвестиции не растут",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.whiteColor,
                                  fontSize: 10,
                                ),
                              )
                              : Text(
                                "Отлично, ваши инвестиции растут",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.whiteColor,
                                  fontSize: 10,
                                ),
                              ),
                          SizedBox(height: 10),
                        ],
                      ),
                    ),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            "Активы",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.whiteColor,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            "Пассивы",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.whiteColor,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            color: AppConstants.darkGreenColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: SizedBox(
                            height: 44,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.arrow_drop_up_rounded,
                                  color: AppConstants.darkGreenColor,
                                ),
                                Text(
                                  "${financesModel.realInvestmentsActive.fold(0.0, (sum, el) => sum + el.value).round()}",
                                  style: GoogleFonts.unbounded(
                                    color: AppConstants.darkGreenColor,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 10),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            color: Colors.blue.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: SizedBox(
                            height: 44,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.arrow_drop_down_rounded,
                                  color: Colors.blue,
                                ),
                                Text(
                                  "${financesModel.realInvestmentsPassive.fold(0.0, (sum, el) => sum + el.value).round()}",
                                  style: GoogleFonts.unbounded(
                                    color: Colors.blue,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 10),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.47,
                          child: ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount:
                                financesModel.realInvestmentsActive.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    color: AppConstants.bgGreyColor,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              financesModel
                                                  .realInvestmentsActive[index]
                                                  .value
                                                  .round()
                                                  .toString(),
                                              style: GoogleFonts.unbounded(
                                                color:
                                                    AppConstants.darkGreenColor,
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              width:
                                                  MediaQuery.of(
                                                    context,
                                                  ).size.width *
                                                  0.38,
                                              child: Text(
                                                financesModel
                                                    .realInvestmentsActive[index]
                                                    .text,
                                                style: GoogleFonts.unbounded(
                                                  color:
                                                      AppConstants.whiteColor,
                                                  fontSize: 10,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        AnimatedButton(
                                          onTap: () async {
                                            await InvestmentDatabase()
                                                .deleteInvestment(
                                                  financesModel
                                                      .realInvestmentsActive[index]
                                                      .id!,
                                                );

                                            await ref
                                                .read(financesController)
                                                .readRealInvestments();
                                          },
                                          child: Icon(
                                            Icons.delete_rounded,
                                            color: Colors.red,
                                            size: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.47,
                          child: ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount:
                                financesModel.realInvestmentsPassive.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    color: AppConstants.bgGreyColor,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              financesModel
                                                  .realInvestmentsPassive[index]
                                                  .value
                                                  .round()
                                                  .toString(),
                                              style: GoogleFonts.unbounded(
                                                color: Colors.blue,
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              width:
                                                  MediaQuery.of(
                                                    context,
                                                  ).size.width *
                                                  0.38,
                                              child: Text(
                                                financesModel
                                                    .realInvestmentsPassive[index]
                                                    .text,
                                                style: GoogleFonts.unbounded(
                                                  color:
                                                      AppConstants.whiteColor,
                                                  fontSize: 10,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        AnimatedButton(
                                          onTap: () async {
                                            await InvestmentDatabase()
                                                .deleteInvestment(
                                                  financesModel
                                                      .realInvestmentsPassive[index]
                                                      .id!,
                                                );

                                            await ref
                                                .read(financesController)
                                                .readRealInvestments();
                                          },
                                          child: Icon(
                                            Icons.delete_rounded,
                                            color: Colors.red,
                                            size: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            "Приход",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.whiteColor,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            "Расход",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.whiteColor,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            color: AppConstants.darkGreenColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: SizedBox(
                            height: 44,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.arrow_drop_up_rounded,
                                  color: AppConstants.darkGreenColor,
                                ),
                                Text(
                                  "${financesModel.realInvestmentsIncome.fold(0.0, (sum, el) => sum + el.value).round()}",
                                  style: GoogleFonts.unbounded(
                                    color: AppConstants.darkGreenColor,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 10),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: SizedBox(
                            height: 44,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.arrow_drop_down_rounded,
                                  color: Colors.red,
                                ),
                                Text(
                                  "${financesModel.realInvestmentsExpense.fold(0.0, (sum, el) => sum + el.value).round()}",
                                  style: GoogleFonts.unbounded(
                                    color: Colors.red,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 10),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.47,
                          child: ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount:
                                financesModel.realInvestmentsIncome.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    color: AppConstants.bgGreyColor,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              financesModel
                                                  .realInvestmentsIncome[index]
                                                  .value
                                                  .round()
                                                  .toString(),
                                              style: GoogleFonts.unbounded(
                                                color:
                                                    AppConstants.darkGreenColor,
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              width:
                                                  MediaQuery.of(
                                                    context,
                                                  ).size.width *
                                                  0.38,
                                              child: Text(
                                                financesModel
                                                    .realInvestmentsIncome[index]
                                                    .text,
                                                style: GoogleFonts.unbounded(
                                                  color:
                                                      AppConstants.whiteColor,
                                                  fontSize: 10,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        AnimatedButton(
                                          onTap: () async {
                                            await InvestmentDatabase()
                                                .deleteInvestment(
                                                  financesModel
                                                      .realInvestmentsIncome[index]
                                                      .id!,
                                                );

                                            await ref
                                                .read(financesController)
                                                .readRealInvestments();
                                          },
                                          child: Icon(
                                            Icons.delete_rounded,
                                            color: Colors.red,
                                            size: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.47,
                          child: ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount:
                                financesModel.realInvestmentsExpense.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    color: AppConstants.bgGreyColor,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              financesModel
                                                  .realInvestmentsExpense[index]
                                                  .value
                                                  .round()
                                                  .toString(),
                                              style: GoogleFonts.unbounded(
                                                color: Colors.red,
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              width:
                                                  MediaQuery.of(
                                                    context,
                                                  ).size.width *
                                                  0.38,
                                              child: Text(
                                                financesModel
                                                    .realInvestmentsExpense[index]
                                                    .text,
                                                style: GoogleFonts.unbounded(
                                                  color:
                                                      AppConstants.whiteColor,
                                                  fontSize: 10,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        AnimatedButton(
                                          onTap: () async {
                                            await InvestmentDatabase()
                                                .deleteInvestment(
                                                  financesModel
                                                      .realInvestmentsExpense[index]
                                                      .id!,
                                                );

                                            await ref
                                                .read(financesController)
                                                .readRealInvestments();
                                          },
                                          child: Icon(
                                            Icons.delete_rounded,
                                            color: Colors.red,
                                            size: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 400),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
