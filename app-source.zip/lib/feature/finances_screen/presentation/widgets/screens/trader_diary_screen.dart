import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';

class TraderDiaryScreen extends ConsumerStatefulWidget {
  const TraderDiaryScreen({super.key});

  @override
  _TraderDiaryScreenState createState() => _TraderDiaryScreenState();
}

class _TraderDiaryScreenState extends ConsumerState<TraderDiaryScreen> {
  bool isVideoTab = false;

  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 30),
        child: AnimatedButton(
          onTap: () {
            Navigation.goToAddTradeScreen(context);
          },
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: AppConstants.darkGreenColor,
            ),
            child: Center(
              child: Text(
                "+ новая сделка",
                style: GoogleFonts.unbounded(
                  color: AppConstants.bgColor,
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor,
                AppConstants.bgColor.withOpacity(0.5),
                AppConstants.bgGreyColor.withOpacity(0.3),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8),
            child: ListView(
              children: [
                CustomAppBar(text: "Дневник трейдера"),
                SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.14,
                        child: Text(
                          "Тикер",
                          style: GoogleFonts.unbounded(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: AppConstants.whiteColor,
                          ),
                        ),
                      ),

                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.14,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Цена 1",
                              style: GoogleFonts.unbounded(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: AppConstants.whiteColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.14,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Цена 2",
                              style: GoogleFonts.unbounded(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: AppConstants.whiteColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.22,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Комиссия",
                              style: GoogleFonts.unbounded(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: AppConstants.whiteColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.22,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Результат",
                              style: GoogleFonts.unbounded(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: AppConstants.whiteColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 8),
                ListView.builder(
                  padding: EdgeInsets.zero,
                  itemCount: financesModel.trades.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppConstants.secondaryColor.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(
                                height: 6,
                                width: 6,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color:
                                      financesModel.trades[index].isBuy
                                          ? AppConstants.darkGreenColor
                                          : Colors.red,
                                ),
                              ),
                              SizedBox(width: 4),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.14,
                                child: Row(
                                  children: [
                                    Text(
                                      financesModel.trades[index].tickerName,
                                      style: GoogleFonts.unbounded(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppConstants.whiteColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.14,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      financesModel.trades[index].price1
                                          .toStringAsFixed(0),
                                      style: GoogleFonts.unbounded(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppConstants.whiteColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.14,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      financesModel.trades[index].price2
                                          .toStringAsFixed(0),
                                      style: GoogleFonts.unbounded(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppConstants.whiteColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.22,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      financesModel.trades[index].commision
                                          .toStringAsFixed(0),
                                      style: GoogleFonts.unbounded(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppConstants.whiteColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(width: 4),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.22,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      financesModel.trades[index].result!
                                          .round()
                                          .toString(),
                                      style: GoogleFonts.unbounded(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color:
                                            financesModel
                                                        .trades[index]
                                                        .result! >
                                                    0
                                                ? AppConstants.darkGreenColor
                                                : Colors.red,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
