import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/gh_videos_widget.dart';

class FinanceLearnScreen extends ConsumerStatefulWidget {
  const FinanceLearnScreen({super.key});

  @override
  _FinanceLearnScreenState createState() => _FinanceLearnScreenState();
}

class _FinanceLearnScreenState extends ConsumerState<FinanceLearnScreen> {
  bool isVideoTab = true;

  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);

    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8),
          child: Column(
            children: [
              const SizedBox(height: 50),
              const CustomAppBar(text: "Финансовая грамотность"),
              const SizedBox(height: 10),
              Row(
                children: [
                  AnimatedButton(
                    onTap: () => setState(() => isVideoTab = true),
                    child: Container(
                      decoration: BoxDecoration(
                        color:
                            !isVideoTab
                                ? AppConstants.secondaryColor.withOpacity(0.6)
                                : AppConstants.darkGreenColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Видео",
                          style: GoogleFonts.unbounded(
                            color:
                                !isVideoTab
                                    ? AppConstants.whiteColor
                                    : AppConstants.bgColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  AnimatedButton(
                    onTap: () => setState(() => isVideoTab = false),
                    child: Container(
                      decoration: BoxDecoration(
                        color:
                            isVideoTab
                                ? AppConstants.secondaryColor.withOpacity(0.6)
                                : AppConstants.darkGreenColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Книги",
                          style: GoogleFonts.unbounded(
                            color:
                                isVideoTab
                                    ? AppConstants.whiteColor
                                    : AppConstants.bgColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              /// -------- ПРОГРЕСС КНИГ --------
              if (!isVideoTab)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "${financesModel.readBooks.length}/${financesModel.mergedBooks.length} прочитано",
                      style: GoogleFonts.unbounded(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: AppConstants.whiteColor,
                      ),
                    ),
                  ],
                ),

              if (!isVideoTab) const SizedBox(height: 4),

              if (!isVideoTab)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 2,
                      width: MediaQuery.of(context).size.width * 0.6,
                      child: ListView.builder(
                        padding: EdgeInsets.zero,
                        itemCount: financesModel.mergedBooks.length,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(right: 4.0),
                            child: Container(
                              height: 2,
                              width: 20,
                              decoration: BoxDecoration(
                                color:
                                    financesModel.mergedBooks[index].isRead
                                        ? AppConstants.darkGreenColor
                                        : AppConstants.secondaryColor
                                            .withOpacity(0.6),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),

              if (!isVideoTab) const SizedBox(height: 20),

              /// ============================================================
              ///                        ВИДЕО TAB
              /// ============================================================
              Expanded(
                child:
                    isVideoTab
                        ? SingleChildScrollView(
                          child: GhVideosWidget(
                            habbit: null,
                            customVideos:
                                financesModel.videos.map((e) => e.url).toList(),
                          ),
                        )
                        /// ============================================================
                        ///                          КНИГИ TAB
                        /// ============================================================
                        : ListView.builder(
                          padding: EdgeInsets.zero,
                          itemCount: financesModel.mergedBooks.length,
                          itemBuilder: (context, index) {
                            final book = financesModel.mergedBooks[index];

                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppConstants.secondaryColor
                                      .withOpacity(0.6),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width *
                                            0.94,
                                        child: Text(
                                          book.text,
                                          style: GoogleFonts.unbounded(
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: AppConstants.whiteColor,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width *
                                            0.94,
                                        child: Text(
                                          book.description,
                                          style: GoogleFonts.unbounded(
                                            fontSize: 10,
                                            color: AppConstants.whiteColor,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 6),

                                      book.isRead
                                          ? Container(
                                            height: 44,
                                            width: double.infinity,
                                            child: Center(
                                              child: Text(
                                                "Вы прочитали эту книгу!",
                                                style: GoogleFonts.unbounded(
                                                  color:
                                                      AppConstants
                                                          .darkGreenColor,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ),
                                          )
                                          : AnimatedButton(
                                            onTap: () async {
                                              await ref
                                                  .read(financesController)
                                                  .makeBookRead(book);
                                            },
                                            child: Container(
                                              height: 44,
                                              width: double.infinity,
                                              decoration: BoxDecoration(
                                                color: AppConstants.bgGreyColor,
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                              ),
                                              child: Center(
                                                child: Text(
                                                  "Отметить прочитанной",
                                                  style: GoogleFonts.unbounded(
                                                    color:
                                                        AppConstants
                                                            .darkGreenColor,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
