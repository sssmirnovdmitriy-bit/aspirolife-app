import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/storages/transaction_database.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';
import 'package:sqflite/sqlite_api.dart';

class PlanScreen extends ConsumerStatefulWidget {
  const PlanScreen({super.key});

  @override
  _PlanScreenState createState() => _PlanScreenState();
}

class _PlanScreenState extends ConsumerState<PlanScreen> {
  @override
  Widget build(BuildContext context) {
    var financesModel = ref.watch(financesController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  CustomAppBar(text: "Планирование"),
                  SizedBox(height: 10),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: AppConstants.secondaryColor.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: 10),
                        Text(
                          "ваш доход:",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 14,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            (financesModel.sumIncome.round() -
                                        financesModel.sumExpenses.round()) <=
                                    0
                                ? Icon(
                                  Icons.arrow_drop_down_rounded,
                                  color: Colors.red,
                                )
                                : Icon(
                                  Icons.arrow_drop_up_rounded,
                                  color: AppConstants.darkGreenColor,
                                ),
                            Text(
                              "${financesModel.sumIncome.round() - financesModel.sumExpenses.round()}/мес",
                              style: GoogleFonts.unbounded(
                                color:
                                    (financesModel.sumIncome.round() -
                                                financesModel.sumExpenses
                                                    .round()) <=
                                            0
                                        ? Colors.red
                                        : AppConstants.darkGreenColor,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(width: 10),
                          ],
                        ),
                        SizedBox(height: 10),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.47,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          "Доходы   (за месяц)",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.47,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          "Расходы   (за месяц)",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.47,
                        decoration: BoxDecoration(
                          color: AppConstants.darkGreenColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: SizedBox(
                          height: 44,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.arrow_drop_up_rounded,
                                color: AppConstants.darkGreenColor,
                              ),
                              Text(
                                "${financesModel.sumIncome.round().toString()}/мес",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.darkGreenColor,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 10),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.47,
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: SizedBox(
                          height: 44,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.arrow_drop_down_rounded,
                                color: Colors.red,
                              ),
                              Text(
                                "${financesModel.sumExpenses.round().toString()}/мес",
                                style: GoogleFonts.unbounded(
                                  color: Colors.red,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 10),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.47,
                        child: ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: financesModel.incomes.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: Container(
                                height: 50,
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  color: AppConstants.bgGreyColor,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            financesModel.incomes[index].value
                                                .round()
                                                .toString(),
                                            style: GoogleFonts.unbounded(
                                              color:
                                                  AppConstants.darkGreenColor,
                                              fontSize: 14,
                                            ),
                                          ),
                                          SizedBox(
                                            width:
                                                MediaQuery.of(
                                                  context,
                                                ).size.width *
                                                0.38,
                                            child: Text(
                                              financesModel.incomes[index].text,
                                              style: GoogleFonts.unbounded(
                                                color: AppConstants.whiteColor,
                                                fontSize: 10,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      AnimatedButton(
                                        onTap: () async {
                                          await TransactionDatabase.instance
                                              .delete(
                                                financesModel
                                                    .incomes[index]
                                                    .id!,
                                              );
                                          await ref
                                              .read(financesController)
                                              .readTransactions();
                                        },
                                        child: Icon(
                                          Icons.delete_rounded,
                                          color: Colors.red,
                                          size: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.47,
                        child: ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: financesModel.expenses.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: Container(
                                height: 50,
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  color: AppConstants.bgGreyColor,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            financesModel.expenses[index].value
                                                .round()
                                                .toString(),
                                            style: GoogleFonts.unbounded(
                                              color: Colors.red,
                                              fontSize: 14,
                                            ),
                                          ),
                                          SizedBox(
                                            width:
                                                MediaQuery.of(
                                                  context,
                                                ).size.width *
                                                0.38,
                                            child: Text(
                                              financesModel
                                                  .expenses[index]
                                                  .text,
                                              style: GoogleFonts.unbounded(
                                                color: AppConstants.whiteColor,
                                                fontSize: 10,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      AnimatedButton(
                                        onTap: () async {
                                          await TransactionDatabase.instance
                                              .delete(
                                                financesModel
                                                    .expenses[index]
                                                    .id!,
                                              );
                                          await ref
                                              .read(financesController)
                                              .readTransactions();
                                        },
                                        child: Icon(
                                          Icons.delete_rounded,
                                          color: Colors.red,
                                          size: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AnimatedButton(
                        onTap: () async {
                          ref
                              .read(financesController)
                              .showAddIncomeTransactionSheet(context, (
                                text,
                                value,
                                isIncome,
                              ) async {
                                await ref
                                    .read(financesController)
                                    .addTransaction(text, value, isIncome);
                              });
                        },
                        child: Container(
                          height: 44,
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            color: AppConstants.bgGreyColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Center(
                              child: Text(
                                "Добавить доход",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.darkGreenColor,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      AnimatedButton(
                        onTap: () async {
                          ref
                              .read(financesController)
                              .showAddExpenseTransactionSheet(context, (
                                text,
                                value,
                                isIncome,
                              ) async {
                                await ref
                                    .read(financesController)
                                    .addTransaction(text, value, isIncome);
                              });
                        },
                        child: Container(
                          height: 44,
                          width: MediaQuery.of(context).size.width * 0.47,
                          decoration: BoxDecoration(
                            color: AppConstants.bgGreyColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Center(
                              child: Text(
                                "Добавить расход",
                                style: GoogleFonts.unbounded(
                                  color: Colors.red,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.47,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          "Инвестиции   (за месяц)",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  SizedBox(
                    width: MediaQuery.of(context).size.width,
                    child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: financesModel.investments.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Container(
                            height: 50,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              color: AppConstants.bgGreyColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        financesModel.investments[index].value
                                            .round()
                                            .toString(),
                                        style: GoogleFonts.unbounded(
                                          color: AppConstants.darkGreenColor,
                                          fontSize: 14,
                                        ),
                                      ),
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width *
                                            0.38,
                                        child: Text(
                                          financesModel.investments[index].text,
                                          style: GoogleFonts.unbounded(
                                            color: AppConstants.whiteColor,
                                            fontSize: 10,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  AnimatedButton(
                                    onTap: () async {
                                      await TransactionDatabase.instance.delete(
                                        financesModel.investments[index].id!,
                                      );
                                      await ref
                                          .read(financesController)
                                          .readTransactions();
                                    },
                                    child: Icon(
                                      Icons.delete_rounded,
                                      color: Colors.red,
                                      size: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  AnimatedButton(
                    onTap: () async {
                      ref
                          .read(financesController)
                          .showAddInvestmentTransactionSheet(context, (
                            text,
                            value,
                            isIncome,
                          ) async {
                            await ref
                                .read(financesController)
                                .addTransaction(text, value, isIncome);
                          });
                    },
                    child: Container(
                      height: 44,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: AppConstants.bgGreyColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(
                          child: Text(
                            "Добавить инвестицию",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.darkGreenColor,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 400),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
