import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/purchase/pay_controller.dart';

class FinancesCourseSection extends ConsumerWidget {
  const FinancesCourseSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasSubscription = ref.watch(payController).hasSubscription;
    return AnimatedButton(
      onTap: () {
        if (hasSubscription) {
          Navigation.goToFinanceLearnScreen(context);
        } else {
          AppNotifications.showError(context, "Необходима подписка Pro");
        }
      },
      child: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: AppConstants.secondaryColor.withOpacity(0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Финансовая грамотность",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 6),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.84,
                    child: Text(
                      "Обучись правильной работе с финансами прямо сейчас!",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.darkGreenColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            hasSubscription
                ? Icon(Icons.arrow_forward_ios_rounded)
                : Icon(
                  Icons.lock,
                  size: 18,
                  color: AppConstants.darkGreenColor,
                ),
          ],
        ),
      ),
    );
  }
}
