import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';

class FinancesInvestmentSection extends ConsumerWidget {
  const FinancesInvestmentSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        //2БЛОК ИНВЕСТИЦИИ
        AnimatedButton(
          onTap: () {
            Navigation.goToInvestmentScreen(context);
          },
          child: Container(
            width: MediaQuery.of(context).size.width * 0.45,

            decoration: BoxDecoration(
              color: AppConstants.secondaryColor.withOpacity(0.6),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 10),
                Icon(
                  Icons.auto_graph_rounded,
                  color: AppConstants.darkGreenColor,
                ),
                SizedBox(height: 6),
                Text(
                  "Инвестиции",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: AppConstants.bgGreyColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "открыть",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.darkGreenColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        //4БЛОК ДНЕВНИК ТРЕЙДЕРА
        AnimatedButton(
          onTap: () {
            Navigation.goToTraderDiaryScreen(context);
          },
          child: Container(
            width: MediaQuery.of(context).size.width * 0.49,

            decoration: BoxDecoration(
              color: AppConstants.secondaryColor.withOpacity(0.6),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 10),
                Icon(
                  Icons.monitor_heart_rounded,
                  color: AppConstants.darkGreenColor,
                ),
                SizedBox(height: 6),
                Text(
                  "Дневник трейдера",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: AppConstants.bgGreyColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "добавить",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.darkGreenColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
