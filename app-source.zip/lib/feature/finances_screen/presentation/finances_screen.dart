import 'package:flutter/material.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/finances_appbar.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/finances_course_section.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/finances_gpt_section.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/finances_investment_section.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/finances_plan_section.dart';
import 'package:organizer/feature/finances_screen/presentation/widgets/finances_portfolio_section.dart';

class FinancesScreen extends StatelessWidget {
  const FinancesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  FinancesAppbar(),
                  SizedBox(height: 10),
                  FinancesPlanSection(),
                  SizedBox(height: 10),
                  FinancesInvestmentSection(),
                  SizedBox(height: 10),
                  FinancesPortfolioSection(),
                  SizedBox(height: 10),
                  FinancesGPTSection(),
                  SizedBox(height: 10),
                  FinancesCourseSection(),
                  SizedBox(height: 50),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
