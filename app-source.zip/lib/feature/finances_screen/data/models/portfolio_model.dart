class PortfolioModel {
  int? id;
  String tickerName;
  int? stocksCount;
  double? averagePrice;
  double totalPrice;
  double price;
  double percent;
  DateTime createdDate;

  PortfolioModel({
    this.id,
    required this.tickerName,
    this.stocksCount,
    this.averagePrice,
    required this.totalPrice,
    required this.price,
    required this.percent,
    required this.createdDate,
  });

  factory PortfolioModel.fromJson(Map<String, dynamic> json) {
    return PortfolioModel(
      id: json['id'] as int?,
      tickerName: json['tickerName'] as String,
      stocksCount: json['stocksCount'] as int?,
      averagePrice: (json['averagePrice'] as num?)?.toDouble(),
      totalPrice: (json['totalPrice'] as num).toDouble(),
      price: (json['price'] as num).toDouble(),
      percent: (json['percent'] as num).toDouble(),
      createdDate: DateTime.parse(json['createdDate']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'tickerName': tickerName,
      'stocksCount': stocksCount,
      'averagePrice': averagePrice,
      'totalPrice': totalPrice,
      'price': price,
      'percent': percent,
      'createdDate': createdDate.toIso8601String(),
    };
  }
}
