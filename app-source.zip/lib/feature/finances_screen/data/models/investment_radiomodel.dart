import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';

class InvestmentRadiomodel {
  bool isSelected;
  String type;
  String name;

  InvestmentRadiomodel(this.isSelected, this.type, this.name);
}

class InvestmentTypeRadioItem extends StatelessWidget {
  final InvestmentRadiomodel _item;
  InvestmentTypeRadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.05,
          width: MediaQuery.of(context).size.height * 0.1,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.05,
                width: MediaQuery.of(context).size.height * 0.1,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color:
                      _item.isSelected
                          ? AppConstants.darkGreenColor
                          : AppConstants.secondaryColor,
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      _item.name,
                      style: GoogleFonts.unbounded(
                        color:
                            _item.isSelected
                                ? AppConstants.bgColor
                                : AppConstants.whiteColor,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
