class TickerRadioModel {
  bool isSelected;
  String name;

  TickerRadioModel(this.isSelected, this.name);
}
