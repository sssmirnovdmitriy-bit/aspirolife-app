import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:math';
import 'package:google_fonts/google_fonts.dart';

import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/models/habbit_model.dart';

class HabitAnalyticsScreen extends StatefulWidget {
  final HabbitModel habit;

  const HabitAnalyticsScreen({Key? key, required this.habit}) : super(key: key);

  @override
  _HabitAnalyticsScreenState createState() => _HabitAnalyticsScreenState();
}

class _HabitAnalyticsScreenState extends State<HabitAnalyticsScreen>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  int selectedPeriod = 0; // 0 - неделя, 1 - месяц, 2 - год

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));

    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      appBar: _buildAppBar(),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildStatsOverview(),
                const SizedBox(height: 24),
                _buildHabitHeader(),
                const SizedBox(height: 24),
                _buildPeriodSelector(),
                const SizedBox(height: 16),
                _buildProgressChart(),
                const SizedBox(height: 24),
                _buildMissionsAnalytics(),
                const SizedBox(height: 24),
                // _buildAIRecommendations(),
                // const SizedBox(height: 24),
                _buildAchievements(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(60),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        child: const SafeArea(child: CustomAppBar(text: "Аналитика")),
      ),
    );
  }

  Widget _buildHabitHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppConstants.darkGreenColor.withOpacity(0.1),
            AppConstants.ligthYellowColor.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppConstants.darkGreenColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.habit.habbitName,
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.habit.habbitDescription,
                  style: GoogleFonts.unbounded(
                    color: AppConstants.greyColor,
                    fontSize: 10,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildMiniStat(
                      Icons.local_fire_department,
                      '${widget.habit.streak ?? 0}',
                      'дней',
                    ),
                    const SizedBox(width: 16),
                    _buildMiniStat(
                      Icons.stars,
                      '${widget.habit.points}',
                      'очков',
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniStat(IconData icon, String value, String label) {
    return Row(
      children: [
        Icon(icon, color: AppConstants.darkGreenColor, size: 16),
        const SizedBox(width: 4),
        Text(
          value,
          style: GoogleFonts.unbounded(
            color: AppConstants.whiteColor,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        const SizedBox(width: 2),
        Text(
          label,
          style: GoogleFonts.unbounded(
            color: AppConstants.greyColor,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildStatsOverview() {
    final completionRate = _calculateCompletionRate();
    final avgDailyPoints = _calculateAvgDailyPoints();
    final totalDays = _calculateTotalDays();

    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            icon: Icons.trending_up,
            title: 'Прогресс',
            value: '${completionRate.toInt()}%',
            subtitle: 'выполнение',
            color: AppConstants.darkGreenColor,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatCard(
            icon: Icons.calendar_today,
            title: 'Активность',
            value: '$totalDays',
            subtitle: 'дней',
            color: AppConstants.ligthYellowColor,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatCard(
            icon: Icons.star,
            title: 'Средний балл',
            value: '${avgDailyPoints.toInt()}',
            subtitle: 'за день',
            color: AppConstants.darkYellowColor,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required String subtitle,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppConstants.bgGreyColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.unbounded(
              color: AppConstants.whiteColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            subtitle,
            style: GoogleFonts.unbounded(
              color: AppConstants.greyColor,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: GoogleFonts.unbounded(
              color: color,
              fontSize: 8,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodSelector() {
    const periods = ['Неделя', 'Месяц', 'Год'];

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppConstants.bgGreyColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children:
            periods.map((period) {
              final index = periods.indexOf(period);
              final isSelected = selectedPeriod == index;

              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => selectedPeriod = index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color:
                          isSelected
                              ? AppConstants.darkGreenColor
                              : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      period,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.unbounded(
                        color:
                            isSelected
                                ? AppConstants.bgColor
                                : AppConstants.greyColor,
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.normal,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
      ),
    );
  }

  Widget _buildProgressChart() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppConstants.bgGreyColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'График прогресса',
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Icon(Icons.show_chart, color: AppConstants.darkGreenColor),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 1,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: AppConstants.greyColor.withOpacity(0.2),
                      strokeWidth: 1,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  show: true,
                  rightTitles: AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30,
                      interval: 1,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        final style = GoogleFonts.unbounded(
                          color: AppConstants.greyColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        );
                        Widget text;
                        switch (value.toInt()) {
                          case 1:
                            text = Text('Пн', style: style);
                            break;
                          case 2:
                            text = Text('Вт', style: style);
                            break;
                          case 3:
                            text = Text('Ср', style: style);
                            break;
                          case 4:
                            text = Text('Чт', style: style);
                            break;
                          case 5:
                            text = Text('Пт', style: style);
                            break;
                          case 6:
                            text = Text('Сб', style: style);
                            break;
                          case 7:
                            text = Text('Вс', style: style);
                            break;
                          default:
                            text = Text('', style: style);
                            break;
                        }
                        return SideTitleWidget(meta: meta, child: text);
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      interval: 1,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        return SideTitleWidget(
                          meta: meta,
                          child: Container(
                            margin: const EdgeInsets.only(right: 8),
                            child: Text(
                              value.toInt().toString(),
                              style: GoogleFonts.unbounded(
                                color: AppConstants.greyColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                              textAlign: TextAlign.right,
                            ),
                          ),
                        );
                      },
                      reservedSize: 32,
                    ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                minX: 0,
                maxX: 8,
                minY: 0,
                maxY: 6,
                lineBarsData: [
                  LineChartBarData(
                    spots: _generateProgressData(),
                    isCurved: true,
                    gradient: LinearGradient(
                      colors: [
                        AppConstants.darkGreenColor,
                        AppConstants.ligthYellowColor,
                      ],
                    ),
                    barWidth: 3,
                    isStrokeCapRound: true,
                    dotData: FlDotData(
                      show: true,
                      getDotPainter:
                          (spot, percent, barData, index) => FlDotCirclePainter(
                            radius: 4,
                            color: AppConstants.darkGreenColor,
                            strokeWidth: 2,
                            strokeColor: AppConstants.whiteColor,
                          ),
                    ),
                    belowBarData: BarAreaData(
                      show: true,
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          AppConstants.darkGreenColor.withOpacity(0.3),
                          AppConstants.darkGreenColor.withOpacity(0.0),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMissionsAnalytics() {
    final completedMissions =
        widget.habit.dailyMissions.where((m) => m.isCompleted).length;
    final totalMissions = widget.habit.dailyMissions.length;
    final completionRate =
        totalMissions > 0 ? (completedMissions / totalMissions) * 100 : 0;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppConstants.bgGreyColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Ежедневные миссии',
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '$completedMissions/$totalMissions',
                style: GoogleFonts.unbounded(
                  color: AppConstants.darkGreenColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Mission list - только выполненные
          widget.habit.dailyMissions
                  .where((mission) => mission.isCompleted)
                  .isEmpty
              ? Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppConstants.secondaryColor.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppConstants.greyColor.withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: AppConstants.greyColor,
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Пока нет выполненных миссий',
                      style: GoogleFonts.unbounded(
                        color: AppConstants.greyColor,
                        fontSize: 10,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              )
              : Column(
                children:
                    widget.habit.dailyMissions
                        .where((mission) => mission.isCompleted)
                        .map((mission) => _buildMissionItem(mission))
                        .toList(),
              ),
        ],
      ),
    );
  }

  Widget _buildMissionItem(DailyMission mission) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppConstants.secondaryColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color:
              mission.isCompleted
                  ? AppConstants.darkGreenColor.withOpacity(0.5)
                  : AppConstants.greyColor.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color:
                  mission.isCompleted
                      ? AppConstants.darkGreenColor
                      : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color:
                    mission.isCompleted
                        ? AppConstants.darkGreenColor
                        : AppConstants.greyColor,
                width: 2,
              ),
            ),
            child:
                mission.isCompleted
                    ? Icon(Icons.check, color: AppConstants.bgColor, size: 12)
                    : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              mission.missionText,
              style: GoogleFonts.unbounded(
                color:
                    mission.isCompleted
                        ? AppConstants.whiteColor
                        : AppConstants.greyColor,
                fontSize: 14,
                decoration:
                    mission.isCompleted
                        ? TextDecoration.lineThrough
                        : TextDecoration.none,
              ),
            ),
          ),
          Text(
            '+${mission.points}',
            style: GoogleFonts.unbounded(
              color: AppConstants.ligthYellowColor,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAIRecommendations() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppConstants.ligthYellowColor.withOpacity(0.1),
            AppConstants.darkYellowColor.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppConstants.ligthYellowColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppConstants.ligthYellowColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.psychology,
                  color: AppConstants.ligthYellowColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                'ИИ Рекомендации',
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            widget.habit.aiSuggestion,
            style: GoogleFonts.unbounded(
              color: AppConstants.greyColor,
              fontSize: 14,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _buildActionButton(
                icon: Icons.thumb_up_outlined,
                label: 'Полезно',
                onTap: () {},
              ),
              const SizedBox(width: 12),
              _buildActionButton(
                icon: Icons.refresh,
                label: 'Обновить',
                onTap: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: AppConstants.bgGreyColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppConstants.ligthYellowColor, size: 16),
            const SizedBox(width: 6),
            Text(
              label,
              style: GoogleFonts.unbounded(
                color: AppConstants.ligthYellowColor,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAchievements() {
    final achievements = _generateAchievements();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppConstants.bgGreyColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Достижения',
            style: GoogleFonts.unbounded(
              color: AppConstants.whiteColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 86,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: achievements.length,
              itemBuilder: (context, index) {
                final achievement = achievements[index];
                return Container(
                  margin: const EdgeInsets.only(right: 12),
                  width: 70,
                  child: Column(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          gradient:
                              achievement['isUnlocked']
                                  ? LinearGradient(
                                    colors: [
                                      AppConstants.darkGreenColor,
                                      AppConstants.ligthYellowColor,
                                    ],
                                  )
                                  : null,
                          color:
                              achievement['isUnlocked']
                                  ? null
                                  : AppConstants.secondaryColor,
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: Icon(
                          achievement['icon'],
                          color:
                              achievement['isUnlocked']
                                  ? AppConstants.bgColor
                                  : AppConstants.greyColor,
                          size: 24,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        achievement['name'],
                        style: GoogleFonts.unbounded(
                          color:
                              achievement['isUnlocked']
                                  ? AppConstants.whiteColor
                                  : AppConstants.greyColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // Helper methods
  double _calculateCompletionRate() {
    if (widget.habit.dailyMissions.isEmpty) return 0;
    final completed =
        widget.habit.dailyMissions.where((m) => m.isCompleted).length;
    return (completed / widget.habit.dailyMissions.length) * 100;
  }

  double _calculateAvgDailyPoints() {
    final totalDays = _calculateTotalDays();
    return totalDays > 0 ? widget.habit.points / totalDays : 0;
  }

  int _calculateTotalDays() {
    if (widget.habit.startDate == null) return 0;
    return DateTime.now().difference(widget.habit.startDate!).inDays + 1;
  }

  List<FlSpot> _generateProgressData() {
    // Генерируем данные для графика за неделю
    final random = Random();
    return List.generate(7, (index) {
      return FlSpot((index + 1).toDouble(), random.nextDouble() * 5 + 1);
    });
  }

  List<Map<String, dynamic>> _generateAchievements() {
    return [
      {'name': 'Первый шаг', 'icon': Icons.start, 'isUnlocked': true},
      {
        'name': 'Неделя',
        'icon': Icons.calendar_view_week,
        'isUnlocked': (widget.habit.streak ?? 0) >= 7,
      },
      {
        'name': 'Месяц',
        'icon': Icons.calendar_month,
        'isUnlocked': (widget.habit.streak ?? 0) >= 30,
      },

      {
        'name': 'Мастер',
        'icon': Icons.emoji_events,
        'isUnlocked': (widget.habit.streak ?? 0) >= 14,
      },
    ];
  }
}
