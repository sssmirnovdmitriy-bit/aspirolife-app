import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';

class TaskRadiomodel {
  bool isSelected;
  int value;
  String name;

  TaskRadiomodel(this.isSelected, this.value, this.name);
}

class TaskRadioItem extends StatelessWidget {
  final TaskRadiomodel _item;
  TaskRadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    var selectedColor;
    if (_item.value == 0) {
      selectedColor = AppConstants.darkGreenColor;
    }
    if (_item.value == 1) {
      selectedColor = const Color.fromARGB(255, 234, 255, 0);
    }

    if (_item.value == 2) {
      selectedColor = const Color.fromARGB(255, 255, 162, 0);
    }

    if (_item.value == 3) {
      selectedColor = const Color.fromARGB(255, 255, 38, 0);
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.07,
          width: MediaQuery.of(context).size.height * 0.1,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.05,
                width: MediaQuery.of(context).size.height * 0.1,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color:
                      _item.isSelected
                          ? selectedColor
                          : AppConstants.secondaryColor,
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Text(
                      _item.name,
                      style: GoogleFonts.unbounded(
                        color:
                            _item.isSelected
                                ? AppConstants.bgColor
                                : AppConstants.whiteColor,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
