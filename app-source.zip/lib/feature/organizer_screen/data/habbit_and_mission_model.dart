import 'package:organizer/core/models/habbit_model.dart';

class HabbitAndMissionModel {
  final HabbitModel habbitModel;
  final DailyMission dailyMission;

  HabbitAndMissionModel({
    required this.habbitModel,
    required this.dailyMission,
  });
}
