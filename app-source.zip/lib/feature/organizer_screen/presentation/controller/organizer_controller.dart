import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/core/models/entertainment_model.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/models/note_model.dart';
import 'package:organizer/core/models/task_model.dart';
import 'package:organizer/core/storages/entertainment_database.dart';
import 'package:organizer/core/storages/habbit_database.dart';
import 'package:organizer/core/storages/note_database.dart';
import 'package:organizer/core/storages/task_database.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';
import 'package:organizer/feature/organizer_screen/data/habbit_and_mission_model.dart';
import 'package:organizer/feature/organizer_screen/data/task_radiomodel.dart';

final organizerController = ChangeNotifierProvider(
  ((ref) => OrganizerController()),
);

class OrganizerController extends ChangeNotifier {
  List<HabbitAndMissionModel> goodHabbitsDailyMissions = [];
  List<HabbitAndMissionModel> badHabbitsDailyMissions = [];
  List<TaskModel> allTasks = [];
  List<NoteModel> myNotes = [];

  List<EntertainmentModel> allEntertainments = [];

  TaskRadiomodel chosenTaskPriority = TaskRadiomodel(true, 0, "Обычный");
  List<TaskRadiomodel> myTaskPriorities = [
    TaskRadiomodel(true, 0, "Обычный"),
    TaskRadiomodel(false, 1, "Средний"),
    TaskRadiomodel(false, 2, "Высокий"),
    TaskRadiomodel(false, 3, "Срочный"),
  ];

  void chooseTaskPriority(TaskRadiomodel taskRadiomodel) {
    chosenTaskPriority = taskRadiomodel;
    notifyListeners();
  }

  OrganizerController() {}

  Future<void> getAllDailyMissionsByDate(WidgetRef ref, DateTime date) async {
    goodHabbitsDailyMissions.clear();
    badHabbitsDailyMissions.clear();

    final goodHabbits = ref.read(ghController).myActiveGoodHabbits;
    final badHabbits = ref.read(bhController).myActiveBadHabbits;

    final habbitDatabaseService = HabbitDatabaseService();

    Future<void> processHabbits(
      List<HabbitModel> habbits,
      List<HabbitAndMissionModel> targetList,
    ) async {
      for (var habbit in habbits) {
        final dailyMission = await habbitDatabaseService.getDailyMissionByDate(
          habbitId: habbit.id!,
          targetDate: date,
        );

        targetList.add(
          HabbitAndMissionModel(
            habbitModel: habbit,
            dailyMission:
                dailyMission ??
                DailyMission(
                  missionText: "Ты молодец! Продолжай в том же духе",
                  notificationText: "",
                  isCompleted: false,
                  points: 10,
                ),
          ),
        );
      }
    }

    await processHabbits(goodHabbits, goodHabbitsDailyMissions);
    await processHabbits(badHabbits, badHabbitsDailyMissions);

    notifyListeners();
  }

  Future<void> getAllTasksByDate(DateTime date) async {
    allTasks.clear();
    final taskService = TaskService();
    allTasks = await taskService.getTasksByDate(date);
    notifyListeners();
  }

  Future<void> getAllEntertainmentsByDate(DateTime date) async {
    allEntertainments.clear();
    allEntertainments = await EntertainmentDatabase.instance.readByDate(date);
    notifyListeners();
  }

  Future<void> createTask(String text, DateTime date) async {
    var newTask = TaskModel(
      text: text,
      timeStart: date,
      priority: chosenTaskPriority.value,
    );

    final taskService = TaskService();
    await taskService.insertTask(newTask);
    await getAllTasksByDate(date);
  }

  Future<void> makeTaskCompleted(TaskModel task, DateTime date) async {
    final taskService = TaskService();
    if (task.isCompleted) {
      await taskService.markTaskCompleted(task.id!, 0);
    } else {
      await taskService.markTaskCompleted(task.id!, 1);
    }
    await getAllTasksByDate(date);
  }

  Future<void> deleteTask(TaskModel task, DateTime date) async {
    final taskService = TaskService();
    taskService.deleteTask(task.id!);
    await getAllTasksByDate(date);
  }

  Future<void> getAllNotes() async {
    final db = NoteDatabase.instance;
    myNotes = await db.readAllNotes();
    notifyListeners();
  }

  Future<void> createNote(String text) async {
    final db = NoteDatabase.instance;
    await db.create(NoteModel(text: text, editDate: DateTime.now()));
    notifyListeners();
  }

  Future<void> updateNote(NoteModel note) async {
    final db = NoteDatabase.instance;
    await db.update(note.copyWith(text: "Изменённая заметка"));
    notifyListeners();
  }

  Future<void> deleteNote(NoteModel note) async {
    final db = NoteDatabase.instance;
    await db.delete(note.id!);
    await getAllNotes();
  }
}
