import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/add_note_button.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/add_task_button.dart';

class NotesScreen extends ConsumerStatefulWidget {
  const NotesScreen({super.key});

  @override
  ConsumerState<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends ConsumerState<NotesScreen> {
  @override
  void initState() {
    super.initState();
    // грузим заметки при заходе на экран
    Future.microtask(() async {
      await ref.read(organizerController.notifier).getAllNotes();
    });
  }

  @override
  Widget build(BuildContext context) {
    final noteModel = ref.watch(organizerController);
    final notes = noteModel.myNotes;

    return Scaffold(
      floatingActionButton: AddNoteButton(),
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8, right: 8),
          child: ListView(
            children: [
              const CustomAppBar(text: "Мои заметки"),
              const SizedBox(height: 20),
              if (notes.isEmpty)
                Center(
                  child: Text(
                    "Нет заметок",
                    style: GoogleFonts.unbounded(
                      color: AppConstants.greyColor,
                      fontSize: 16,
                    ),
                  ),
                )
              else
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: notes.length,
                  itemBuilder: (context, index) {
                    final note = notes[index];
                    final formattedDate = DateFormat(
                      "dd.MM.yyyy HH:mm",
                    ).format(note.editDate);
                    return Slidable(
                      endActionPane: ActionPane(
                        motion: BehindMotion(),
                        children: [
                          SlidableAction(
                            borderRadius: BorderRadius.circular(4),
                            onPressed: (context) async {
                              await ref
                                  .read(organizerController)
                                  .deleteNote(note);
                            },
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.red,
                            icon: Icons.delete_rounded,
                            label: "удалить",
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: AnimatedButton(
                          onTap: () async {
                            Navigation.goToAddNoteScreen(context, note);
                            await ref.read(organizerController).getAllNotes();
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              color: AppConstants.secondaryColor.withOpacity(
                                0.6,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    note.text.isEmpty
                                        ? "Без текста"
                                        : note.text,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.unbounded(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    "Изменено: $formattedDate",
                                    style: GoogleFonts.unbounded(
                                      fontSize: 11,
                                      color: AppConstants.greyColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              const SizedBox(height: 400),
            ],
          ),
        ),
      ),
    );
  }
}
