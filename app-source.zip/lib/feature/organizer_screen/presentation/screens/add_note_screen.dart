import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/note_model.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/storages/note_database.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';

class AddNoteScreen extends ConsumerStatefulWidget {
  final NoteModel? note;

  const AddNoteScreen({super.key, this.note});

  @override
  _AddNoteScreenState createState() => _AddNoteScreenState();
}

class _AddNoteScreenState extends ConsumerState<AddNoteScreen> {
  late TextEditingController _controller;
  late NoteModel? _note;

  @override
  void initState() {
    super.initState();
    _note = widget.note;
    _controller = TextEditingController(text: _note?.text ?? "");
  }

  Future<void> _saveNote(String text) async {
    final db = NoteDatabase.instance;

    if (_note == null) {
      /// Создание новой заметки
      final id = await db.create(
        NoteModel(text: text, editDate: DateTime.now()),
      );
      _note = NoteModel(id: id, text: text, editDate: DateTime.now());
    } else {
      /// Обновление существующей заметки
      _note = _note!.copyWith(text: text, editDate: DateTime.now());
      await db.update(_note!);
      await ref.read(organizerController).getAllNotes();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      appBar: AppBar(
        backgroundColor: AppConstants.bgColor,
        titleTextStyle: TextStyle(fontSize: 14),
        title: Text(
          _note == null ? "Новая заметка" : "Редактирование",
          style: GoogleFonts.unbounded(),
        ),
        leading: AnimatedButton(
          onTap: () {
            Navigation.goBack(context);
          },
          child: Icon(Icons.arrow_back_ios),
        ),
      ),
      body: TextField(
        controller: _controller,
        cursorColor: AppConstants.darkGreenColor,
        autofocus: true,
        maxLines: null,
        expands: true, // растягивает TextField на весь экран
        textAlignVertical: TextAlignVertical.top,
        style: GoogleFonts.unbounded(fontSize: 14),
        decoration: const InputDecoration(
          border: InputBorder.none,
          contentPadding: EdgeInsets.all(16),
          hintText: "Начните писать заметку...",
        ),
        onChanged: (value) {
          _saveNote(value);
        },
      ),
    );
  }
}
