import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';

class HabitsAnalyticsScreen extends ConsumerStatefulWidget {
  const HabitsAnalyticsScreen({super.key});

  @override
  _HabitsAnalyticsScreenState createState() => _HabitsAnalyticsScreenState();
}

class _HabitsAnalyticsScreenState extends ConsumerState<HabitsAnalyticsScreen>
    with TickerProviderStateMixin {
  List<HabbitModel> activeGoodHabits = [];
  List<HabbitModel> activeBadHabits = [];
  bool _loading = true;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _getInfo();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _getInfo() async {
    setState(() => _loading = true);
    try {
      final good = ref.read(ghController).myActiveGoodHabbits;
      final bad = ref.read(bhController).myActiveBadHabbits;

      setState(() {
        activeGoodHabits = List<HabbitModel>.from(good);
        activeBadHabits = List<HabbitModel>.from(bad);
        _loading = false;
      });
      _animationController.forward();
    } catch (e) {
      setState(() {
        activeGoodHabits = [];
        activeBadHabits = [];
        _loading = false;
      });
      _animationController.forward();
    }
  }

  // --------------------- Метрики ---------------------
  int get totalGoodPoints =>
      activeGoodHabits.fold(0, (sum, h) => sum + (h.points ?? 0));
  int get totalBadPoints =>
      activeBadHabits.fold(0, (sum, h) => sum + (h.points ?? 0));

  int get totalMissions =>
      activeGoodHabits.fold(0, (sum, h) => sum + h.dailyMissions.length) +
      activeBadHabits.fold(0, (sum, h) => sum + h.dailyMissions.length);

  int get completedMissions =>
      activeGoodHabits.fold(
        0,
        (sum, h) => sum + h.dailyMissions.where((m) => m.isCompleted).length,
      ) +
      activeBadHabits.fold(
        0,
        (sum, h) => sum + h.dailyMissions.where((m) => m.isCompleted).length,
      );

  double get completionRate =>
      totalMissions == 0 ? 0 : (completedMissions / totalMissions) * 100;

  double get overallEfficiency {
    final avgStreak = _averageStreak();
    final streakFactor = (avgStreak / 30).clamp(0.0, 1.0);
    final completionFactor = (completionRate / 100).clamp(0.0, 1.0);
    return (completionFactor * 0.75 + streakFactor * 0.25) * 100;
  }

  double _averageStreak() {
    final all = [...activeGoodHabits, ...activeBadHabits];
    if (all.isEmpty) return 0.0;
    final total = all.fold(0, (sum, h) => sum + (h.streak ?? 0));
    return total / all.length;
  }

  double habitDailyCompletionRate(HabbitModel habit) {
    if (habit.dailyMissions.isEmpty) return 0.0;
    final done = habit.dailyMissions.where((m) => m.isCompleted).length;
    return done / habit.dailyMissions.length;
  }

  List<double> _last7Days(HabbitModel habit) {
    try {
      final dynamic raw = habit.additionalInfo?['history'];
      if (raw is List) {
        final list =
            raw
                .map((e) => e is num ? (e.toDouble()).clamp(0.0, 1.0) : 0.0)
                .toList();
        if (list.length >= 7) return list.sublist(list.length - 7);
        final padded = List<double>.filled(7 - list.length, 0.0);
        padded.addAll(list.cast<double>());
        return padded;
      }
    } catch (_) {}

    final base = habitDailyCompletionRate(habit);
    final rnd = List<double>.generate(7, (i) {
      final factor = 0.6 + (i / 14);
      return (base * factor).clamp(0.0, 1.0);
    });
    return rnd;
  }

  // --------------------- UI ---------------------
  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: AppConstants.bgColor,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const CircularProgressIndicator(
                  strokeWidth: 3,
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6366F1)),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Загружаем аналитику...',
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xFF64748B),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildAppBar(),
          SliverToBoxAdapter(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: RefreshIndicator(
                onRefresh: _getInfo,
                color: AppConstants.bgGreyColor,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 10, 32),
                  child: Column(
                    children: [
                      _buildOverviewCard(),
                      const SizedBox(height: 24),
                      _buildChartsSection(),
                      const SizedBox(height: 24),
                      _buildHabitsSection(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      expandedHeight: 50,
      floating: true,
      pinned: true,
      elevation: 0,
      backgroundColor: AppConstants.bgGreyColor,
      flexibleSpace: FlexibleSpaceBar(
        title: const Text(
          'Аналитика привычек',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
        background: Container(
          decoration: const BoxDecoration(color: AppConstants.bgColor),
        ),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
        onPressed: () => Navigator.pop(context),
      ),
    );
  }

  Widget _buildOverviewCard() {
    final totalHabits = activeGoodHabits.length + activeBadHabits.length;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppConstants.bgGreyColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Круговая диаграмма
              SizedBox(
                width: 80,
                height: 80,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (totalHabits > 0)
                      PieChart(
                        PieChartData(
                          centerSpaceRadius: 25,
                          sectionsSpace: 3,
                          startDegreeOffset: -90,
                          sections: [
                            if (activeGoodHabits.isNotEmpty)
                              PieChartSectionData(
                                value: activeGoodHabits.length.toDouble(),
                                color: AppConstants.darkGreenColor,
                                title: '',
                                radius: 20,
                              ),
                            if (activeBadHabits.isNotEmpty)
                              PieChartSectionData(
                                value: activeBadHabits.length.toDouble(),
                                color: const Color(0xFFEF4444),
                                title: '',
                                radius: 20,
                              ),
                          ],
                        ),
                      )
                    else
                      Container(
                        width: 120,
                        height: 120,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xFFF1F5F9),
                        ),
                      ),
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: const Color(0xFF6366F1),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF6366F1).withOpacity(0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '$totalHabits',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Text(
                            'всего',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 24),

              // Статистика
              Expanded(
                child: Column(
                  children: [
                    Row(
                      children: [
                        _buildStatCard(
                          'Хорошие',
                          '${activeGoodHabits.length}',
                          AppConstants.darkGreenColor,
                          Icons.trending_up_rounded,
                          MediaQuery.of(context).size.width * 0.26,
                        ),
                        const SizedBox(width: 16),
                        _buildStatCard(
                          'Плохие',
                          '${activeBadHabits.length}',
                          const Color(0xFFEF4444),
                          Icons.trending_down_rounded,
                          MediaQuery.of(context).size.width * 0.26,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _buildStatCard(
                'Выполнено',
                '$completedMissions/$totalMissions',
                const Color(0xFF3B82F6),
                Icons.check_circle_outline_rounded,
                MediaQuery.of(context).size.width * 0.39,
              ),
              const SizedBox(width: 16),
              _buildStatCard(
                'Эффективность',
                '${overallEfficiency.round()}%',
                const Color(0xFF8B5CF6),
                Icons.speed_rounded,
                MediaQuery.of(context).size.width * 0.39,
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Прогресс-бар
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppConstants.bgColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Процент выполнения',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppConstants.whiteColor,
                      ),
                    ),
                    Text(
                      '${completionRate.toStringAsFixed(1)}%',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF6366F1),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: completionRate / 100,
                  backgroundColor: const Color(0xFFE5E7EB),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    completionRate >= 80
                        ? AppConstants.darkGreenColor
                        : completionRate >= 50
                        ? const Color(0xFF3B82F6)
                        : const Color(0xFFF59E0B),
                  ),
                  minHeight: 6,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    Color color,
    IconData icon,
    double width,
  ) {
    return Container(
      width: width,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 20),
              SizedBox(width: 8),
              Text(
                value,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              color: color.withOpacity(0.8),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChartsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Графики и тренды',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppConstants.whiteColor,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: _buildPointsChart()),
            const SizedBox(width: 16),
            Expanded(child: _buildWeeklyTrendChart()),
          ],
        ),
      ],
    );
  }

  Widget _buildPointsChart() {
    final goodSum = totalGoodPoints.toDouble();
    final badSum = totalBadPoints.toDouble();
    final maxY = (goodSum > badSum ? goodSum : badSum) + 50;

    return Container(
      height: 220,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppConstants.secondaryColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Очки',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppConstants.whiteColor,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: BarChart(
              BarChartData(
                maxY: maxY > 0 ? maxY : 100,
                barGroups: [
                  BarChartGroupData(
                    barsSpace: 20,
                    x: 0,
                    barRods: [
                      BarChartRodData(
                        toY: goodSum,
                        gradient: const LinearGradient(
                          colors: [
                            AppConstants.darkGreenColor,
                            Color(0xFF34D399),
                          ],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                        width: 40,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ],
                  ),
                  BarChartGroupData(
                    barsSpace: 20,
                    x: 1,
                    barRods: [
                      BarChartRodData(
                        toY: badSum,
                        gradient: const LinearGradient(
                          colors: [Color(0xFFF87171), Color(0xFFEF4444)],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                        width: 40,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ],
                  ),
                ],
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        switch (value.toInt()) {
                          case 0:
                            return const Text(
                              'Хорошие',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            );
                          case 1:
                            return const Text(
                              'Плохие',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            );
                          default:
                            return const SizedBox();
                        }
                      },
                    ),
                  ),
                  leftTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWeeklyTrendChart() {
    final all = [...activeGoodHabits, ...activeBadHabits];
    final merged = List<double>.filled(7, 0.0);

    if (all.isNotEmpty) {
      for (var i = 0; i < 7; i++) {
        double daySum = 0;
        for (final h in all) {
          final arr = _last7Days(h);
          daySum += arr[i];
        }
        merged[i] = daySum / all.length;
      }
    }

    final spots =
        merged
            .asMap()
            .entries
            .map((e) => FlSpot(e.key.toDouble(), (e.value * 100)))
            .toList();

    return Container(
      height: 220,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppConstants.secondaryColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Тренд за неделю',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppConstants.whiteColor,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: 100,
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 33,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: const Color(0xFFE5E7EB),
                      strokeWidth: 1,
                    );
                  },
                ),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        const labels = [
                          'Пн',
                          'Вт',
                          'Ср',
                          'Чт',
                          'Пт',
                          'Сб',
                          'Вс',
                        ];
                        final idx = value.toInt();
                        if (idx >= 0 && idx < labels.length) {
                          return Text(
                            labels[idx],
                            style: const TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              color: Color(0xFF9CA3AF),
                            ),
                          );
                        }
                        return const SizedBox();
                      },
                    ),
                  ),
                  leftTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    curveSmoothness: 0.5,
                    color: AppConstants.darkGreenColor,
                    barWidth: 3,
                    isStrokeCapRound: true,
                    dotData: FlDotData(
                      show: true,
                      getDotPainter: (spot, percent, barData, index) {
                        return FlDotCirclePainter(
                          radius: 4,
                          color: AppConstants.bgColor,
                          strokeWidth: 2,
                          strokeColor: AppConstants.darkGreenColor,
                        );
                      },
                    ),
                    belowBarData: BarAreaData(
                      show: true,
                      color: AppConstants.darkGreenColor.withOpacity(0.05),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHabitsSection() {
    final all = [...activeGoodHabits, ...activeBadHabits];

    if (all.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: const Column(
          children: [
            Icon(Icons.insights_rounded, size: 64, color: Color(0xFF9CA3AF)),
            SizedBox(height: 16),
            Text(
              'Нет привычек для анализа',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Color(0xFF6B7280),
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Добавьте привычки, чтобы увидеть подробную аналитику',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Color(0xFF9CA3AF)),
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Детальная статистика',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppConstants.whiteColor,
          ),
        ),
        const SizedBox(height: 16),
        ...all.map((habit) => _buildHabitCard(habit)).toList(),
      ],
    );
  }

  Widget _buildHabitCard(HabbitModel habit) {
    final rate = (habitDailyCompletionRate(habit) * 100).round();
    final last7 = _last7Days(habit);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppConstants.secondaryColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  gradient: LinearGradient(
                    colors:
                        habit.isGoodHabbit
                            ? [const Color(0xFF34D399), const Color(0xFF10B981)]
                            : [
                              const Color(0xFFF87171),
                              const Color(0xFFEF4444),
                            ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child:
                    habit.imagePath.isNotEmpty
                        ? ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Image.asset(
                              habit.imagePath,
                              fit: BoxFit.cover,
                            ),
                          ),
                        )
                        : Icon(
                          habit.isGoodHabbit
                              ? Icons.trending_up_rounded
                              : Icons.trending_down_rounded,
                          color: Colors.white,
                          size: 24,
                        ),
              ),
              SizedBox(width: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    habit.habbitName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppConstants.whiteColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      _buildMiniStat('Стрик', '${habit.streak ?? 0}'),
                      const SizedBox(width: 16),
                      _buildMiniStat('Очки', '${habit.points ?? 0}'),
                      const SizedBox(width: 16),
                      _buildMiniStat('Сегодня', '$rate%'),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMiniStat(String title, String value) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: const Color(0xFF6366F1).withOpacity(0.1),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: Color(0xFF6366F1),
            ),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          title,
          style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF)),
        ),
      ],
    );
  }

  Widget _buildDetailStat(String title, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFF6366F1), size: 20),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1F2937),
              ),
            ),
            const SizedBox(height: 2),
            Text(
              title,
              style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF)),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
