import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/purchase/pay_controller.dart';

class MenuWidget extends ConsumerWidget {
  const MenuWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AnimatedButton(
              onTap: () async {
                ref.read(payController).showPlans(context);
              },
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: AppConstants.darkGreenColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.local_activity,
                        size: 16,
                        color: AppConstants.bgColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  SizedBox(
                    width: 88,
                    child: Text(
                      "подписка",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 8),
            AnimatedButton(
              onTap: () async {
                Navigation.goToNotesScreen(context);
              },
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: AppConstants.secondaryColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.edit,
                        size: 16,
                        color: AppConstants.whiteColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  SizedBox(
                    width: 88,
                    child: Text(
                      "заметки",
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 8),
            AnimatedButton(
              onTap: () async {
                Navigation.goToAnalyticsScreen(context);
              },
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: AppConstants.secondaryColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.stacked_bar_chart,
                        size: 16,
                        color: AppConstants.whiteColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  SizedBox(
                    width: 88,
                    child: Text(
                      "статистика",
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 8),
            AnimatedButton(
              onTap: () {
                Navigation.goToSettingsScreen(context);
              },
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: AppConstants.secondaryColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.settings,
                        size: 16,
                        color: AppConstants.whiteColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  SizedBox(
                    width: 88,
                    child: Text(
                      "настройки",
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
