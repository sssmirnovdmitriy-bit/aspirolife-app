import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';

final selectedDateProvider = StateProvider<DateTime>((ref) {
  return DateTime.now();
});

class HorizontalCalendar extends ConsumerStatefulWidget {
  @override
  _HorizontalCalendarState createState() => _HorizontalCalendarState();
}

class _HorizontalCalendarState extends ConsumerState<HorizontalCalendar> {
  final ScrollController _scrollController = ScrollController();
  final int pastDays = 7;
  final int futureDays = 365;
  late int todayIndex;
  bool showTodayButton = false;

  @override
  void initState() {
    super.initState();
    todayIndex = pastDays; // Сегодняшний день в списке
    _scrollController.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToToday();
    });
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.offset > todayIndex * 64.0 + 14) {
      if (!showTodayButton) {
        setState(() => showTodayButton = true);
      }
    } else {
      if (showTodayButton) {
        setState(() => showTodayButton = false);
      }
    }
  }

  void _scrollToToday() async {
    ref.read(selectedDateProvider.notifier).state = DateTime.now();
    await ref
        .read(organizerController)
        .getAllDailyMissionsByDate(ref, DateTime.now());
    await ref.read(organizerController).getAllTasksByDate(DateTime.now());
    Future.delayed(Duration(milliseconds: 100), () {
      _scrollController.animateTo(
        todayIndex * 64.0,
        duration: Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  // void _openFullScreenCalendar() async {
  //   final selectedDate = await Navigator.push(
  //     context,
  //     MaterialPageRoute(builder: (context) => FullScreenCalendar()),
  //   );

  //   if (selectedDate != null) {
  //     ref.read(selectedDateProvider.notifier).state = selectedDate;
  //     _scrollToSelectedDate();
  //   }
  // }

  void _scrollToSelectedDate() {
    DateTime today = DateTime.now();
    DateTime firstDisplayedDay = today.subtract(Duration(days: pastDays));

    // Вычисляем индекс выбранного дня относительно первого отображаемого дня
    int selectedIndex =
        ref
            .read(selectedDateProvider.notifier)
            .state
            .difference(firstDisplayedDay)
            .inDays;

    // Убеждаемся, что индекс не выходит за границы
    if (selectedIndex < 0) selectedIndex = 0;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollController.animateTo(
        selectedIndex * 68.0, // 64 — высота одного дня
        duration: Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    var organizerModel = ref.watch(organizerController);
    final selectedDate = ref.watch(selectedDateProvider);
    final today = DateTime.now();
    final totalDays = pastDays + futureDays + 1;
    // var personaModel = ref.watch(personaController);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                DateFormat('d MMMM', 'ru').format(selectedDate),
                style: GoogleFonts.unbounded(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                ", ${DateFormat('EEEE', 'ru').format(selectedDate)}",
                style: GoogleFonts.unbounded(color: Colors.white, fontSize: 14),
              ),
              Spacer(),
              showTodayButton
                  ? Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: AnimatedButton(
                      onTap: _scrollToToday,
                      child: Text(
                        "Вернуться к сегодня",
                        style: GoogleFonts.unbounded(
                          color: Colors.white,
                          fontSize: 10,
                        ),
                      ),
                    ),
                  )
                  : SizedBox(width: 40),
            ],
          ),
        ),

        SizedBox(
          height: 100,
          child: ListView.builder(
            controller: _scrollController,
            scrollDirection: Axis.horizontal,
            itemCount: totalDays,
            itemBuilder: (context, index) {
              final date = today.add(Duration(days: index - pastDays));
              final isSelected =
                  date.day == selectedDate.day &&
                  date.month == selectedDate.month &&
                  date.year == selectedDate.year;
              final isPast = date.isBefore(today);

              return GestureDetector(
                onTap: () async {
                  ref.read(selectedDateProvider.notifier).state = date;
                  await ref
                      .read(organizerController)
                      .getAllDailyMissionsByDate(ref, date);
                  await ref.read(organizerController).getAllTasksByDate(date);
                  await ref
                      .read(organizerController)
                      .getAllEntertainmentsByDate(date);
                },
                child: Container(
                  width: 60,
                  margin: EdgeInsets.symmetric(horizontal: 4, vertical: 10),
                  decoration: BoxDecoration(
                    color:
                        isSelected
                            ? AppConstants.darkGreenColor
                            : AppConstants.secondaryColor.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        DateFormat.E('ru').format(date),
                        style: GoogleFonts.unbounded(
                          color:
                              isSelected
                                  ? AppConstants.secondaryColor
                                  : (isPast
                                      ? Colors.grey.withOpacity(0.7)
                                      : Colors.white),
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        '${date.day}',
                        style: GoogleFonts.unbounded(
                          color:
                              isSelected
                                  ? AppConstants.secondaryColor
                                  : (isPast
                                      ? Colors.grey.withOpacity(0.7)
                                      : Colors.white),
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        DateFormat.MMM('ru').format(date),
                        style: GoogleFonts.unbounded(
                          color:
                              isSelected
                                  ? AppConstants.secondaryColor
                                  : (isPast
                                      ? Colors.grey.withOpacity(0.7)
                                      : Colors.white),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
