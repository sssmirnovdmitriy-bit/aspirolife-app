import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/services/money_counter/money_count_controller.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';
import 'package:organizer/feature/organizer_screen/data/habbit_and_mission_model.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/calendar.dart';

class HabbitDailyMissionCard extends ConsumerWidget {
  final HabbitAndMissionModel habbitDailyMission;
  const HabbitDailyMissionCard({super.key, required this.habbitDailyMission});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final today = DateTime.now();
    final isToday =
        habbitDailyMission.dailyMission.startDate != null &&
        habbitDailyMission.dailyMission.startDate!.year == today.year &&
        habbitDailyMission.dailyMission.startDate!.month == today.month &&
        habbitDailyMission.dailyMission.startDate!.day == today.day;
    return GestureDetector(
      onTap: () async {
        if (isToday) {
          if (habbitDailyMission.habbitModel.isGoodHabbit) {
            await ref
                .read(ghController)
                .confirmMission(
                  context,
                  habbitDailyMission.dailyMission,
                  habbitDailyMission.habbitModel,
                );
          } else {
            await ref
                .read(bhController)
                .confirmMission(
                  context,
                  habbitDailyMission.dailyMission,
                  habbitDailyMission.habbitModel,
                );
          }

          await ref
              .read(organizerController)
              .getAllDailyMissionsByDate(
                ref,
                ref.read(selectedDateProvider.notifier).state,
              );
          await ref.read(moneyCountController).getMyMoneySavings(ref);
        } else {
          AppNotifications.showError(
            context,
            "Подтверждать можно только сегодняшние миссии",
          );
          // Можно показать Snackbar или диалог
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color:
              habbitDailyMission.habbitModel.isGoodHabbit
                  ? AppConstants.darkGreenColor.withAlpha(20)
                  : Colors.redAccent.withAlpha(20),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.all(7.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  habbitDailyMission.dailyMission.isCompleted
                      ? Icon(
                        Icons.check_circle,
                        size: 18,
                        color: AppConstants.darkGreenColor,
                      )
                      : Icon(
                        Icons.circle_outlined,
                        size: 18,
                        color: AppConstants.whiteColor,
                      ),

                  SizedBox(width: 6),
                  Text(
                    habbitDailyMission.habbitModel.habbitName,
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 6),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.7,
                child: Text(
                  habbitDailyMission.dailyMission.missionText,
                  style: GoogleFonts.unbounded(
                    color:
                        habbitDailyMission.habbitModel.isGoodHabbit
                            ? AppConstants.darkGreenColor
                            : Colors.redAccent,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
