import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';

class AddNoteButton extends ConsumerWidget {
  const AddNoteButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AnimatedButton(
      onTap: () async {
        Navigation.goToAddNoteScreen(context, null);
      },
      child: Container(
        decoration: BoxDecoration(
          color: AppConstants.darkGreenColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Text(
            "+ заметка",
            style: GoogleFonts.unbounded(color: AppConstants.bgColor),
          ),
        ),
      ),
    );
  }
}
