import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/organizer_screen/data/task_radiomodel.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/calendar.dart';

class AddTaskScreen extends ConsumerStatefulWidget {
  const AddTaskScreen({super.key});

  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends ConsumerState<AddTaskScreen> {
  TextEditingController _controller = TextEditingController();
  bool isEnabled = false;

  @override
  Widget build(BuildContext context) {
    var organizerModel = ref.watch(organizerController);
    return Scaffold(
      bottomNavigationBar:
          !isEnabled
              ? Padding(
                padding: const EdgeInsets.only(
                  left: 14.0,
                  right: 14,
                  bottom: 20,
                ),
                child: AnimatedButton(
                  onTap: () async {},
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppConstants.greyColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Center(
                        child: Text(
                          "Добавить",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              )
              : Padding(
                padding: const EdgeInsets.only(
                  left: 14.0,
                  right: 14,
                  bottom: 20,
                ),
                child: AnimatedButton(
                  onTap: () async {
                    var date = ref.read(selectedDateProvider.notifier).state;
                    await ref
                        .read(organizerController)
                        .createTask(_controller.text, date);
                    Navigation.goBack(context);
                  },
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppConstants.darkGreenColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Center(
                        child: Text(
                          "Добавить",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.bgColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                CustomAppBar(text: "Добавить личную задачу"),
                SizedBox(height: 20),
                Row(
                  children: [
                    Text(
                      "Опишите задачу",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                SizedBox(
                  height: 150,
                  child: TextInputField(
                    controller: _controller,
                    hintText: "Например, выполнить задачу по работе",
                    height: 100,
                    maxLines: 10,
                    minLines: null,
                    maxLength: 200,
                    onChanged: (value) {
                      if (_controller.text.length >= 3) {
                        setState(() {
                          isEnabled = true;
                        });
                      } else {
                        setState(() {
                          isEnabled = false;
                        });
                      }
                    },
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  children: [
                    Text(
                      "Приоритет задачи",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.08,
                  width: MediaQuery.of(context).size.width,
                  child: ListView.builder(
                    padding: EdgeInsets.zero,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: organizerModel.myTaskPriorities.length,
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              for (var element
                                  in organizerModel.myTaskPriorities) {
                                element.isSelected = false;
                              }
                              organizerModel
                                  .myTaskPriorities[index]
                                  .isSelected = true;
                              ref
                                  .read(organizerController)
                                  .chooseTaskPriority(
                                    organizerModel.myTaskPriorities[index],
                                  );
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 4.0),
                            child: TaskRadioItem(
                              organizerModel.myTaskPriorities[index],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
