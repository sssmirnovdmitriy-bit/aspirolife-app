import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/task_model.dart';
import 'package:organizer/core/storages/task_database.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/calendar.dart';

class TaskCard extends ConsumerWidget {
  final TaskModel taskModel;
  const TaskCard({super.key, required this.taskModel});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var selectedColor;
    if (taskModel.priority == 0) {
      selectedColor = AppConstants.darkGreenColor;
    }
    if (taskModel.priority == 1) {
      selectedColor = const Color.fromARGB(255, 234, 255, 0);
    }

    if (taskModel.priority == 2) {
      selectedColor = const Color.fromARGB(255, 255, 162, 0);
    }

    if (taskModel.priority == 3) {
      selectedColor = const Color.fromARGB(255, 255, 38, 0);
    }
    return Slidable(
      endActionPane: ActionPane(
        motion: BehindMotion(),
        children: [
          SlidableAction(
            borderRadius: BorderRadius.circular(4),
            // An action can be bigger than the others.
            onPressed: (context) async {
              if (taskModel.isPinned) {
                await TaskService().pinTask(taskModel.id!, false);
              } else {
                await TaskService().pinTask(taskModel.id!, true);
              }
              await ref
                  .read(organizerController)
                  .getAllTasksByDate(
                    ref.read(selectedDateProvider.notifier).state,
                  );
            },
            backgroundColor: Colors.transparent,
            foregroundColor:
                taskModel.isPinned
                    ? AppConstants.greyColor
                    : AppConstants.darkGreenColor,
            icon: Icons.attach_file_outlined,
            label: taskModel.isPinned ? 'открепить' : 'закрепить',
          ),
          SlidableAction(
            borderRadius: BorderRadius.circular(4),
            onPressed: (context) async {
              await ref
                  .read(organizerController)
                  .deleteTask(
                    taskModel,
                    ref.read(selectedDateProvider.notifier).state,
                  );
            },
            backgroundColor: Colors.transparent,
            foregroundColor: Colors.red,
            icon: Icons.delete_rounded,
            label: "удалить",
          ),
        ],
      ),
      child: GestureDetector(
        onTap: () async {
          await ref
              .read(organizerController)
              .makeTaskCompleted(
                taskModel,
                ref.read(selectedDateProvider.notifier).state,
              );
        },
        child: Container(
          decoration: BoxDecoration(
            color: AppConstants.secondaryColor.withOpacity(0.6),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child:
                    taskModel.isCompleted
                        ? Icon(
                          Icons.check_circle,
                          size: 18,
                          color: AppConstants.darkGreenColor,
                        )
                        : Icon(
                          Icons.circle_outlined,
                          size: 18,
                          color: AppConstants.whiteColor,
                        ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 4.0),
                child:
                    taskModel.isPinned
                        ? Icon(
                          Icons.attach_file_outlined,
                          color: AppConstants.greyColor,
                        )
                        : SizedBox(),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0, bottom: 8),
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.76,
                  child: Text(
                    taskModel.text,
                    maxLines: 2,
                    style: GoogleFonts.unbounded(
                      color: AppConstants.whiteColor,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Spacer(),
              Container(
                height: 60,
                width: 6,
                decoration: BoxDecoration(
                  color: selectedColor,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(10),
                    bottomRight: Radius.circular(10),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
