import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/add_task_button.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/calendar.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/entertainment_card.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/habbit_daily_mission_card.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/menu_widget.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/task_card.dart';

class OrganizerScreen extends ConsumerWidget {
  const OrganizerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var organizerModel = ref.watch(organizerController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      floatingActionButton: AddTaskButton(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  MenuWidget(),
                  SizedBox(height: 4),

                  HorizontalCalendar(),

                  organizerModel.goodHabbitsDailyMissions.isNotEmpty
                      ? SizedBox(height: 8)
                      : SizedBox(),
                  organizerModel.goodHabbitsDailyMissions.isNotEmpty
                      ? Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Задачи по хорошим привычкам",
                              style: GoogleFonts.unbounded(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              " ${organizerModel.goodHabbitsDailyMissions.where((e) => e.dailyMission.isCompleted).length}"
                              "/${organizerModel.goodHabbitsDailyMissions.length}",
                              style: GoogleFonts.unbounded(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      )
                      : SizedBox(),
                  organizerModel.goodHabbitsDailyMissions.isNotEmpty
                      ? SizedBox(
                        height: 98, // чуть больше, чтобы текст влезал
                        width: MediaQuery.of(context).size.width,
                        child: ListView.builder(
                          padding: EdgeInsets.zero,
                          scrollDirection: Axis.horizontal,
                          itemCount:
                              organizerModel.goodHabbitsDailyMissions.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 8,
                              ),
                              child: IntrinsicHeight(
                                // Автоматическая подстройка карточки
                                child: HabbitDailyMissionCard(
                                  habbitDailyMission:
                                      organizerModel
                                          .goodHabbitsDailyMissions[index],
                                ),
                              ),
                            );
                          },
                        ),
                      )
                      : SizedBox(),
                  organizerModel.badHabbitsDailyMissions.isNotEmpty
                      ? SizedBox(height: 4)
                      : SizedBox(),
                  organizerModel.badHabbitsDailyMissions.isNotEmpty
                      ? Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Задачи по вредным привычкам",
                              style: GoogleFonts.unbounded(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              " ${organizerModel.badHabbitsDailyMissions.where((e) => e.dailyMission.isCompleted).length}"
                              "/${organizerModel.badHabbitsDailyMissions.length}",
                              style: GoogleFonts.unbounded(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      )
                      : SizedBox(),
                  organizerModel.badHabbitsDailyMissions.isNotEmpty
                      ? SizedBox(
                        height: 98, // чуть больше, чтобы текст влезал
                        width: MediaQuery.of(context).size.width,
                        child: ListView.builder(
                          padding: EdgeInsets.zero,
                          scrollDirection: Axis.horizontal,
                          itemCount:
                              organizerModel.badHabbitsDailyMissions.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 8,
                              ),
                              child: IntrinsicHeight(
                                // Автоматическая подстройка карточки
                                child: HabbitDailyMissionCard(
                                  habbitDailyMission:
                                      organizerModel
                                          .badHabbitsDailyMissions[index],
                                ),
                              ),
                            );
                          },
                        ),
                      )
                      : SizedBox(),
                  organizerModel.allTasks.isNotEmpty
                      ? SizedBox(height: 4)
                      : SizedBox(),
                  organizerModel.allTasks.isNotEmpty
                      ? Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "Личные задачи",
                              style: GoogleFonts.unbounded(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      )
                      : SizedBox(),
                  organizerModel.allTasks.isNotEmpty
                      ? ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: organizerModel.allTasks.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: TaskCard(
                              taskModel: organizerModel.allTasks[index],
                            ),
                          );
                        },
                      )
                      : SizedBox(),
                  organizerModel.allEntertainments.isNotEmpty
                      ? SizedBox(height: 4)
                      : SizedBox(),
                  organizerModel.allEntertainments.isNotEmpty
                      ? Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "Развлечения",
                              style: GoogleFonts.unbounded(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      )
                      : SizedBox(),
                  organizerModel.allEntertainments.isNotEmpty
                      ? SizedBox(
                        height: 100, // задай больше места, чтобы влез текст
                        width: MediaQuery.of(context).size.width,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: organizerModel.allEntertainments.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: EntertainmentCard(
                                model: organizerModel.allEntertainments[index],
                              ),
                            );
                          },
                        ),
                      )
                      : SizedBox(),
                  SizedBox(height: 600),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
