import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_gh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';
import 'package:organizer/feature/organizer_screen/data/task_radiomodel.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/widgets/calendar.dart';

class AddMyHabbitScreen extends ConsumerStatefulWidget {
  final bool isGoodHabbit;
  const AddMyHabbitScreen(this.isGoodHabbit, {super.key});

  @override
  _AddMyHabbitScreenState createState() => _AddMyHabbitScreenState();
}

class _AddMyHabbitScreenState extends ConsumerState<AddMyHabbitScreen> {
  TextEditingController _controller = TextEditingController();
  bool isEnabled = false;

  @override
  Widget build(BuildContext context) {
    var organizerModel = ref.watch(organizerController);
    return Scaffold(
      bottomNavigationBar:
          !isEnabled
              ? Padding(
                padding: const EdgeInsets.only(
                  left: 14.0,
                  right: 14,
                  bottom: 20,
                  top: 10,
                ),
                child: AnimatedButton(
                  onTap: () async {},
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppConstants.greyColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Center(
                        child: Text(
                          "Добавить",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              )
              : Padding(
                padding: const EdgeInsets.only(
                  left: 14.0,
                  right: 14,
                  bottom: 20,
                  top: 10,
                ),
                child: AnimatedButton(
                  onTap: () async {
                    if (widget.isGoodHabbit) {
                      await ref
                          .read(addGhController)
                          .addMyGoodHabitToBD(context, ref, _controller.text);
                    } else {
                      await ref
                          .read(addBhController)
                          .addMyBadHabitToBD(context, ref, _controller.text);
                    }

                    Navigation.goBack(context);
                  },
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppConstants.darkGreenColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Center(
                        child: Text(
                          "Добавить",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.bgColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                CustomAppBar(text: "Добавить cвою привычку"),
                SizedBox(height: 20),
                Row(
                  children: [
                    Text(
                      "Название привычки",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                SizedBox(
                  height: 150,
                  child: TextInputField(
                    controller: _controller,
                    hintText: 'Например, "Ранний подъем"',
                    height: 100,
                    maxLines: 10,
                    minLines: null,
                    maxLength: 20,
                    onChanged: (value) {
                      if (_controller.text.length >= 3) {
                        setState(() {
                          isEnabled = true;
                        });
                      } else {
                        setState(() {
                          isEnabled = false;
                        });
                      }
                    },
                  ),
                ),
                SizedBox(height: 200),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
