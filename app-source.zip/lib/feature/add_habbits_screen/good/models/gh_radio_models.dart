enum GoodHabbitType { FAST, SLOW }

class GoodHabbitTypeRadioModel {
  bool isSelected;
  String name;
  String type;
  String description;

  GoodHabbitTypeRadioModel(
    this.isSelected,
    this.type,
    this.name,
    this.description,
  );
}
