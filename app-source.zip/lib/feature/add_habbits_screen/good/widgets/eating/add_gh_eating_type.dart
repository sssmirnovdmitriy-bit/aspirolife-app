import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_gh_controller.dart';
import 'package:organizer/feature/add_habbits_screen/good/models/gh_radio_models.dart';

class AddGhEatingType extends ConsumerStatefulWidget {
  const AddGhEatingType({super.key});

  @override
  _AddGhEatingTypeState createState() => _AddGhEatingTypeState();
}

class _AddGhEatingTypeState extends ConsumerState<AddGhEatingType> {
  @override
  Widget build(BuildContext context) {
    var ghModel = ref.watch(addGhController);
    return Column(
      children: [
        Row(
          children: [
            Text(
              "Выберите режим*",
              style: GoogleFonts.unbounded(
                color: AppConstants.whiteColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        SizedBox(height: 10),
        SizedBox(
          // height: MediaQuery.of(context).size.height * 0.24,
          child: ListView.builder(
            physics: NeverScrollableScrollPhysics(),
            itemCount: ghModel.myEatingTypes.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      for (var element in ghModel.myEatingTypes) {
                        element.isSelected = false;
                      }
                      ghModel.myEatingTypes[index].isSelected = true;
                      ref
                          .read(addGhController)
                          .chooseEatingType(ghModel.myEatingTypes[index]);
                    });
                  },
                  child: TypeRadioItem(ghModel.myEatingTypes[index]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class TypeRadioItem extends StatelessWidget {
  final GoodHabbitTypeRadioModel _item;
  TypeRadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.1,
          width: MediaQuery.of(context).size.height * 0.15,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.1,
                width: MediaQuery.of(context).size.height * 0.15,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color:
                      _item.isSelected
                          ? AppConstants.darkGreenColor
                          : AppConstants.secondaryColor,
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      _item.name,
                      style: GoogleFonts.unbounded(
                        color:
                            _item.isSelected
                                ? AppConstants.bgColor
                                : AppConstants.whiteColor,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 10),
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.6,
          child: Text(
            _item.description,
            style: GoogleFonts.unbounded(
              color: AppConstants.whiteColor,
              fontSize: 12,
            ),
          ),
        ),
      ],
    );
  }
}
