import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/storages/mock_habbit_storage.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/add_bh_description_section.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/add_bh_prizes_section.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_gh_controller.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/eating/add_gh_eating_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/eating/add_gh_eating_type.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/gym/add_gh_gym_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/gym/add_gh_gym_type.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/hardening/add_gh_hardening_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/hardening/add_gh_hardening_types.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/jogging/add_gh_jogging_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/jogging/add_gh_jogging_type.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/meditation/add_gh_meditation_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/meditation/add_gh_meditation_type.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/workout/add_gh_workout_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/workout/add_gh_workout_type.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/yoga/add_gh_yoga_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/good/widgets/yoga/add_gh_yoga_type.dart';

class AddGhScreenSecond extends ConsumerStatefulWidget {
  final HabbitModel habbitModel;
  const AddGhScreenSecond({required this.habbitModel, super.key});

  @override
  _AddGhScreenSecondState createState() => _AddGhScreenSecondState();
}

class _AddGhScreenSecondState extends ConsumerState<AddGhScreenSecond> {
  @override
  Widget build(BuildContext context) {
    var ghModel = ref.watch(addGhController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Builder(
        builder: (context) {
          if (widget.habbitModel.habbitType == GoodHabitTypes.JOGGING.name) {
            return AddGhJoggingNavbar();
          } else if (widget.habbitModel.habbitType ==
              GoodHabitTypes.YOGA.name) {
            return AddGhYogaNavbar();
          } else if (widget.habbitModel.habbitType ==
              GoodHabitTypes.EATING.name) {
            return AddGhEatingNavbar();
          } else if (widget.habbitModel.habbitType == GoodHabitTypes.GYM.name) {
            return AddGhGymNavbar();
          } else if (widget.habbitModel.habbitType ==
              GoodHabitTypes.MEDITATION.name) {
            return AddGhMeditationNavbar();
          } else if (widget.habbitModel.habbitType ==
              GoodHabitTypes.HARDENING.name) {
            return AddGhHardeningNavbar();
          } else if (widget.habbitModel.habbitType ==
              GoodHabitTypes.WORKOUT.name) {
            return AddGhWorkoutNavbar();
          } else {
            return SizedBox();
          }
        },
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(
                text: "Новая привычка (${widget.habbitModel.habbitName})",
              ),
              Expanded(
                child: ListView(
                  children: [
                    AddBhDescriptionSection(widget.habbitModel),
                    SizedBox(height: 10),
                    AddBhPrizesSection(habbitModel: widget.habbitModel),
                    SizedBox(height: 30),
                    Builder(
                      builder: (context) {
                        if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.JOGGING.name) {
                          return Column(
                            children: [
                              AddGhJoggingType(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.YOGA.name) {
                          return Column(
                            children: [AddGhYogaType(), SizedBox(height: 20)],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.EATING.name) {
                          return Column(
                            children: [AddGhEatingType(), SizedBox(height: 20)],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.GYM.name) {
                          return Column(
                            children: [AddGhGymType(), SizedBox(height: 20)],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.MEDITATION.name) {
                          return Column(
                            children: [
                              AddGhMeditationType(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.HARDENING.name) {
                          return Column(
                            children: [
                              AddGhHardeningType(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.WORKOUT.name) {
                          return Column(
                            children: [
                              AddGhWorkoutType(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else {
                          return SizedBox();
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
