import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/services/money_counter/money_count_controller.dart';
import 'package:organizer/core/storages/habbit_database.dart';
import 'package:organizer/core/storages/mock_eating_daily_missions.dart';
import 'package:organizer/core/storages/mock_gym_daily_missions.dart';
import 'package:organizer/core/storages/mock_habbit_storage.dart';
import 'package:organizer/core/storages/mock_hardening_daily_missions.dart';
import 'package:organizer/core/storages/mock_jogging_daily_missions.dart';
import 'package:organizer/core/storages/mock_meditation_daily_missions.dart';
import 'package:organizer/core/storages/mock_workout_daily_missions.dart';
import 'package:organizer/core/storages/mock_yoga_daily_missions.dart';
import 'package:organizer/feature/add_habbits_screen/good/models/gh_radio_models.dart';
import 'package:organizer/feature/good_habbits_screen/data/models/gh_radio_model.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';

final addGhController = ChangeNotifierProvider(((ref) => AddGhController()));

class AddGhController extends ChangeNotifier {
  AddGhController() {}

  //ALL HABITS
  GhRadioModel? chosenGoodHabbit;
  List<GhRadioModel> myGoodHabbitsButtons = [
    GhRadioModel(false, goodHabbitsRu[0]),
    GhRadioModel(false, goodHabbitsRu[1]),
    GhRadioModel(false, goodHabbitsRu[2]),
    GhRadioModel(false, goodHabbitsRu[3]),
    GhRadioModel(false, goodHabbitsRu[4]),
    GhRadioModel(false, goodHabbitsRu[5]),
    GhRadioModel(false, goodHabbitsRu[6]),
  ];

  void chooseGoodHabit(GhRadioModel gh) {
    chosenGoodHabbit = gh;
    notifyListeners();
  }

  //JOGGING HABIT CONTROLS
  GoodHabbitTypeRadioModel? chosenJoggingType;
  List<GoodHabbitTypeRadioModel> myJoggingTypes = [
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.FAST.name,
      "Быстрый, но сложный",
      "Интенсивные пробежки с высокой скоростью. Эффективны для улучшения выносливости и сжигания калорий, но требуют хорошей физической подготовки и могут быть сложны для новичков.",
    ),
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.SLOW.name,
      "Медленный, но легкий",
      "Спокойный, размеренный бег трусцой. Подходит для начинающих и тех, кто хочет постепенно войти в форму, снижая нагрузку на суставы и уменьшая риск травм.",
    ),
  ];

  void chooseType(GoodHabbitTypeRadioModel type) {
    chosenJoggingType = type;
    notifyListeners();
  }

  Future<void> addMyGoodHabitToBD(
    BuildContext context,
    WidgetRef ref,
    String habbitName,
  ) async {
    HabbitModel habbit = HabbitModel(
      habbitName: habbitName,
      habbitType: "MINE",
      habbitDescription: "",
      isGoodHabbit: true,
      aiSuggestion: "",
      points: 50,
      imagePath: "",
      animationPath: "",
      facts: [],
      dailyMissions: [],
    );

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    for (int i = 0; i < 24; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == 24 - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: "Отлично! Продолжайте в том же духе",
          notificationText: "",
          isCompleted: false,
          points: 50,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    await ref.read(moneyCountController).getMyMoneySavings(ref);

    Navigator.of(context).pop();
  }

  Future<void> addJoggingHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenGoodHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenJoggingType!.type == GoodHabbitType.FAST.name) {
      originalMissions = joggingDailyMissionsFastRu; // быстрая стратегия
    } else {
      originalMissions = joggingDailyMissionsSlowRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
          textInfo: originalMissions[i].textInfo,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  //JOGA HABIT CONTROLS
  GoodHabbitTypeRadioModel? chosenYogaType;
  List<GoodHabbitTypeRadioModel> myYogaTypes = [
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.FAST.name,
      "Динамичная йога",
      "Интенсивная практика, сочетающая дыхание и быстрые смены поз. Улучшает силу, гибкость и выносливость. Подходит тем, кто хочет активной тренировки.",
    ),
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.SLOW.name,
      "Спокойная йога",
      "Неспешная практика, сосредоточенная на дыхании, растяжке и расслаблении. Отлично подходит для начинающих и снятия стресса.",
    ),
  ];

  void chooseYogaType(GoodHabbitTypeRadioModel type) {
    chosenYogaType = type;
    notifyListeners();
  }

  Future<void> addYogaHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenGoodHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenYogaType!.type == GoodHabbitType.FAST.name) {
      originalMissions = yogaDailyMissionsFastRu; // быстрая стратегия
    } else {
      originalMissions = yogaDailyMissionsFastRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
          videoUrl: originalMissions[i].videoUrl,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  //EATING HABIT CONTROLS
  GoodHabbitTypeRadioModel? chosenEatingType;
  List<GoodHabbitTypeRadioModel> myEatingTypes = [
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.FAST.name,
      "Сбросить вес",
      "Рацион с дефицитом калорий и сбалансированным содержанием белков, жиров и углеводов. Включает полезные перекусы и регулярные приёмы пищи для снижения веса без вреда для здоровья.",
    ),
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.SLOW.name,
      "Правильное питание",
      "Сбалансированное питание без строгих ограничений. Подходит для улучшения самочувствия, укрепления здоровья и поддержания нормального веса в долгосрочной перспективе.",
    ),
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.FAST.name,
      "Набрать вес",
      "Питание с умеренным профицитом калорий, повышенным содержанием белка и полезных жиров. Подходит для набора массы при сохранении баланса макро- и микронутриентов.",
    ),
  ];

  void chooseEatingType(GoodHabbitTypeRadioModel type) {
    chosenEatingType = type;
    notifyListeners();
  }

  Future<void> addEatingHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenGoodHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenEatingType!.type == GoodHabbitType.FAST.name) {
      originalMissions = nutritionDailyMissionsFastRu; // быстрая стратегия
    } else {
      originalMissions = nutritionDailyMissionsFastRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
          textInfo: originalMissions[i].textInfo,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  //GYM HABIT CONTROLS
  GoodHabbitTypeRadioModel? chosenGymType;
  List<GoodHabbitTypeRadioModel> myGymTypes = [
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.FAST.name,
      "Мужской",
      "Интенсивные тренировки с фокусом на сжигание жира, прирост силы и выносливости. Подходит для тех, кто хочет увидеть ощутимые изменения за короткий срок при высокой дисциплине.",
    ),
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.SLOW.name,
      "Женский",
      "Плавный вход в тренировки с акцентом на привычку, здоровье и постепенное улучшение физической формы. Подходит для устойчивого и комфортного образа жизни.",
    ),
  ];

  void chooseGymType(GoodHabbitTypeRadioModel type) {
    chosenGymType = type;
    notifyListeners();
  }

  Future<void> addGymHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenGoodHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenGymType!.type == GoodHabbitType.FAST.name) {
      originalMissions = gymDailyMissionsMaleRu; // быстрая стратегия
    } else {
      originalMissions = gymDailyMissionsFemaleRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
          videoUrl: originalMissions[i].videoUrl,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  //MEDITATION HABIT CONTROLS
  GoodHabbitTypeRadioModel? chosenMeditationType = GoodHabbitTypeRadioModel(
    true,
    GoodHabbitType.FAST.name,
    "Медитация",
    "Интенсивная практика, сочетающая дыхание и расслабление. Улучшает силу, спокойствие и стрессоустойчивость. Подходит тем, кто хочет забыть о стрессе",
  );
  List<GoodHabbitTypeRadioModel> myMeditationTypes = [
    GoodHabbitTypeRadioModel(
      true,
      GoodHabbitType.FAST.name,
      "Медитация",
      "Интенсивная практика, сочетающая дыхание и расслабление. Улучшает силу, спокойствие и стрессоустойчивость. Подходит тем, кто хочет забыть о стрессе",
    ),
  ];

  Future<void> addMeditationHabitToBD(
    BuildContext context,
    WidgetRef ref,
  ) async {
    HabbitModel habbit = chosenGoodHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenMeditationType!.type == GoodHabbitType.FAST.name) {
      originalMissions = meditationDailyMissionsSlowRu; // быстрая стратегия
    } else {
      originalMissions = meditationDailyMissionsSlowRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
          videoUrl: originalMissions[i].videoUrl,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  // WORKOUT HABIT CONTROLS
  GoodHabbitTypeRadioModel? chosenWorkoutType = GoodHabbitTypeRadioModel(
    true,
    GoodHabbitType.SLOW.name,
    "Лёгкие тренировки",
    "Простые упражнения без сильной нагрузки: прогулки, лёгкая гимнастика или домашняя зарядка. Подходит новичкам и для поддержания тонуса.",
  );

  List<GoodHabbitTypeRadioModel> myWorkoutTypes = [
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.FAST.name,
      "Кардио",
      "Бег, велосипед, HIIT или аэробика. Укрепляют сердце, повышают выносливость и сжигают калории.",
    ),
    GoodHabbitTypeRadioModel(
      true,
      GoodHabbitType.SLOW.name,
      "Лёгкие тренировки",
      "Простые упражнения без сильной нагрузки: прогулки, лёгкая гимнастика или домашняя зарядка. Подходит новичкам и для поддержания тонуса.",
    ),
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.FAST.name,
      "Силовые упражнения",
      "Занятия с гантелями, штангой или собственным весом. Развивают силу, ускоряют метаболизм и формируют мышцы.",
    ),
    GoodHabbitTypeRadioModel(
      false,
      GoodHabbitType.SLOW.name,
      "Растяжка и мобилити",
      "Мягкие упражнения на гибкость и подвижность суставов. Снижают риск травм и помогают восстанавливаться после нагрузок.",
    ),
  ];

  void chooseWorkoutType(GoodHabbitTypeRadioModel type) {
    chosenWorkoutType = type;
    notifyListeners();
  }

  Future<void> addWorkoutHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenGoodHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenWorkoutType!.type == GoodHabbitType.FAST.name) {
      originalMissions = workoutDailyMissionsFastRu; // быстрая стратегия
    } else {
      originalMissions = workoutDailyMissionsSlowRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
          videoUrl: originalMissions[i].videoUrl,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  // HARDENING HABIT CONTROLS
  GoodHabbitTypeRadioModel? chosenHardeningType = GoodHabbitTypeRadioModel(
    true,
    GoodHabbitType.SLOW.name,
    "Лёгкая закалка",
    "Начни с простого: контрастный душ или умывание холодной водой. Подходит новичкам и помогает мягко адаптировать организм.",
  );

  List<GoodHabbitTypeRadioModel> myHardeningTypes = [
    GoodHabbitTypeRadioModel(
      true,
      GoodHabbitType.SLOW.name,
      "Лёгкая закалка",
      "Контрастный душ, обливание прохладной водой или прогулка босиком. Мягкое укрепление иммунитета.",
    ),
    GoodHabbitTypeRadioModel(
      true,
      GoodHabbitType.FAST.name,
      "Активная закалка",
      "Холодный душ 1–3 минуты или купание в холодной воде. Интенсивная тренировка выносливости и силы духа.",
    ),
  ];

  void chooseHardeningType(GoodHabbitTypeRadioModel type) {
    chosenHardeningType = type;
    notifyListeners();
  }

  Future<void> addHardeningHabitToBD(
    BuildContext context,
    WidgetRef ref,
  ) async {
    HabbitModel habbit = chosenGoodHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenHardeningType!.type == GoodHabbitType.FAST.name) {
      originalMissions = hardeningDailyMissionsFastRu; // быстрая стратегия
    } else {
      originalMissions = hardeningDailyMissionsSlowRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
          videoUrl: originalMissions[i].videoUrl,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(ghController).getMyActiveGoodHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }
}
