import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/services/money_counter/money_count_controller.dart';
import 'package:organizer/core/storages/habbit_database.dart';
import 'package:organizer/core/storages/mock_alcohol_daily_missions.dart';
import 'package:organizer/core/storages/mock_drugs_daily_missions.dart';
import 'package:organizer/core/storages/mock_gambling_daily_missions.dart';
import 'package:organizer/core/storages/mock_habbit_storage.dart';
import 'package:organizer/core/storages/mock_procrastionation_daily_missions.dart';
import 'package:organizer/core/storages/mock_smoking_daily_missions.dart';
import 'package:organizer/core/storages/mock_socials_daily_missions.dart';
import 'package:organizer/feature/add_habbits_screen/bad/models/bh_radio_models.dart';
import 'package:organizer/feature/bad_habbits_screen/data/models/bh_radio_model.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';

final addBhController = ChangeNotifierProvider(((ref) => AddBhController()));

class AddBhController extends ChangeNotifier {
  AddBhController() {}

  //ALL HABITS
  BhRadioModel? chosenBadHabbit;
  List<BhRadioModel> myBadHabbitsButtons = [
    BhRadioModel(false, badHabbitsRu[0]),
    BhRadioModel(false, badHabbitsRu[1]),
    BhRadioModel(false, badHabbitsRu[2]),
    BhRadioModel(false, badHabbitsRu[3]),
    BhRadioModel(false, badHabbitsRu[4]),
    BhRadioModel(false, badHabbitsRu[5]),
  ];

  void chooseBadHabit(BhRadioModel bh) {
    chosenBadHabbit = bh;
    notifyListeners();
  }

  //SMOKING HABIT CONTROLS
  int? oneItemSmokingPrice;
  BadHabbitTypeRadioModel? chosenSmokingType;
  List<BadHabbitTypeRadioModel> mySmokingTypes = [
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.FAST.name,
      "Быстрый, но сложный",
      "это метод, при котором ты решаешь раз и навсегда, что больше не куришь, и сразу отказываешься от сигарет на 100%. Это называют резким или мгновенным отказом, и у него есть научно подтверждённые преимущества перед постепенным снижением дозы.",
    ),
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.SLOW.name,
      "Медленный, но легкий",
      "это постепенное уменьшение количества сигарет, чтобы снизить зависимость и избежать резких симптомов отмены. Такой подход подходит тем, кто не готов бросить резко, боится срывов или хочет подготовить психику и тело к жизни без сигарет.",
    ),
  ];

  //ALCOHOL HABIT CONTROLS
  int? oneItemAlcoholPrice;
  BadHabbitTypeRadioModel? chosenAlcoholType;
  List<BadHabbitTypeRadioModel> myAlcoholTypes = [
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.FAST.name,
      "Быстрый, но сложный",
      "это метод, при котором ты решаешь раз и навсегда, что больше не пьешь алкоголь, и сразу отказываешься от выпивки на 100%. Это называют резким или мгновенным отказом, и у него есть научно подтверждённые преимущества перед постепенным снижением дозы.",
    ),
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.SLOW.name,
      "Медленный, но легкий",
      "это постепенное уменьшение количества алкоголя, чтобы снизить зависимость и избежать резких симптомов отмены. Такой подход подходит тем, кто не готов бросить резко, боится срывов или хочет подготовить психику и тело к жизни без алкоголя.",
    ),
  ];

  //ALCOHOL HABIT CONTROLS
  BadHabbitTypeRadioModel? chosenGamblingType = BadHabbitTypeRadioModel(
    true,
    BadHabbitType.FAST.name,
    "Быстрый, но сложный",
    "это метод, при котором ты решаешь раз и навсегда, что больше не играешь и не делаешь ставки, и сразу отказываешься от этого на 100%. Это называют резким или мгновенным отказом, и у него есть научно подтверждённые преимущества перед постепенным снижением дозы.",
  );
  List<BadHabbitTypeRadioModel> myGamblingTypes = [
    BadHabbitTypeRadioModel(
      true,
      BadHabbitType.FAST.name,
      "Быстрый, но сложный",
      "это метод, при котором ты решаешь раз и навсегда, что больше не играешь и не делаешь ставки, и сразу отказываешься от этого на 100%. Это называют резким или мгновенным отказом, и у него есть научно подтверждённые преимущества перед постепенным снижением дозы.",
    ),
  ];

  //SOCIALS HABIT CONTROLS
  BadHabbitTypeRadioModel? chosenSocialsType;
  List<BadHabbitTypeRadioModel> mySocialsTypes = [
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.FAST.name,
      "Быстрый, но сложный",
      "это метод, при котором ты полностью отказываешься от социальных сетей сразу, удаляешь приложения и блокируешь сайты. Это резкий отказ, который помогает быстро восстановить концентрацию, внимание и избавиться от зависимости.",
    ),
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.SLOW.name,
      "Медленный, но легкий",
      "это постепенное сокращение времени, проводимого в соцсетях. Такой подход подойдёт тем, кто хочет контролировать использование и постепенно вырабатывать новые привычки, снижая зависимость мягко.",
    ),
  ];

  //DRUGS HABIT CONTROLS
  BadHabbitTypeRadioModel? chosenDrugsType;
  List<BadHabbitTypeRadioModel> myDrugsTypes = [
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.FAST.name,
      "Быстрый, но сложный",
      "это метод полного отказа от наркотиков сразу и навсегда. Такой подход требует решимости, но наиболее эффективен для прекращения пагубной зависимости и начала восстановления.",
    ),
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.SLOW.name,
      "Медленный, но легкий",
      "это метод постепенного сокращения употребления с последующим полным отказом. Подходит для тех, кто не может бросить резко, но готов работать над избавлением шаг за шагом, желательно под наблюдением специалистов.",
    ),
  ];

  //PROCRASTINATION HABIT CONTROLS
  BadHabbitTypeRadioModel? chosenProcrastinationType;
  List<BadHabbitTypeRadioModel> myProcrastinationTypes = [
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.FAST.name,
      "Быстрый, но сложный",
      "это метод, при котором ты решаешь с сегодняшнего дня выполнять задачи сразу и больше не откладывать. Такой подход помогает быстро влиться в продуктивный ритм, но требует дисциплины и силы воли.",
    ),
    BadHabbitTypeRadioModel(
      false,
      BadHabbitType.SLOW.name,
      "Медленный, но легкий",
      "это метод, при котором ты постепенно внедряешь полезные привычки: планирование дня, правило двух минут, техника «помидора» и маленькие шаги к дисциплине. Он подходит тем, кто хочет стабильно улучшать свою продуктивность без резких изменений.",
    ),
  ];

  void chooseType(HabitTypes habitType, BadHabbitTypeRadioModel type) {
    switch (habitType) {
      case HabitTypes.SMOKING:
        chosenSmokingType = type;
        break;
      case HabitTypes.ALCOHOL:
        chosenAlcoholType = type;
        break;
      case HabitTypes.GAMBLING:
        chosenGamblingType = type;
        break;
      case HabitTypes.SOCIALS:
        chosenSocialsType = type;
        break;
      case HabitTypes.DRUGS:
        chosenDrugsType = type;
        break;
      case HabitTypes.TIMELOSS:
        chosenProcrastinationType = type;
        break;
    }
    notifyListeners();
  }

  SmokingPacksRadioModel? chosenSmokingPacks;
  List<SmokingPacksRadioModel> mySmokingPacks = [
    SmokingPacksRadioModel(false, "<1", 1),
    SmokingPacksRadioModel(false, "2-3", 2),
    SmokingPacksRadioModel(false, ">3", 3),
  ];

  void chooseSmokingPacks(SmokingPacksRadioModel smokingPacks) {
    chosenSmokingPacks = smokingPacks;
    notifyListeners();
  }

  void chooseSmokingPrice(String value) {
    var price;
    try {
      price = int.parse(value);
    } catch (e) {}
    oneItemSmokingPrice = price;
    notifyListeners();
  }

  AlcoholCountRadioModel? chosenAlcoholCount;
  List<AlcoholCountRadioModel> myAlcoholCounts = [
    AlcoholCountRadioModel(false, "Каждый день", 7),
    AlcoholCountRadioModel(false, "3-4 раза в неделю", 4),
    AlcoholCountRadioModel(false, "1-2 раза в неделю", 2),
  ];

  void chooseAlcoholCount(AlcoholCountRadioModel alcoholCount) {
    chosenAlcoholCount = alcoholCount;
    notifyListeners();
  }

  void chooseAlcoholPrice(String value) {
    var price;
    try {
      price = int.parse(value);
    } catch (e) {}
    oneItemAlcoholPrice = price;
    notifyListeners();
  }

  GamblingSessionRadioModel? chosenGamblingSessions;
  List<GamblingSessionRadioModel> myGamblingSessions = [
    GamblingSessionRadioModel(false, "Каждый день"),
    GamblingSessionRadioModel(false, "3-4 раза в неделю"),
    GamblingSessionRadioModel(false, "1-2 раза в неделю"),
  ];

  void chooseGamblingSessions(GamblingSessionRadioModel gamblingSession) {
    chosenGamblingSessions = gamblingSession;
    notifyListeners();
  }

  SocialsTimeRadioModel? chosenSocialsTime;
  List<SocialsTimeRadioModel> mySocialsTimes = [
    SocialsTimeRadioModel(false, "<1", 1),
    SocialsTimeRadioModel(false, "2-3", 3),
    SocialsTimeRadioModel(false, "4+", 5),
  ];

  void chooseSocialsTime(SocialsTimeRadioModel socialsTime) {
    chosenSocialsTime = socialsTime;
    notifyListeners();
  }

  DrugsUsageRadioModel? chosenDrugsUsage;
  List<DrugsUsageRadioModel> myDrugsUsages = [
    DrugsUsageRadioModel(false, "Редко"),
    DrugsUsageRadioModel(false, "Иногда"),
    DrugsUsageRadioModel(false, "Часто"),
  ];

  void chooseDrugsUsage(DrugsUsageRadioModel drugsUsage) {
    chosenDrugsUsage = drugsUsage;
    notifyListeners();
  }

  ProcrastinationLevelRadioModel? chosenProcrastinationLevel;
  List<ProcrastinationLevelRadioModel> myProcrastinationLevels = [
    ProcrastinationLevelRadioModel(false, "Редко"),
    ProcrastinationLevelRadioModel(false, "Часто"),
    ProcrastinationLevelRadioModel(false, "Всегда"),
  ];

  void chooseProcrastinationLevel(ProcrastinationLevelRadioModel level) {
    chosenProcrastinationLevel = level;
    notifyListeners();
  }

  Future<void> addMyBadHabitToBD(
    BuildContext context,
    WidgetRef ref,
    String habbitName,
  ) async {
    HabbitModel habbit = HabbitModel(
      habbitName: habbitName,
      habbitType: "MINE",
      habbitDescription: "",
      isGoodHabbit: false,
      aiSuggestion: "",
      points: 50,
      imagePath: "",
      animationPath: "",
      facts: [],
      dailyMissions: [],
    );

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    for (int i = 0; i < 24; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == 24 - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: "Отлично! Продолжайте в том же духе",
          notificationText: "",
          isCompleted: false,
          points: 50,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(bhController).getMyActiveBadHabbits();
    });

    await ref.read(moneyCountController).getMyMoneySavings(ref);

    Navigator.of(context).pop();
  }

  Future<void> addSmokingHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenBadHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenSmokingType!.type == BadHabbitType.FAST.name) {
      originalMissions = smokingDailyMissionsFastRu; // быстрая стратегия
    } else {
      originalMissions = smokingDailyMissionsSlowRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
      oneValuePrice: oneItemSmokingPrice,
      habbitUseCount: chosenSmokingPacks?.value,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(bhController).getMyActiveBadHabbits();
    });

    await ref.read(moneyCountController).getMyMoneySavings(ref);

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  Future<void> addAlcoholHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenBadHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions;

    if (chosenAlcoholType!.type == BadHabbitType.FAST.name) {
      originalMissions = alcoholDailyMissionsFastRu; // быстрая стратегия
    } else {
      originalMissions = alcoholDailyMissionsSlowRu; // медленная стратегия
    }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
      oneValuePrice: oneItemAlcoholPrice,
      habbitUseCount: chosenAlcoholCount?.value,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(bhController).getMyActiveBadHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  Future<void> addGamblingHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenBadHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions = gamblingDailyMissionsFastRu;

    // if (chosenGamblingType!.type == BadHabbitType.FAST.name) {
    //   originalMissions = gamblingDailyMissionsFastRu; // быстрая стратегия
    // } else {
    //   originalMissions = alcoholDailyMissionsSlowRu; // медленная стратегия
    // }

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate;

      if (i == originalMissions.length - 1) {
        endDate = startDate.add(const Duration(days: 365));
      } else {
        endDate = startDate.add(const Duration(hours: 23, minutes: 59));
      }

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(bhController).getMyActiveBadHabbits();
    });

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  Future<void> addProcrastinationHabitToBD(
    BuildContext context,
    WidgetRef ref,
  ) async {
    HabbitModel habbit = chosenBadHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions =
        chosenProcrastinationType!.type == BadHabbitType.FAST.name
            ? procrastinationDailyMissionsFastRu
            : procrastinationDailyMissionsSlowRu;

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate =
          i == originalMissions.length - 1
              ? startDate.add(const Duration(days: 365))
              : startDate.add(const Duration(hours: 23, minutes: 59));

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(bhController).getMyActiveBadHabbits();
    });

    await ref.read(moneyCountController).getMyMoneySavings(ref);

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  Future<void> addDrugsHabitToBD(BuildContext context, WidgetRef ref) async {
    HabbitModel habbit = chosenBadHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions =
        chosenDrugsType!.type == BadHabbitType.FAST.name
            ? drugsDailyMissionsFastRu
            : drugsDailyMissionsSlowRu;

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate =
          i == originalMissions.length - 1
              ? startDate.add(const Duration(days: 365))
              : startDate.add(const Duration(hours: 23, minutes: 59));

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(bhController).getMyActiveBadHabbits();
    });

    await ref.read(moneyCountController).getMyMoneySavings(ref);

    Navigator.of(context)
      ..pop()
      ..pop();
  }

  Future<void> addSocialMediaHabitToBD(
    BuildContext context,
    WidgetRef ref,
  ) async {
    HabbitModel habbit = chosenBadHabbit!.habbit;

    List<DailyMission> missionsToAdd = [];
    DateTime now = DateTime.now();

    List<DailyMission> originalMissions =
        chosenSocialsType!.type == BadHabbitType.FAST.name
            ? socialMediaDailyMissionsFastRu
            : socialMediaDailyMissionsSlowRu;

    for (int i = 0; i < originalMissions.length; i++) {
      DateTime startDate = now.add(Duration(days: i));
      DateTime endDate =
          i == originalMissions.length - 1
              ? startDate.add(const Duration(days: 365))
              : startDate.add(const Duration(hours: 23, minutes: 59));

      missionsToAdd.add(
        DailyMission(
          startDate: startDate,
          endDate: endDate,
          missionText: originalMissions[i].missionText,
          notificationText: originalMissions[i].notificationText,
          isCompleted: false,
          points: originalMissions[i].points,
        ),
      );
    }

    HabbitModel newHabbit = habbit.copyWith(
      dailyMissions: missionsToAdd,
      startDate: missionsToAdd.first.startDate,
      endDate: missionsToAdd.last.endDate,
      habbitUseCount: chosenSocialsTime?.value,
    );

    final habbitDatabaseService = HabbitDatabaseService();
    await habbitDatabaseService.saveHabbit(newHabbit).whenComplete(() async {
      await ref.read(bhController).getMyActiveBadHabbits();
    });

    await ref.read(moneyCountController).getMyMoneySavings(ref);

    Navigator.of(context)
      ..pop()
      ..pop();
  }
}
