import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/animated_gradient_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/add_habbits_screen/bad/choose_bh_section.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';

class AddBhScreenFirst extends ConsumerWidget {
  const AddBhScreenFirst({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var bhModel = ref.watch(addBhController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar:
          bhModel.chosenBadHabbit == null
              ? Padding(
                padding: const EdgeInsets.only(
                  left: 14.0,
                  right: 14,
                  bottom: 20,
                ),
                child: AnimatedButton(
                  onTap: () {},
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.greyColor,
                    ),
                    child: Center(
                      child: Text(
                        "Далее",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              )
              : Padding(
                padding: const EdgeInsets.only(
                  left: 14.0,
                  right: 14,
                  bottom: 20,
                ),
                child: AnimatedButton(
                  onTap: () {
                    Navigation.goToAddBhScreenSecond(
                      context,
                      bhModel.chosenBadHabbit!.habbit,
                    );
                  },
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.darkGreenColor,
                    ),
                    child: Center(
                      child: Text(
                        "Далее",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(text: "Выберите плохую привычку"),
              SizedBox(height: 10),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height * 0.23,
                      width: MediaQuery.of(context).size.width * 0.98,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: AppConstants.secondaryColor,
                        border: Border.all(
                          width: 2,
                          color: AppConstants.secondaryColor,
                        ),
                      ),
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              Positioned(
                                bottom: -100,
                                child: SizedBox(
                                  width: 400,
                                  height: 400,
                                  child: LottieBuilder.asset(
                                    AppConstants.fireworksAnim,
                                    animate: true,
                                  ),
                                ),
                              ),

                              Positioned(
                                child: SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height * 0.23,
                                  width:
                                      MediaQuery.of(context).size.width * 0.96,
                                  child: Column(
                                    children: [
                                      Text(
                                        "Поздравляем!",
                                        style: GoogleFonts.unbounded(
                                          color: AppConstants.whiteColor,
                                          fontSize: 24,
                                        ),
                                      ),
                                      SizedBox(height: 14),
                                      Transform.rotate(
                                        angle: -0.5 * (3.14 / 180),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                              20,
                                            ),
                                            color: AppConstants.darkGreenColor,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(4.0),
                                            child: Text(
                                              textAlign: TextAlign.center,
                                              maxLines: 4,
                                              "Вы сделали первый шаг на пути избавления от вредной привычки!",
                                              style: GoogleFonts.unbounded(
                                                color: AppConstants.bgColor,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 14),
                                      Text(
                                        textAlign: TextAlign.center,
                                        maxLines: 4,
                                        "Теперь определите, что хотите убрать или минимизировать в своей жизни",
                                        style: GoogleFonts.unbounded(
                                          color: AppConstants.whiteColor,
                                          fontSize: 13,
                                        ),
                                      ),
                                      Icon(
                                        Icons.keyboard_arrow_down_rounded,
                                        color: AppConstants.whiteColor,
                                        size: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    AnimatedButton(
                      onTap: () async {
                        Navigation.goToAddMyHabbit(context, false);
                      },
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: AppConstants.bgGreyColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Добавить свою привычку",
                                    style: GoogleFonts.unbounded(
                                      color: AppConstants.whiteColor,
                                      fontSize: 14,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width * 0.8,
                                    child: Text(
                                      "При добавлении собственной привычки у вас не будет ежедневных заданий",
                                      style: GoogleFonts.unbounded(
                                        color: AppConstants.greyColor,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Icon(Icons.arrow_forward_ios),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    CustomBhRadioButton(),
                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
