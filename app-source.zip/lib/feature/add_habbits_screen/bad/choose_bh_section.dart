import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/storages/mock_habbit_storage.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';
import 'package:organizer/feature/bad_habbits_screen/data/models/bh_radio_model.dart';

class CustomBhRadioButton extends ConsumerStatefulWidget {
  const CustomBhRadioButton({super.key});

  @override
  _CustomBhRadioButtonState createState() => _CustomBhRadioButtonState();
}

class _CustomBhRadioButtonState extends ConsumerState<CustomBhRadioButton> {
  @override
  Widget build(BuildContext context) {
    var bhAddModel = ref.watch(addBhController);
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.98,

      child: Align(
        alignment: Alignment.topCenter,
        child: GridView.builder(
          physics: NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, // Два элемента в строке
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.4, // Соотношение сторон элемента (шире или уже)
          ),
          itemCount: badHabbitsRu.length,
          itemBuilder: (context, index) {
            return AnimatedButton(
              onTap: () {
                setState(() {
                  for (var element in bhAddModel.myBadHabbitsButtons) {
                    element.isSelected = false;
                  }
                  bhAddModel.myBadHabbitsButtons[index].isSelected = true;
                  ref
                      .read(addBhController)
                      .chooseBadHabit(bhAddModel.myBadHabbitsButtons[index]);
                });
              },
              child: RadioItem(bhAddModel.myBadHabbitsButtons[index]),
            );
          },
        ),
      ),
    );
  }
}

class RadioItem extends StatelessWidget {
  final BhRadioModel _item;
  RadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.26,
      width: MediaQuery.of(context).size.height * 0.22,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.26,
            width: MediaQuery.of(context).size.height * 0.22,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color:
                  _item.isSelected
                      ? AppConstants.darkGreenColor
                      : AppConstants.secondaryColor,
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    // SizedBox(
                    //   height: 50,
                    //   width: 50,
                    //   child: Image.asset(_item.habbit.imagePath),
                    // ),
                    Positioned(
                      top: 30,
                      child: Icon(
                        AppConstants.getHabitIcon(
                          _item.habbit.habbitType,
                          isGood: false,
                        ),
                        size: 46,
                        color:
                            _item.isSelected
                                ? AppConstants.bgColor
                                : AppConstants.darkGreenColor,
                      ),
                    ),

                    Positioned(
                      bottom: 2,
                      child: Text(
                        _item.habbit.habbitName,
                        style: GoogleFonts.unbounded(
                          color:
                              _item.isSelected
                                  ? AppConstants.bgColor
                                  : AppConstants.whiteColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
