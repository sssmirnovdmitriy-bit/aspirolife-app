import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';

class AddBhSmokingCount extends ConsumerStatefulWidget {
  const AddBhSmokingCount({super.key});

  @override
  _AddBhSmokingCountState createState() => _AddBhSmokingCountState();
}

class _AddBhSmokingCountState extends ConsumerState<AddBhSmokingCount> {
  TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var bhModel = ref.watch(addBhController);
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.94,
              child: Text(
                "Рассчитайте какую сумму в день Вы тратите на курение*",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 20),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.3,
          child: TextInputField(
            radius: 20,
            height: 50,
            controller: _controller,
            keyboard: TextInputType.number,
            hintText: "В условных единицах",
            onChanged: (value) {
              ref
                  .read(addBhController)
                  .chooseSmokingPrice(_controller.text.trim());
            },
          ),
        ),
      ],
    );
  }
}
