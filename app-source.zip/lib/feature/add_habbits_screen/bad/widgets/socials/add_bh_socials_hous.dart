import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/add_habbits_screen/bad/models/bh_radio_models.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';

class AddBhSocialsHours extends ConsumerStatefulWidget {
  const AddBhSocialsHours({super.key});

  @override
  _AddBhSocialsHoursState createState() => _AddBhSocialsHoursState();
}

class _AddBhSocialsHoursState extends ConsumerState<AddBhSocialsHours> {
  @override
  Widget build(BuildContext context) {
    var bhModel = ref.watch(addBhController);
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.95,
              child: Text(
                "Сколько часов в день вы тратите на соцсети?*",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 4),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.11,
          child: ListView.builder(
            physics: NeverScrollableScrollPhysics(),
            itemCount: bhModel.mySocialsTimes.length,
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.zero,

            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: AnimatedButton(
                  onTap: () {
                    setState(() {
                      for (var element in bhModel.mySocialsTimes) {
                        element.isSelected = false;
                      }
                      bhModel.mySocialsTimes[index].isSelected = true;
                      ref
                          .read(addBhController)
                          .chooseSocialsTime(bhModel.mySocialsTimes[index]);
                    });
                  },
                  child: TypeRadioItem(bhModel.mySocialsTimes[index]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class TypeRadioItem extends StatelessWidget {
  final SocialsTimeRadioModel _item;
  TypeRadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.08,
      width: MediaQuery.of(context).size.height * 0.08,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.08,
            width: MediaQuery.of(context).size.height * 0.08,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color:
                  _item.isSelected
                      ? AppConstants.darkGreenColor
                      : AppConstants.secondaryColor,
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  _item.type,
                  style: GoogleFonts.unbounded(
                    color:
                        _item.isSelected
                            ? AppConstants.bgColor
                            : AppConstants.whiteColor,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
