import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';

class AddBhProcrastinationNavbar extends ConsumerWidget {
  const AddBhProcrastinationNavbar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var bhModel = ref.watch(addBhController);
    return bhModel.chosenProcrastinationLevel == null ||
            bhModel.chosenProcrastinationType == null
        ? Padding(
          padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 20),
          child: AnimatedButton(
            onTap: () {},
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: AppConstants.greyColor,
              ),
              child: Center(
                child: Text(
                  "Создать",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.whiteColor,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ),
        )
        : Padding(
          padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 20),
          child: AnimatedButton(
            onTap: () async {
              await ref
                  .read(addBhController)
                  .addProcrastinationHabitToBD(context, ref);
            },
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: AppConstants.darkGreenColor,
              ),
              child: Center(
                child: Text(
                  "Создать",
                  style: GoogleFonts.unbounded(
                    color: AppConstants.bgColor,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ),
        );
  }
}
