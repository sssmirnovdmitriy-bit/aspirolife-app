import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/habbit_model.dart';

class AddBhPrizesSection extends StatelessWidget {
  final HabbitModel habbitModel;
  const AddBhPrizesSection({required this.habbitModel, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Text(
              "Ваша награда за отказ от привычки",
              style: GoogleFonts.unbounded(
                color: AppConstants.whiteColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        SizedBox(height: 10),
        SizedBox(
          height: 72,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              Container(
                height: 60,
                decoration: BoxDecoration(
                  color: AppConstants.secondaryColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      SizedBox(
                        child: Image.asset(
                          AppConstants.pointsImage,
                          height: 32,
                          width: 100,
                        ),
                      ),

                      Positioned(
                        bottom: 1,
                        child: Text(
                          "+${habbitModel.points} очков",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 8),
              Container(
                height: 60,
                decoration: BoxDecoration(
                  color: AppConstants.secondaryColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 28,
                        width: 28,
                        child: LottieBuilder.asset(AppConstants.heartAnim),
                      ),
                      SizedBox(height: 4),
                      Text(
                        "здоровье",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
