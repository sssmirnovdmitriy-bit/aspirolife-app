import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/typewritter_widget.dart';
import 'package:organizer/feature/add_habbits_screen/bad/models/bh_radio_models.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';

class AddBhGamblingType extends ConsumerStatefulWidget {
  const AddBhGamblingType({super.key});

  @override
  _AddBhGamblingTypeState createState() => _AddBhGamblingTypeState();
}

class _AddBhGamblingTypeState extends ConsumerState<AddBhGamblingType> {
  @override
  Widget build(BuildContext context) {
    var bhModel = ref.watch(addBhController);
    return Column(
      children: [
        Row(
          children: [
            Text(
              "Режим отказа*",
              style: GoogleFonts.unbounded(
                color: AppConstants.whiteColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        SizedBox(height: 10),
        SizedBox(
          // height: MediaQuery.of(context).size.height * 0.24,
          child: ListView.builder(
            physics: NeverScrollableScrollPhysics(),
            itemCount: bhModel.myGamblingTypes.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: GestureDetector(
                  onTap: () {},
                  child: TypeRadioItem(bhModel.myGamblingTypes[index]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class TypeRadioItem extends StatelessWidget {
  final BadHabbitTypeRadioModel _item;
  TypeRadioItem(this._item);
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.1,
          width: MediaQuery.of(context).size.height * 0.15,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.1,
                width: MediaQuery.of(context).size.height * 0.15,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color:
                      _item.isSelected
                          ? AppConstants.darkGreenColor
                          : AppConstants.secondaryColor,
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      _item.name,
                      style: GoogleFonts.unbounded(
                        color:
                            _item.isSelected
                                ? AppConstants.bgColor
                                : AppConstants.whiteColor,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 10),
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.6,
          child: Text(
            _item.description,
            style: GoogleFonts.unbounded(
              color: AppConstants.whiteColor,
              fontSize: 12,
            ),
          ),
        ),
      ],
    );
  }
}
