import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/typewritter_widget.dart';
import 'package:organizer/core/models/habbit_model.dart';

class AddBhDescriptionSection extends StatelessWidget {
  final HabbitModel habit;
  const AddBhDescriptionSection(this.habit, {super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            height: MediaQuery.of(context).size.height * 0.15,
            width: MediaQuery.of(context).size.width * 0.98,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: AppConstants.secondaryColor,
              border: Border.all(width: 2, color: AppConstants.secondaryColor),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: AppConstants.bgColor,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: SizedBox(
                            height: 20,
                            width: 20,
                            child: Image.asset(habit.imagePath),
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      Text(
                        habit.habbitName,
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.84,
                        child: TypewriterText(
                          text: habit.habbitDescription,
                          textStyle: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          right: -20,
          bottom: -6,
          child: SizedBox(
            width: 90,
            height: 90,
            child: LottieBuilder.asset(AppConstants.fireAnim, animate: true),
          ),
        ),
      ],
    );
  }
}
