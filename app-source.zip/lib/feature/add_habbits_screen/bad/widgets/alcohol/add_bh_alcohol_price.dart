import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';

class AddBhAlcoholPrice extends ConsumerStatefulWidget {
  const AddBhAlcoholPrice({super.key});

  @override
  _AddBhAlcoholPriceState createState() => _AddBhAlcoholPriceState();
}

class _AddBhAlcoholPriceState extends ConsumerState<AddBhAlcoholPrice> {
  TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.94,
              child: Text(
                "Рассчитайте какую сумму в день Вы тратите на алкоголь*",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 20),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.3,
          child: TextInputField(
            radius: 20,
            height: 50,
            keyboard: TextInputType.number,
            hintText: "В условных единицах",
            controller: _controller,
            onChanged: (value) {
              ref.read(addBhController).chooseAlcoholPrice(_controller.text);
            },
          ),
        ),
      ],
    );
  }
}
