import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/animated_gradient_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/storages/mock_habbit_storage.dart';
import 'package:organizer/feature/add_habbits_screen/bad/choose_bh_section.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/add_bh_description_section.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/add_bh_prizes_section.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/alcohol/add_bh_alcohol_count.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/alcohol/add_bh_alcohol_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/alcohol/add_bh_alcohol_price.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/alcohol/add_bh_alcohol_type.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/drugs/add_bh_drugs_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/drugs/add_bh_drugs_type.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/drugs/add_bh_drugs_usage.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/gambling/add_bh_gambling_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/gambling/add_bh_gambling_sessions.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/gambling/add_bh_gambling_type.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/procrastination/add_bh_procrastination_level.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/procrastination/add_bh_procrastination_type.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/procrastination/add_bh_procrastintion_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/smoking/add_bh_smoking_count.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/smoking/add_bh_smoking_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/smoking/add_bh_smoking_packs.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/smoking/add_bh_smoking_type.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/socials/add_bh_socials_hous.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/socials/add_bh_socials_navbar.dart';
import 'package:organizer/feature/add_habbits_screen/bad/widgets/socials/add_bh_socials_types.dart';
import 'package:organizer/feature/add_habbits_screen/controller/add_bh_controller.dart';

class AddBhScreenSecond extends ConsumerStatefulWidget {
  final HabbitModel habbitModel;
  const AddBhScreenSecond({required this.habbitModel, super.key});

  @override
  _AddBhScreenSecondState createState() => _AddBhScreenSecondState();
}

class _AddBhScreenSecondState extends ConsumerState<AddBhScreenSecond> {
  @override
  Widget build(BuildContext context) {
    var bhModel = ref.watch(addBhController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Builder(
        builder: (context) {
          if (widget.habbitModel.habbitType == HabitTypes.SMOKING.name) {
            return AddBhSmokingNavbar();
          } else if (widget.habbitModel.habbitType == HabitTypes.ALCOHOL.name) {
            return AddBhAlcoholNavbar();
          } else if (widget.habbitModel.habbitType ==
              HabitTypes.GAMBLING.name) {
            return AddBhGamblingNavbar();
          } else if (widget.habbitModel.habbitType ==
              HabitTypes.TIMELOSS.name) {
            return AddBhProcrastinationNavbar();
          } else if (widget.habbitModel.habbitType == HabitTypes.SOCIALS.name) {
            return AddBhSocialsNavbar();
          } else if (widget.habbitModel.habbitType == HabitTypes.DRUGS.name) {
            return AddBhDrugsNavbar();
          } else {
            return SizedBox();
          }
        },
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(
                text: "Новая привычка (${widget.habbitModel.habbitName})",
              ),
              Expanded(
                child: ListView(
                  children: [
                    AddBhDescriptionSection(widget.habbitModel),
                    SizedBox(height: 10),
                    AddBhPrizesSection(habbitModel: widget.habbitModel),
                    SizedBox(height: 30),
                    Builder(
                      builder: (context) {
                        if (widget.habbitModel.habbitType ==
                            HabitTypes.SMOKING.name) {
                          return Column(
                            children: [
                              AddBhSmokingType(),
                              SizedBox(height: 20),
                              AddBhSmokingPacks(),
                              SizedBox(height: 20),
                              AddBhSmokingCount(),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            HabitTypes.ALCOHOL.name) {
                          return Column(
                            children: [
                              AddBhAlcoholType(),
                              SizedBox(height: 20),
                              AddBhAlcoholCount(),
                              SizedBox(height: 20),
                              AddBhAlcoholPrice(),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            HabitTypes.GAMBLING.name) {
                          return Column(
                            children: [
                              AddBhGamblingType(),
                              SizedBox(height: 20),
                              AddBhGamblingSessions(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            HabitTypes.TIMELOSS.name) {
                          return Column(
                            children: [
                              AddBhProcrastionationType(),
                              SizedBox(height: 20),
                              AddBhProcrastionationLevel(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            HabitTypes.SOCIALS.name) {
                          return Column(
                            children: [
                              AddBhSocialsType(),
                              SizedBox(height: 20),
                              AddBhSocialsHours(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            HabitTypes.DRUGS.name) {
                          return Column(
                            children: [
                              AddBhDrugsType(),
                              SizedBox(height: 20),
                              AddBhDrugsUsage(),
                              SizedBox(height: 20),
                            ],
                          );
                        } else {
                          return SizedBox();
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
