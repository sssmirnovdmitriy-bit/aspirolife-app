enum BadHabbitType { FAST, SLOW }

class BadHabbitTypeRadioModel {
  bool isSelected;
  String name;
  String type;
  String description;

  BadHabbitTypeRadioModel(
    this.isSelected,
    this.type,
    this.name,
    this.description,
  );
}

class SmokingPacksRadioModel {
  bool isSelected;
  String type;
  int? value;

  SmokingPacksRadioModel(this.isSelected, this.type, this.value);
}

class AlcoholCountRadioModel {
  bool isSelected;
  String type;
  int? value;

  AlcoholCountRadioModel(this.isSelected, this.type, this.value);
}

class GamblingSessionRadioModel {
  bool isSelected;
  String type;

  GamblingSessionRadioModel(this.isSelected, this.type);
}

class SocialsTimeRadioModel {
  bool isSelected;
  String type;
  int? value; // Например, количество часов в день

  SocialsTimeRadioModel(this.isSelected, this.type, this.value);
}

class DrugsUsageRadioModel {
  bool isSelected;
  String type;

  DrugsUsageRadioModel(this.isSelected, this.type);
}

class ProcrastinationLevelRadioModel {
  bool isSelected;
  String type;

  ProcrastinationLevelRadioModel(this.isSelected, this.type);
}
