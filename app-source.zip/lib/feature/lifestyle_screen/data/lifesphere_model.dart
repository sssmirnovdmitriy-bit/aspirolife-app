// models/life_sphere_model.dart

class LifeSphere {
  final int id;
  final String title;
  final String emoji;
  final String description;
  final List<String> supportingQuestions;
  int rating;
  String? additionalComment;

  LifeSphere({
    required this.id,
    required this.title,
    required this.emoji,
    required this.description,
    required this.supportingQuestions,
    this.rating = 5,
    this.additionalComment,
  });

  // Получение цвета по рейтингу
  String get colorCode {
    switch (rating) {
      case 0:
      case 1:
        return '#FF0000'; // Красный
      case 2:
      case 3:
        return '#FF6600'; // Оранжево-красный
      case 4:
      case 5:
        return '#FFA500'; // Оранжевый
      case 6:
      case 7:
        return '#FFFF00'; // Жёлтый
      case 8:
      case 9:
        return '#90EE90'; // Светло-зелёный
      case 10:
        return '#A6FF00'; // Зелёный
      default:
        return '#FFFF00';
    }
  }

  // Описание уровня удовлетворенности
  String get satisfactionLevel {
    switch (rating) {
      case 0:
      case 1:
        return 'Крайне неудовлетворительно';
      case 2:
      case 3:
        return 'Низкий уровень';
      case 4:
      case 5:
        return 'Ниже среднего';
      case 6:
      case 7:
        return 'Средний уровень';
      case 8:
      case 9:
        return 'Высокий уровень';
      case 10:
        return 'Полная удовлетворённость';
      default:
        return 'Средний уровень';
    }
  }

  // Описание рейтинга
  String get ratingDescription {
    switch (rating) {
      case 0:
        return 'Ужасно. Всё разваливается.';
      case 1:
        return 'Очень плохо. Почти невыносимо.';
      case 2:
        return 'Плохо. Всё не так, как хочется.';
      case 3:
        return 'Слабо. Много напряжения и недовольства.';
      case 4:
        return 'Так себе. Часто тяжело, хочется по-другому.';
      case 5:
        return 'Нормально. Терпимо, но без радости.';
      case 6:
        return 'Скорее да. Иногда даже приятно.';
      case 7:
        return 'Хорошо. В целом устраивает.';
      case 8:
        return 'Очень хорошо. Поддерживает и радует.';
      case 9:
        return 'Почти идеально. Всё на своём месте.';
      case 10:
        return 'Прекрасно. Полная гармония.';
      default:
        return 'Нормально. Терпимо, но без радости.';
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'emoji': emoji,
      'description': description,
      'supportingQuestions': supportingQuestions,
      'rating': rating,
      'additionalComment': additionalComment,
    };
  }

  factory LifeSphere.fromJson(Map<String, dynamic> json) {
    return LifeSphere(
      id: json['id'],
      title: json['title'],
      emoji: json['emoji'],
      description: json['description'],
      supportingQuestions: List<String>.from(json['supportingQuestions']),
      rating: json['rating'] ?? 5,
      additionalComment: json['additionalComment'],
    );
  }

  LifeSphere copyWith({
    int? id,
    String? title,
    String? emoji,
    String? description,
    List<String>? supportingQuestions,
    int? rating,
    String? additionalComment,
  }) {
    return LifeSphere(
      id: id ?? this.id,
      title: title ?? this.title,
      emoji: emoji ?? this.emoji,
      description: description ?? this.description,
      supportingQuestions: supportingQuestions ?? this.supportingQuestions,
      rating: rating ?? this.rating,
      additionalComment: additionalComment ?? this.additionalComment,
    );
  }
}

// Модель результата опроса
class LifestyleSurveyResult {
  final List<LifeSphere> spheres;
  final List<int> selectedSpheresIds;
  final DateTime completedAt;

  LifestyleSurveyResult({
    required this.spheres,
    this.selectedSpheresIds = const [],
    required this.completedAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'spheres': spheres.map((s) => s.toJson()).toList(),
      'selectedSpheresIds': selectedSpheresIds,
      'completedAt': completedAt.toIso8601String(),
    };
  }

  factory LifestyleSurveyResult.fromJson(Map<String, dynamic> json) {
    return LifestyleSurveyResult(
      spheres:
          (json['spheres'] as List).map((s) => LifeSphere.fromJson(s)).toList(),
      selectedSpheresIds: List<int>.from(json['selectedSpheresIds'] ?? []),
      completedAt: DateTime.parse(json['completedAt']),
    );
  }
}
