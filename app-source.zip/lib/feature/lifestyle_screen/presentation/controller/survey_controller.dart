// controllers/survey_controller.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/core/services/survey_service/survey_service.dart';
import 'package:organizer/feature/lifestyle_screen/data/lifesphere_model.dart';

final surveyController = ChangeNotifierProvider(((ref) => SurveyController()));

class SurveyController extends ChangeNotifier {
  List<LifeSphere> _spheres = [];
  int _currentIndex = 0;
  List<int> _selectedSphereIds = [];
  bool _isLoading = false;
  String? _errorMessage;
  SurveyState _state = SurveyState.initial;
  LifestyleSurveyResult? currentSurvey;

  // Геттеры
  List<LifeSphere> get spheres => _spheres;
  int get currentIndex => _currentIndex;
  List<int> get selectedSphereIds => _selectedSphereIds;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  SurveyState get state => _state;

  LifeSphere? get currentSphere =>
      _spheres.isNotEmpty && _currentIndex < _spheres.length
          ? _spheres[_currentIndex]
          : null;

  bool get canGoNext => _currentIndex < _spheres.length - 1;
  bool get canGoPrevious => _currentIndex > 0;
  bool get isLastSphere => _currentIndex == _spheres.length - 1;
  bool get canCompleteSelection => _selectedSphereIds.length == 3;

  SurveyController() {}

  // Инициализация опроса
  Future<void> initializeSurvey() async {
    _setLoading(true);
    _clearError();

    try {
      // Проверяем, есть ли уже завершенный опрос
      final existingResult = await SurveyDataService.getSurveyResults();

      if (existingResult != null) {
        _spheres = existingResult.spheres;
        _selectedSphereIds = existingResult.selectedSpheresIds;
        _state =
            _selectedSphereIds.isNotEmpty
                ? SurveyState.finished
                : SurveyState.completed;
      } else {
        // Начинаем новый опрос
        _spheres = SurveyDataService.getLifeSpheres();
        _currentIndex = 0;
        _state = SurveyState.inProgress;
      }
    } catch (e) {
      _setError('Ошибка при загрузке опроса: $e');
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> checkShouldShowSurveyScreen() async {
    final existingResult = await SurveyDataService.getSurveyResults();

    if (existingResult != null) {
      return false;
    } else {
      return true;
    }
  }

  // Начать новый опрос
  void startNewSurvey() {
    _spheres = SurveyDataService.getLifeSpheres();
    _currentIndex = 0;
    _selectedSphereIds.clear();
    _state = SurveyState.inProgress;
    _clearError();
    notifyListeners();
  }

  // Переход к следующей сфере
  void nextSphere() {
    if (canGoNext) {
      _currentIndex++;
      notifyListeners();
    }
  }

  // Переход к предыдущей сфере
  void previousSphere() {
    if (canGoPrevious) {
      _currentIndex--;
      notifyListeners();
    }
  }

  // Переход к конкретной сфере
  void goToSphere(int index) {
    if (index >= 0 && index < _spheres.length) {
      _currentIndex = index;
      notifyListeners();
    }
  }

  // Обновление рейтинга сферы
  void updateSphereRating(int rating) {
    if (currentSphere != null) {
      final updatedSphere = currentSphere!.copyWith(rating: rating);
      _spheres[_currentIndex] = updatedSphere;
      notifyListeners();
    }
  }

  // Обновление комментария к сфере
  void updateSphereComment(String? comment) {
    if (currentSphere != null) {
      final updatedSphere = currentSphere!.copyWith(additionalComment: comment);
      _spheres[_currentIndex] = updatedSphere;
      notifyListeners();
    }
  }

  // Завершение опроса оценок
  Future<void> completeSurvey() async {
    _setLoading(true);
    _clearError();

    try {
      final result = LifestyleSurveyResult(
        spheres: _spheres,
        completedAt: DateTime.now(),
      );

      await SurveyDataService.saveSurveyResults(result);
      _state = SurveyState.completed;
    } catch (e) {
      _setError('Ошибка при сохранении опроса: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Переключение выбора сферы для дальнейшей работы
  void toggleSphereSelection(int sphereId) {
    if (_selectedSphereIds.contains(sphereId)) {
      _selectedSphereIds.remove(sphereId);
    } else if (_selectedSphereIds.length < 3) {
      _selectedSphereIds.add(sphereId);
    }
    notifyListeners();
  }

  // Завершение выбора сфер
  Future<void> completeSphereSelection() async {
    if (_selectedSphereIds.length != 3) return;

    _setLoading(true);
    _clearError();

    try {
      await SurveyDataService.saveSelectedSpheres(_selectedSphereIds);

      // Обновляем результат с выбранными сферами
      final result = LifestyleSurveyResult(
        spheres: _spheres,
        selectedSpheresIds: _selectedSphereIds,
        completedAt: DateTime.now(),
      );

      await SurveyDataService.saveSurveyResults(result);
      _state = SurveyState.finished;
    } catch (e) {
      _setError('Ошибка при сохранении выбранных сфер: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Получение выбранных сфер для работы
  List<LifeSphere> getSelectedSpheresForWork() {
    return _spheres
        .where((sphere) => _selectedSphereIds.contains(sphere.id))
        .toList();
  }

  // Сброс опроса (для тестирования)
  Future<void> resetSurvey() async {
    _setLoading(true);
    try {
      await SurveyDataService.clearSurveyData();
      _spheres.clear();
      _selectedSphereIds.clear();
      _currentIndex = 0;
      _state = SurveyState.initial;
      _clearError();
    } catch (e) {
      _setError('Ошибка при сбросе опроса: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Проверка необходимости повторного опроса
  Future<bool> shouldShowRepeatedSurvey() async {
    return await SurveyDataService.shouldShowRepeatedSurvey();
  }

  // Получение прогресса опроса (в процентах)
  double get progress {
    if (_spheres.isEmpty) return 0.0;
    return (_currentIndex + 1) / _spheres.length;
  }

  // Приватные методы
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}

// Enum для состояний опроса
enum SurveyState {
  initial, // Начальное состояние
  inProgress, // Опрос в процессе
  completed, // Опрос завершен, нужно выбрать сферы
  finished, // Всё завершено, сферы выбраны
}
