import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/core/models/entertainment_model.dart';
import 'package:organizer/core/models/hobby_model.dart';
import 'package:organizer/core/models/year_goal_model.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/services/gpt_service/gpt_service.dart';
import 'package:organizer/core/storages/entertainment_database.dart';
import 'package:organizer/core/storages/hobbies_database.dart';
import 'package:organizer/core/storages/lifestyle_mission_database.dart';
import 'package:organizer/core/storages/mock_entertainment.dart';
import 'package:organizer/core/storages/year_goal_database.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/controller/bh_controller.dart';

final lifeStyleController = ChangeNotifierProvider(
  ((ref) => LifestyleController()),
);

class LifestyleController extends ChangeNotifier {
  List<YearGoalModel> yearGoals = [];
  List<HobbyModel> myHobbies = [];
  List<EntertainmentModel> myEntertainments = mockEntertainments;
  String? missionText = '';

  LifestyleController() {}

  Future<void> getAllYearGoals() async {
    yearGoals = await YearGoalDatabase.instance.readAllGoals();
    notifyListeners();
  }

  Future<void> createYearGoal(
    BuildContext context, {
    required String title,
  }) async {
    var newGoal = YearGoalModel(
      title: title,
      startDate: DateTime.now(),
      isCompleted: false,
    );
    await YearGoalDatabase.instance.createGoal(newGoal);
    await getAllYearGoals();
    Navigation.goBack(context);
  }

  Future<void> makeGoalCompleted(YearGoalModel yearGoalModel) async {
    yearGoalModel.isCompleted = true;
    await YearGoalDatabase.instance.updateGoal(yearGoalModel);
    await getAllYearGoals();
  }

  //HOBBIES
  Future<void> getAllHobbies() async {
    myHobbies = await HobbyDatabase().getAllHobbies();
    notifyListeners();
  }

  Future<void> makeHobbyCompleted(HobbyModel hobby) async {
    hobby.isCompleted = true;
    await HobbyDatabase().updateHobby(hobby);
    await getAllHobbies();
  }

  Future<void> askGPTYourMission(String dateBirth) async {
    missionText = null;
    missionText = await OpenAIService().fetchMissionByBirthday(dateBirth);
    if (missionText != null) {
      await LifestyleMissionDatabase.instance.saveMission(
        LifestyleMission(text: missionText!, date: dateBirth),
      );
    }
    notifyListeners();
  }

  void setMission(String missionValue) async {
    missionText = missionValue;
    notifyListeners();
  }

  //Entertainments

  Future<void> planEntertainmentsToWeekend(
    BuildContext context,
    EntertainmentModel model,
  ) async {
    final db = await EntertainmentDatabase.instance.database;

    // 1. Определяем ближайшую субботу и воскресенье
    DateTime now = DateTime.now();
    int daysToSaturday = DateTime.saturday - now.weekday;
    if (daysToSaturday < 0) daysToSaturday += 7;

    DateTime saturday = DateTime(
      now.year,
      now.month,
      now.day,
    ).add(Duration(days: daysToSaturday));
    DateTime sunday = saturday.add(const Duration(days: 1));

    // 2. Копируем модель на субботу и воскресенье
    final saturdayModel = EntertainmentModel(
      text: model.text,
      description: model.description,
      plannedDate: saturday,
      isCompleted: false,
    );

    final sundayModel = EntertainmentModel(
      text: model.text,
      description: model.description,
      plannedDate: sunday,
      isCompleted: false,
    );

    // 3. Записываем обе активности в базу
    await db.insert('entertainment', saturdayModel.toJson());
    await db.insert('entertainment', sundayModel.toJson());
    AppNotifications.showSuccess(
      context,
      "Развлечение добавлено на ближайшие выходные",
    );
  }

  Future<void> planEntertainmentsToExactDate(
    BuildContext context,
    EntertainmentModel model,
  ) async {
    final db = await EntertainmentDatabase.instance.database;

    // 1. Диалог выбора даты
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (pickedDate == null) return; // пользователь отменил выбор

    // 2. Очищаем время (ставим 00:00:00)
    final finalDate = DateTime(
      pickedDate.year,
      pickedDate.month,
      pickedDate.day,
    );

    // 3. Создаём новую модель с выбранной датой
    final newModel = EntertainmentModel(
      text: model.text,
      description: model.description,
      plannedDate: finalDate,
      isCompleted: false,
    );

    // 4. Сохраняем в БД
    await db.insert('entertainment', newModel.toJson());
    AppNotifications.showSuccess(
      context,
      "Развлечение добавлено на указанную дату",
    );
  }
}
