// screens/survey_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/survey_widgets/rating_slider.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/survey_widgets/sphere_selection_grid.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/survey_widgets/survey_progress_indicator.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/survey_widgets/survey_results_display.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/survey_widgets/survey_sphere_card.dart';

class SurveyScreen extends ConsumerStatefulWidget {
  const SurveyScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<SurveyScreen> createState() => _SurveyScreenState();
}

class _SurveyScreenState extends ConsumerState<SurveyScreen> {
  final PageController _pageController = PageController();
  final TextEditingController _commentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(surveyController).initializeSurvey();
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = ref.watch(surveyController);

    if (controller.isLoading) {
      return const Scaffold(
        backgroundColor: AppConstants.bgColor,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (controller.errorMessage != null) {
      return Scaffold(
        backgroundColor: AppConstants.bgColor,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline,
                size: 64,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 16),
              Text(
                'Произошла ошибка',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                controller.errorMessage!,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => ref.read(surveyController).initializeSurvey(),
                child: const Text('Попробовать снова'),
              ),
            ],
          ),
        ),
      );
    }

    switch (controller.state) {
      case SurveyState.initial:
        return _buildWelcomeScreen();
      case SurveyState.inProgress:
        return _buildSurveyScreen();
      case SurveyState.completed:
        return _buildResultsScreen();
      case SurveyState.finished:
        return _buildFinishedScreen();
    }
  }

  Widget _buildWelcomeScreen() {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('🌱', style: TextStyle(fontSize: 80)),
              const SizedBox(height: 24),
              Text(
                'Опрос удовлетворённости жизнью',
                style: GoogleFonts.unbounded(
                  fontSize: 18,
                  color: AppConstants.darkGreenColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                'Оцени 8 важных сфер своей жизни, чтобы понять, где всё хорошо, а где стоит уделить больше внимания.',
                style: GoogleFonts.unbounded(
                  fontSize: 14,
                  color: AppConstants.whiteColor,
                ),
                textAlign: TextAlign.center,
              ),
              Spacer(),
              AnimatedButton(
                onTap: () => ref.read(surveyController).startNewSurvey(),
                child: Container(
                  height: 44,

                  decoration: BoxDecoration(
                    color: AppConstants.darkGreenColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Center(
                      child: Text(
                        'Начать опрос',
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSurveyScreen() {
    final controller = ref.watch(surveyController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      appBar: AppBar(
        backgroundColor: AppConstants.bgColor,
        title: Text(
          '${controller.currentIndex + 1} из ${controller.spheres.length}',
          style: GoogleFonts.unbounded(fontSize: 14, color: Colors.grey),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: SurveyProgressIndicator(progress: controller.progress),
        ),
        leading:
            controller.canGoPrevious
                ? AnimatedButton(
                  onTap: () {
                    ref.read(surveyController).previousSphere();
                    _pageController.previousPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                    );
                  },
                  child: Icon(
                    Icons.arrow_back_ios_new,
                    color: AppConstants.whiteColor,
                  ),
                )
                : null,
      ),
      body: PageView.builder(
        controller: _pageController,
        onPageChanged: (index) {
          ref.read(surveyController).goToSphere(index);
          _updateCommentController();
        },
        itemCount: controller.spheres.length,
        itemBuilder: (context, index) {
          return _buildSphereCard(controller.spheres[index]);
        },
      ),
      bottomNavigationBar: _buildBottomNavigation(),
    );
  }

  Widget _buildSphereCard(sphere) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SurveySphereCard(sphere: sphere),
          const SizedBox(height: 32),
          RatingSlider(
            value: sphere.rating,
            onChanged: (rating) {
              ref.read(surveyController).updateSphereRating(rating);
            },
          ),
          const SizedBox(height: 32),
          Text(
            'Хочешь что-то добавить?',
            style: GoogleFonts.unbounded(
              fontSize: 14,
              color: AppConstants.whiteColor,
            ),
          ),
          const SizedBox(height: 8),
          TextInputField(
            height: 60,
            controller: _commentController,
            hintText:
                "Общее впечатление или слово, описывающее данную сферу жизни",
            maxLines: 3,
            onChanged: (value) {
              ref
                  .read(surveyController)
                  .updateSphereComment(value.isEmpty ? null : value);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigation() {
    final controller = ref.watch(surveyController);

    return Container(
      padding: const EdgeInsets.all(24.0),
      child: Row(
        children: [
          if (controller.canGoPrevious)
            Expanded(
              child: AnimatedButton(
                onTap: () async {
                  ref.read(surveyController).previousSphere();
                  _pageController.previousPage(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                },
                child: Container(
                  height: 44,

                  decoration: BoxDecoration(
                    color: AppConstants.bgGreyColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Center(
                      child: Text(
                        "Назад",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.darkGreenColor,
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          if (controller.canGoPrevious) const SizedBox(width: 16),

          Expanded(
            flex: 2,
            child: AnimatedButton(
              onTap: () async {
                if (controller.isLastSphere) {
                  ref.read(surveyController).completeSurvey();
                } else {
                  ref.read(surveyController).nextSphere();
                  _pageController.nextPage(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                }
              },
              child: Container(
                height: 44,

                decoration: BoxDecoration(
                  color: AppConstants.darkGreenColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Center(
                    child: Text(
                      controller.isLastSphere ? 'Готово' : 'Далее',
                      style: GoogleFonts.unbounded(
                        color: AppConstants.bgColor,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultsScreen() {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      appBar: AppBar(
        backgroundColor: AppConstants.bgColor,
        title: Text(
          'Результаты опроса',
          style: GoogleFonts.unbounded(
            fontSize: 14,
            color: AppConstants.whiteColor,
          ),
        ),
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 16.0, right: 16),
              child: Column(
                children: [
                  Text(
                    'Ты молодец — уже сделал(а) первый шаг, взглянув честно на разные сферы своей жизни.',
                    style: GoogleFonts.unbounded(
                      fontSize: 12,
                      color: AppConstants.whiteColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Сейчас ты видишь, где есть пробелы и где необходимо больше твоего внимания. Не надо браться за всё сразу — выбери 3 сферы, которые важнее всего сейчас.',
                    style: GoogleFonts.unbounded(
                      fontSize: 12,
                      color: AppConstants.whiteColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Сфокусируйся на них, сделай маленькие шаги — и увидишь, как жизнь начнёт меняться к лучшему.',
                    style: GoogleFonts.unbounded(
                      fontSize: 12,
                      color: AppConstants.whiteColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 32),
                  const SphereSelectionGrid(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFinishedScreen() {
    final controller = ref.watch(surveyController);
    final selectedSpheres = controller.getSelectedSpheresForWork();

    return Scaffold(
      backgroundColor: AppConstants.bgColor,

      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 12.0, right: 8),
                child: CustomAppBar(text: "Сферы жизни"),
              ),

              const SizedBox(height: 8),
              SurveyResultsDisplay(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Ты выбрал(а) сферы для работы:',
                      style: GoogleFonts.unbounded(
                        fontSize: 14,
                        color: AppConstants.whiteColor,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    ...selectedSpheres.map(
                      (sphere) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppConstants.darkGreenColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: Text(
                              '${sphere.title}',
                              style: GoogleFonts.unbounded(
                                fontSize: 12,
                                color: AppConstants.bgColor,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              const SizedBox(height: 8),

              Text(
                'Остальные сферы? Они никуда не уйдут и ждут тебя — когда будешь готов(а), к ним можно будет вернуться.',
                style: GoogleFonts.unbounded(
                  fontSize: 12,
                  color: AppConstants.greyColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),

              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16),
                child: AnimatedButton(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppConstants.darkGreenColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Center(
                        child: Text(
                          'Продолжить',
                          style: GoogleFonts.unbounded(
                            color: AppConstants.bgColor,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16),
                child: AnimatedButton(
                  onTap: () => ref.read(surveyController).resetSurvey(),
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppConstants.bgGreyColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Center(
                        child: Text(
                          'Пройти опрос заново',
                          style: GoogleFonts.unbounded(
                            color: AppConstants.darkGreenColor,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _updateCommentController() {
    final controller = ref.read(surveyController);
    if (controller.currentSphere != null) {
      _commentController.text =
          controller.currentSphere!.additionalComment ?? '';
    }
  }
}
