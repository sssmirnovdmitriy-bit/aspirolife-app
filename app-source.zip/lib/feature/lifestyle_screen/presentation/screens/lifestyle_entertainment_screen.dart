import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';
import 'package:organizer/feature/organizer_screen/presentation/controller/organizer_controller.dart';

class LifestyleEntertainmentScreen extends ConsumerWidget {
  const LifestyleEntertainmentScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var lifestyleModel = ref.watch(lifeStyleController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8),
          child: Column(
            children: [
              SizedBox(height: 50),
              CustomAppBar(text: "Развлечения"),
              Expanded(
                child: ListView.builder(
                  physics: AlwaysScrollableScrollPhysics(),
                  shrinkWrap: true,
                  padding: EdgeInsets.only(bottom: 40),
                  itemCount: lifestyleModel.myEntertainments.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          color: AppConstants.secondaryColor.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "${lifestyleModel.myEntertainments[index].text}",
                                style: GoogleFonts.unbounded(
                                  color: const Color.fromARGB(
                                    255,
                                    255,
                                    59,
                                    124,
                                  ),
                                  fontSize: 13,
                                ),
                              ),
                              SizedBox(height: 8),
                              Container(
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  color: AppConstants.darkGreenColor.withAlpha(
                                    20,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.thumb_up_alt,
                                        size: 16,
                                        color: AppConstants.darkGreenColor,
                                      ),
                                      SizedBox(width: 8),
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width *
                                            0.8,
                                        child: Text(
                                          "${lifestyleModel.myEntertainments[index].description}",
                                          style: GoogleFonts.unbounded(
                                            color: AppConstants.whiteColor,
                                            fontSize: 10,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(height: 16),
                              Text(
                                "Добавление в Органайзер",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.whiteColor,
                                  fontSize: 11,
                                ),
                              ),
                              SizedBox(height: 8),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  AnimatedButton(
                                    onTap: () async {
                                      await ref
                                          .read(lifeStyleController)
                                          .planEntertainmentsToWeekend(
                                            context,
                                            lifestyleModel
                                                .myEntertainments[index],
                                          );
                                    },
                                    child: Container(
                                      height: 34,
                                      width:
                                          MediaQuery.of(context).size.width *
                                          0.45,
                                      decoration: BoxDecoration(
                                        color: const Color.fromARGB(
                                          147,
                                          13,
                                          14,
                                          14,
                                        ),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(4.0),
                                        child: Center(
                                          child: Text(
                                            "На выходные",
                                            style: GoogleFonts.unbounded(
                                              color:
                                                  AppConstants.darkGreenColor,
                                              fontSize: 10,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  AnimatedButton(
                                    onTap: () async {
                                      await ref
                                          .read(lifeStyleController)
                                          .planEntertainmentsToExactDate(
                                            context,
                                            lifestyleModel
                                                .myEntertainments[index],
                                          );
                                    },
                                    child: Container(
                                      height: 34,
                                      width:
                                          MediaQuery.of(context).size.width *
                                          0.45,
                                      decoration: BoxDecoration(
                                        color: AppConstants.darkGreenColor,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(4.0),
                                        child: Center(
                                          child: Text(
                                            "Выбрать дату",
                                            style: GoogleFonts.unbounded(
                                              color: AppConstants.bgColor,
                                              fontSize: 10,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
