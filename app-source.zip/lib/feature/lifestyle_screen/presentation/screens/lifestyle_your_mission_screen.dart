import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/components/typewritter_widget.dart';
import 'package:organizer/core/services/gpt_service/gpt_service.dart';
import 'package:organizer/core/storages/lifestyle_mission_database.dart';
import 'package:organizer/feature/finances_screen/data/models/ticker_radiomodel.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';

class AiYourMissionScreen extends ConsumerStatefulWidget {
  const AiYourMissionScreen({super.key});

  @override
  _AiYourMissionScreenState createState() => _AiYourMissionScreenState();
}

class _AiYourMissionScreenState extends ConsumerState<AiYourMissionScreen> {
  bool isLoading = false;

  TextEditingController dateController = TextEditingController();

  @override
  void initState() {
    _getInfo();
    super.initState();
  }

  void _getInfo() async {
    var mission = await LifestyleMissionDatabase.instance.getMission();
    if (mission != null) {
      ref.read(lifeStyleController).setMission(mission.text);
      setState(() {
        dateController = TextEditingController(text: mission.date);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    var lifestyleModel = ref.watch(lifeStyleController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  CustomAppBar(text: "Твоя миссия"),
                  SizedBox(height: 20),

                  Row(
                    children: [
                      Text(
                        "Ваша дата рождения*",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  TextInputField(
                    radius: 10,
                    height: 44,
                    keyboard: TextInputType.numberWithOptions(),
                    controller: dateController,
                    hintText: "Например, 01.01.2024",
                    onChanged: (value) {
                      setState(() {});
                    },
                  ),
                  SizedBox(height: 10),
                  AnimatedButton(
                    onTap: () async {
                      if (lifestyleModel.missionText != null &&
                          dateController.text.isNotEmpty) {
                        setState(() {
                          isLoading = true;
                        });
                        await ref
                            .read(lifeStyleController)
                            .askGPTYourMission(dateController.text);
                        setState(() {
                          isLoading = false;
                        });
                      }
                    },
                    child: Container(
                      height: 44,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: AppConstants.bgGreyColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(
                          child:
                              isLoading
                                  ? SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 1,
                                      color: AppConstants.darkGreenColor,
                                    ),
                                  )
                                  : Text(
                                    "Расчитать",
                                    style: GoogleFonts.unbounded(
                                      color:
                                          (lifestyleModel.missionText != null &&
                                                  dateController
                                                      .text
                                                      .isNotEmpty)
                                              ? AppConstants.darkGreenColor
                                              : AppConstants.greyColor,
                                      fontSize: 12,
                                    ),
                                  ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  lifestyleModel.missionText == null
                      ? SizedBox()
                      : Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          ConstrainedBox(
                            constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.of(context).size.width * 0.94,
                            ),
                            child: TypewriterText(
                              text: lifestyleModel.missionText!,
                              textStyle: GoogleFonts.unbounded(
                                color: AppConstants.whiteColor,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                  SizedBox(height: 500),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
