import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';

class LifestyleHobbyScreen extends ConsumerWidget {
  const LifestyleHobbyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var lifestyleModel = ref.watch(lifeStyleController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8),
          child: ListView(
            children: [
              CustomAppBar(text: "Хобби"),
              SizedBox(height: 20),
              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: EdgeInsets.zero,
                itemCount: lifestyleModel.myHobbies.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Container(
                      height: 40,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color:
                            lifestyleModel.myHobbies[index].isCompleted
                                ? AppConstants.darkGreenColor
                                : AppConstants.secondaryColor.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "${lifestyleModel.myHobbies[index].hobbyName}",
                              style: GoogleFonts.unbounded(
                                color:
                                    lifestyleModel.myHobbies[index].isCompleted
                                        ? AppConstants.bgColor
                                        : AppConstants.whiteColor,
                                fontSize: 12,
                              ),
                            ),
                            lifestyleModel.myHobbies[index].isCompleted
                                ? Text(
                                  "Активно",
                                  style: GoogleFonts.unbounded(
                                    color: AppConstants.bgColor,
                                    fontSize: 10,
                                  ),
                                )
                                : AnimatedButton(
                                  onTap: () async {
                                    await ref
                                        .read(lifeStyleController)
                                        .makeHobbyCompleted(
                                          lifestyleModel.myHobbies[index],
                                        );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 4.0),
                                    child: Container(
                                      height: 26,
                                      width:
                                          MediaQuery.of(context).size.width *
                                          0.24,
                                      decoration: BoxDecoration(
                                        color: AppConstants.bgGreyColor,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(4.0),
                                        child: Center(
                                          child: Text(
                                            "Выбрать",
                                            style: GoogleFonts.unbounded(
                                              color:
                                                  AppConstants.darkGreenColor,
                                              fontSize: 10,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
