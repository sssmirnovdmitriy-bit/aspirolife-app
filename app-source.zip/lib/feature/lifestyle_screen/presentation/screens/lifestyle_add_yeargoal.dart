import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/components/text_input_field.dart';
import 'package:organizer/feature/finances_screen/presentation/controller/finances_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';

class AddYearGoalScreen extends ConsumerStatefulWidget {
  const AddYearGoalScreen({super.key});

  @override
  _AddYearGoalScreenState createState() => _AddYearGoalScreenState();
}

class _AddYearGoalScreenState extends ConsumerState<AddYearGoalScreen> {
  final TextEditingController mainGoalController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var lifestyle = ref.watch(lifeStyleController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 14.0, right: 14, bottom: 20),
        child:
            (mainGoalController.text.isNotEmpty)
                ? AnimatedButton(
                  onTap: () async {
                    await ref
                        .read(lifeStyleController)
                        .createYearGoal(
                          context,
                          title: mainGoalController.text,
                        );
                  },
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.darkGreenColor,
                    ),
                    child: Center(
                      child: Text(
                        "Добавить цель",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                )
                : AnimatedButton(
                  onTap: () async {},
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppConstants.greyColor,
                    ),
                    child: Center(
                      child: Text(
                        "Добавить цель",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.bgColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8),
          child: ListView(
            children: [
              CustomAppBar(text: "Добавление цели"),
              SizedBox(height: 20),
              Text(
                "Цель на год",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 4),
              TextInputField(
                radius: 10,
                height: 44,
                maxLength: 200,
                controller: mainGoalController,
                hintText: "",
                onChanged: (value) {
                  setState(() {});
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
