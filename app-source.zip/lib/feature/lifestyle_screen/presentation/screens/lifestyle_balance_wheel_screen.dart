import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_psychology_section.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_survey_section.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/survey_widgets/survey_lifebalance_wheel.dart';

class LifestyleBalanceWheelScreen extends ConsumerWidget {
  const LifestyleBalanceWheelScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final surveyModel = ref.watch(surveyController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8),
          child: Column(
            children: [
              SizedBox(height: 50),
              CustomAppBar(text: "Колесо Баланса"),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    RepaintBoundary(
                      child: LifeBalanceWheel(
                        spheres: surveyModel.spheres,
                        size: 280,
                        showLabels: true,
                        showValues: true,
                        showEmojis: false,
                      ),
                    ),
                    SizedBox(height: 20),
                    LifestyleSurveySectionUncompleted(),
                    SizedBox(height: 400),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
