import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/storages/mock_psychology_videos.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/gh_videos_widget.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';

class LifestylePsychologyScreen extends ConsumerWidget {
  const LifestylePsychologyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final surveyModel = ref.watch(surveyController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8),
          child: Column(
            children: [
              SizedBox(height: 50),
              CustomAppBar(text: "Психология"),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    GhVideosWidget(
                      habbit: null,
                      customVideos: mockPsychologyVideos,
                    ),
                    SizedBox(height: 400),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
