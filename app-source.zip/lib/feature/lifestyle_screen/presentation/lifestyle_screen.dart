import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/services/money_counter/money_saved_widget.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_appbar.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_book_card.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_psychology_section.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_events.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_hobby_section.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_message_section.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_natal_card.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_balance_wheel.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_recomendation_widget.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_survey_section.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_year_goal.dart';

class LifestyleScreen extends ConsumerStatefulWidget {
  const LifestyleScreen({super.key});

  @override
  _LifestyleScreenState createState() => _LifestyleScreenState();
}

class _LifestyleScreenState extends ConsumerState<LifestyleScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  LifestyleAppbar(),
                  SizedBox(height: 10),
                  ListView(
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    children: [
                      LifestyleBalanceWheelSection(),
                      SizedBox(height: 10),
                      LifestylePsychologySection(),
                      SizedBox(height: 10),
                      LifestyleNatalCard(),
                      SizedBox(height: 10),
                      LifestyleBookCard(),
                      SizedBox(height: 10),
                      LifestyleHobbySection(),
                      SizedBox(height: 10),
                      LifestyleEvents(),
                      SizedBox(height: 10),
                      LifestyleYearGoal(),
                    ],
                  ),

                  SizedBox(height: 400),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
