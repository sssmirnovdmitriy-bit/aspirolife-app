import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';

class RatingSlider extends StatefulWidget {
  final int value;
  final ValueChanged<int> onChanged;

  const RatingSlider({Key? key, required this.value, required this.onChanged})
    : super(key: key);

  @override
  State<RatingSlider> createState() => _RatingSliderState();
}

class _RatingSliderState extends State<RatingSlider> {
  late int _currentValue;

  @override
  void initState() {
    super.initState();
    _currentValue = widget.value;
  }

  @override
  void didUpdateWidget(RatingSlider oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value) {
      _currentValue = widget.value;
    }
  }

  Color _getColorForValue(int value) {
    switch (value) {
      case 0:
      case 1:
        return const Color(0xFFFF0000); // Красный
      case 2:
      case 3:
        return const Color(0xFFFF6600); // Оранжево-красный
      case 4:
      case 5:
        return const Color(0xFFFFA500); // Оранжевый
      case 6:
      case 7:
        return const Color(0xFFFFFF00); // Жёлтый
      case 8:
      case 9:
        return const Color(0xFF90EE90); // Светло-зелёный
      case 10:
        return AppConstants.darkGreenColor; // Зелёный
      default:
        return const Color(0xFFFFA500);
    }
  }

  String _getDescriptionForValue(int value) {
    switch (value) {
      case 0:
        return 'Ужасно. Всё разваливается.';
      case 1:
        return 'Очень плохо. Почти невыносимо.';
      case 2:
        return 'Плохо. Всё не так, как хочется.';
      case 3:
        return 'Слабо. Много напряжения и недовольства.';
      case 4:
        return 'Так себе. Часто тяжело, хочется по-другому.';
      case 5:
        return 'Нормально. Терпимо, но без радости.';
      case 6:
        return 'Скорее да. Иногда даже приятно.';
      case 7:
        return 'Хорошо. В целом устраивает.';
      case 8:
        return 'Очень хорошо. Поддерживает и радует.';
      case 9:
        return 'Почти идеально. Всё на своём месте.';
      case 10:
        return 'Прекрасно. Полная гармония.';
      default:
        return 'Нормально. Терпимо, но без радости.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Оцени по 10-балльной шкале:',
          style: GoogleFonts.unbounded(
            fontSize: 14,
            color: AppConstants.whiteColor,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _getColorForValue(_currentValue).withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _getColorForValue(_currentValue),
              width: 2,
            ),
          ),
          child: Column(
            children: [
              Text(
                _currentValue.toString(),
                style: GoogleFonts.unbounded(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: _getColorForValue(_currentValue),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _getDescriptionForValue(_currentValue),
                style: GoogleFonts.unbounded(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: _getColorForValue(_currentValue),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: _getColorForValue(_currentValue),
            inactiveTrackColor: _getColorForValue(
              _currentValue,
            ).withOpacity(0.3),
            thumbColor: _getColorForValue(_currentValue),
            overlayColor: _getColorForValue(_currentValue).withOpacity(0.2),
            trackHeight: 6,
          ),
          child: Slider(
            value: _currentValue.toDouble(),
            min: 0,
            max: 10,
            divisions: 10,
            onChanged: (value) {
              setState(() {
                _currentValue = value.round();
              });
              widget.onChanged(_currentValue);
            },
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '0 - Ужасно',
              style: GoogleFonts.unbounded(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: AppConstants.greyColor,
              ),
            ),
            Text(
              '10 - Прекрасно',
              style: GoogleFonts.unbounded(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: AppConstants.greyColor,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
