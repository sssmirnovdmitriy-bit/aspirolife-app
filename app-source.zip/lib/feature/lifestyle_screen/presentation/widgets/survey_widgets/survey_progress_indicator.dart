import 'package:flutter/material.dart';
import 'package:organizer/components/app_constants.dart';

class SurveyProgressIndicator extends StatelessWidget {
  final double progress;

  const SurveyProgressIndicator({Key? key, required this.progress})
    : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LinearProgressIndicator(
      value: progress,
      backgroundColor: AppConstants.darkGreenColor,
      valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
    );
  }
}
