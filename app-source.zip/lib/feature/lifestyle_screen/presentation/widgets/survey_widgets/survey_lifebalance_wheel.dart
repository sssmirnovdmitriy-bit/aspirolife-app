import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math' as math;

import 'package:organizer/feature/lifestyle_screen/data/lifesphere_model.dart';

class LifeBalanceWheel extends StatefulWidget {
  final List<LifeSphere> spheres;
  final double size;
  final bool showLabels;
  final bool showValues;
  final bool showEmojis;
  final VoidCallback? onTap;

  const LifeBalanceWheel({
    Key? key,
    required this.spheres,
    this.size = 300,
    this.showLabels = true,
    this.showValues = true,
    this.showEmojis = true,
    this.onTap,
  }) : super(key: key);

  @override
  State<LifeBalanceWheel> createState() => _LifeBalanceWheelState();
}

class _LifeBalanceWheelState extends State<LifeBalanceWheel>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  static bool _hasAnimatedGlobally = false; // Глобальный флаг
  List<LifeSphere>? _previousSpheres; // Сохраняем предыдущее состояние

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _animationController.value = 1;
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    );

    // Запускаем анимацию только при первом запуске
    if (!_hasAnimatedGlobally) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _animationController.forward();
          _hasAnimatedGlobally = true;
        }
      });
    } else {
      // Если уже была анимация, сразу показываем конечное состояние
      _animationController.value = 1.0;
    }

    _previousSpheres = List.from(widget.spheres);
  }

  @override
  void didUpdateWidget(LifeBalanceWheel oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Проверяем, действительно ли изменились данные сфер
    if (_hasDataChanged(oldWidget.spheres, widget.spheres)) {
      _previousSpheres = List.from(widget.spheres);
      // Запускаем анимацию только при реальном изменении данных
      _animationController.reset();
      _animationController.forward();
    }
  }

  // Метод для проверки реальных изменений в данных
  bool _hasDataChanged(
    List<LifeSphere> oldSpheres,
    List<LifeSphere> newSpheres,
  ) {
    if (oldSpheres.length != newSpheres.length) return true;

    for (int i = 0; i < oldSpheres.length; i++) {
      final oldSphere = oldSpheres[i];
      final newSphere = newSpheres[i];

      if (oldSphere.rating != newSphere.rating ||
          oldSphere.title != newSphere.title ||
          oldSphere.colorCode != newSphere.colorCode ||
          oldSphere.emoji != newSphere.emoji) {
        return true;
      }
    }
    return false;
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final adaptiveWidth = math.max(widget.size, screenWidth - 32);

    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: adaptiveWidth,
        height: widget.size,
        child: AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            return CustomPaint(
              size: Size(adaptiveWidth, widget.size),
              painter: BalanceWheelPainter(
                spheres: widget.spheres,
                animationValue: _animation.value,
                showLabels: widget.showLabels,
                showValues: widget.showValues,
                showEmojis: widget.showEmojis,
              ),
            );
          },
        ),
      ),
    );
  }
}

class BalanceWheelPainter extends CustomPainter {
  final List<LifeSphere> spheres;
  final double animationValue;
  final bool showLabels;
  final bool showValues;
  final bool showEmojis;

  BalanceWheelPainter({
    required this.spheres,
    required this.animationValue,
    required this.showLabels,
    required this.showValues,
    required this.showEmojis,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.height / 2) - 50;
    final maxRating = 10.0;

    // Рисуем концентрические круги (сетку)
    _drawGrid(canvas, center, radius, maxRating);

    // Рисуем сектора для каждой сферы
    _drawSpheres(canvas, center, radius, maxRating);

    // Рисуем подписи сфер
    if (showLabels) {
      _drawLabels(canvas, center, radius, size);
    }
  }

  void _drawGrid(
    Canvas canvas,
    Offset center,
    double radius,
    double maxRating,
  ) {
    final gridPaint =
        Paint()
          ..color = Colors.grey.withOpacity(0.3 * animationValue)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1;

    // Рисуем концентрические круги
    for (int i = 1; i <= maxRating.toInt(); i++) {
      final circleRadius = (radius / maxRating) * i * animationValue;
      canvas.drawCircle(center, circleRadius, gridPaint);
    }

    // Рисуем радиальные линии
    final angleStep = 2 * math.pi / spheres.length;
    for (int i = 0; i < spheres.length; i++) {
      final angle = i * angleStep - math.pi / 2;
      final endPoint = Offset(
        center.dx + radius * math.cos(angle) * animationValue,
        center.dy + radius * math.sin(angle) * animationValue,
      );
      canvas.drawLine(center, endPoint, gridPaint);
    }
  }

  void _drawSpheres(
    Canvas canvas,
    Offset center,
    double radius,
    double maxRating,
  ) {
    if (spheres.isEmpty) return;

    final angleStep = 2 * math.pi / spheres.length;
    final path = Path();
    final validSpheres = spheres.where((s) => s.rating > 0).toList();

    if (validSpheres.isEmpty) return;

    // Создаем путь для заливки
    for (int i = 0; i < spheres.length; i++) {
      final sphere = spheres[i];
      final angle = i * angleStep - math.pi / 2;
      final ratingRadius =
          (radius / maxRating) * sphere.rating * animationValue;

      final point = Offset(
        center.dx + ratingRadius * math.cos(angle),
        center.dy + ratingRadius * math.sin(angle),
      );

      if (i == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    path.close();

    // Заливаем область с градиентом
    final fillPaint =
        Paint()
          ..shader = RadialGradient(
            colors: [
              _hexToColor(
                spheres.first.colorCode,
              ).withOpacity(0.3 * animationValue),
              _getAverageColor().withOpacity(0.1 * animationValue),
            ],
          ).createShader(Rect.fromCircle(center: center, radius: radius))
          ..style = PaintingStyle.fill;
    canvas.drawPath(path, fillPaint);

    // Обводим контур
    final strokePaint =
        Paint()
          ..color = _getAverageColor().withOpacity(animationValue)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2;
    canvas.drawPath(path, strokePaint);

    // Рисуем точки для каждой сферы
    for (int i = 0; i < spheres.length; i++) {
      final sphere = spheres[i];
      final angle = i * angleStep - math.pi / 2;
      final ratingRadius =
          (radius / maxRating) * sphere.rating * animationValue;

      final point = Offset(
        center.dx + ratingRadius * math.cos(angle),
        center.dy + ratingRadius * math.sin(angle),
      );

      final sphereColor = _hexToColor(sphere.colorCode);

      // Рисуем внешнее кольцо точки с плавной анимацией
      final outerPointPaint =
          Paint()
            ..color = sphereColor.withOpacity(0.3 * animationValue)
            ..style = PaintingStyle.fill;
      canvas.drawCircle(point, 8 * animationValue, outerPointPaint);

      // Рисуем основную точку
      final pointPaint =
          Paint()
            ..color = sphereColor.withOpacity(animationValue)
            ..style = PaintingStyle.fill;
      canvas.drawCircle(point, 5 * animationValue, pointPaint);

      // Рисуем значение рейтинга с задержкой
      if (showValues && animationValue > 0.5) {
        _drawRatingValue(canvas, point, sphere.rating, sphereColor);
      }

      // Рисуем emoji с задержкой
      if (showEmojis && animationValue > 0.7) {
        _drawEmoji(canvas, point, sphere.emoji, angle);
      }
    }
  }

  void _drawRatingValue(Canvas canvas, Offset point, int rating, Color color) {
    final textPainter = TextPainter(
      text: TextSpan(
        text: rating.toString(),
        style: GoogleFonts.unbounded(
          fontSize: 10,
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();

    final textOffset = Offset(
      point.dx - textPainter.width / 2,
      point.dy - textPainter.height / 2,
    );

    // Фон для текста
    final textBgPaint =
        Paint()
          ..color = color
          ..style = PaintingStyle.fill;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: point,
          width: textPainter.width + 8,
          height: textPainter.height + 4,
        ),
        const Radius.circular(8),
      ),
      textBgPaint,
    );

    textPainter.paint(canvas, textOffset);
  }

  void _drawEmoji(Canvas canvas, Offset point, String emoji, double angle) {
    final emojiPainter = TextPainter(
      text: TextSpan(text: emoji, style: const TextStyle(fontSize: 16)),
      textDirection: TextDirection.ltr,
    );
    emojiPainter.layout();

    // Позиционируем emoji ближе к центру от точки
    final emojiOffset = Offset(
      point.dx - emojiPainter.width / 2 - 15 * math.cos(angle),
      point.dy - emojiPainter.height / 2 - 15 * math.sin(angle),
    );

    emojiPainter.paint(canvas, emojiOffset);
  }

  Color _hexToColor(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }

  Color _getAverageColor() {
    if (spheres.isEmpty) return const Color(0xFF4CAF50);

    double avgRating =
        spheres.fold(0, (sum, sphere) => sum + sphere.rating) / spheres.length;

    if (avgRating <= 3) return const Color(0xFFFF6600);
    if (avgRating <= 5) return const Color(0xFFFFA500);
    if (avgRating <= 7) return const Color(0xFFFFFF00);
    return const Color(0xFF90EE90);
  }

  void _drawLabels(
    Canvas canvas,
    Offset center,
    double radius,
    Size canvasSize,
  ) {
    if (spheres.isEmpty || animationValue < 0.3) return;

    final angleStep = 2 * math.pi / spheres.length;
    final maxTextWidth = 74.0;

    for (int i = 0; i < spheres.length; i++) {
      final sphere = spheres[i];
      final angle = i * angleStep - math.pi / 2;
      final labelRadius = radius + 50;

      final labelPoint = Offset(
        center.dx + labelRadius * math.cos(angle),
        center.dy + labelRadius * math.sin(angle),
      );

      String displayText = sphere.title.toUpperCase();

      final textPainter = TextPainter(
        text: TextSpan(
          text: displayText,
          style: GoogleFonts.unbounded(
            fontSize: 8,
            color: Colors.white.withOpacity(animationValue),
            fontWeight: FontWeight.w600,
            height: 1.2,
          ),
        ),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
        maxLines: 2,
        ellipsis: '..',
      );
      textPainter.layout(maxWidth: maxTextWidth);

      // Корректируем позицию с учетом размера canvas
      double textX = labelPoint.dx - textPainter.width / 2;
      double textY = labelPoint.dy - textPainter.height / 2;

      final angleNormalized = angle % (2 * math.pi);

      if (angleNormalized > math.pi / 4 && angleNormalized < 3 * math.pi / 4) {
        textY += 20;
      } else if (angleNormalized > -3 * math.pi / 4 &&
          angleNormalized < -math.pi / 4) {
        textY -= 20;
      } else if (angleNormalized >= 3 * math.pi / 4 ||
          angleNormalized <= -3 * math.pi / 4) {
        textX -= 5;
      } else {
        textX += 10;
      }

      final padding = 10.0;
      textX = math.max(
        padding,
        math.min(textX, canvasSize.width - textPainter.width - padding),
      );
      textY = math.max(
        padding,
        math.min(textY, canvasSize.height - textPainter.height - padding),
      );

      final textOffset = Offset(textX, textY);

      // Полупрозрачный фон
      final backgroundPaint =
          Paint()
            ..color = Colors.black.withOpacity(0.5 * animationValue)
            ..style = PaintingStyle.fill;

      final backgroundRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(
          textOffset.dx - 4,
          textOffset.dy - 2,
          textPainter.width + 8,
          textPainter.height + 4,
        ),
        const Radius.circular(8),
      );

      canvas.drawRRect(backgroundRect, backgroundPaint);
      textPainter.paint(canvas, textOffset);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return oldDelegate is! BalanceWheelPainter ||
        oldDelegate.animationValue != animationValue ||
        oldDelegate.spheres != spheres;
  }
}
