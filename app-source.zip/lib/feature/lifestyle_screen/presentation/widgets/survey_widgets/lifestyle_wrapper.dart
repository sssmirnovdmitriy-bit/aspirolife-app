import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/screens/survey_screen.dart';

class LifestyleWrapper extends ConsumerWidget {
  final Widget child;

  const LifestyleWrapper({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder<bool>(
      future: ref.read(surveyController).shouldShowRepeatedSurvey(),
      builder: (context, snapshot) {
        return Consumer(
          builder: (context, ref, _) {
            final controller = ref.watch(surveyController);

            // Показываем уведомление о повторном опросе
            if (snapshot.hasData && snapshot.data == true) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                _showRepeatedSurveyDialog(context, ref);
              });
            }

            // Если опрос не пройден, показываем экран опроса
            if (controller.state == SurveyState.initial) {
              return const SurveyScreen();
            }

            // Если опрос пройден, показываем основной контент
            return child;
          },
        );
      },
    );
  }

  void _showRepeatedSurveyDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Время для повторного опроса!'),
            content: const Text(
              'Прошёл месяц с последнего опроса. Хочешь обновить свои оценки и посмотреть, что изменилось?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Позже'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const SurveyScreen(),
                    ),
                  );
                },
                child: const Text('Пройти опрос'),
              ),
            ],
          ),
    );
  }
}
