import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/lifestyle_screen/data/lifesphere_model.dart';

class SurveySphereCard extends StatelessWidget {
  final LifeSphere sphere;

  const SurveySphereCard({Key? key, required this.sphere}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: AppConstants.secondaryColor,
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(sphere.emoji, style: const TextStyle(fontSize: 24)),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    sphere.title,
                    style: GoogleFonts.unbounded(
                      fontSize: 16,
                      color: AppConstants.whiteColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              sphere.description,
              style: GoogleFonts.unbounded(
                fontSize: 12,
                color: AppConstants.greyColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
