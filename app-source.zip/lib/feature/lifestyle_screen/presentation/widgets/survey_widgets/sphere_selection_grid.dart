import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/survey_widgets/sphere_selection_card.dart';

class SphereSelectionGrid extends ConsumerWidget {
  const SphereSelectionGrid({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(surveyController);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Выбери 3 сферы для работы:',
          style: GoogleFonts.unbounded(
            fontSize: 16,
            color: AppConstants.darkGreenColor,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        Text(
          '${controller.selectedSphereIds.length}/3 выбрано',
          style: GoogleFonts.unbounded(
            fontSize: 12,
            color: AppConstants.greyColor,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.2,
          ),
          itemCount: controller.spheres.length,
          itemBuilder: (context, index) {
            final sphere = controller.spheres[index];
            final isSelected = controller.selectedSphereIds.contains(sphere.id);
            final canSelect =
                controller.selectedSphereIds.length < 3 || isSelected;

            return SphereSelectionCard(
              sphere: sphere,
              isSelected: isSelected,
              canSelect: canSelect,
              onTap:
                  canSelect
                      ? () => ref
                          .read(surveyController)
                          .toggleSphereSelection(sphere.id)
                      : null,
            );
          },
        ),
        SizedBox(height: 16),
        AnimatedButton(
          onTap:
              controller.canCompleteSelection
                  ? () => ref.read(surveyController).completeSphereSelection()
                  : null,
          child:
              controller.isLoading
                  ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                  : Container(
                    height: 44,

                    decoration: BoxDecoration(
                      color:
                          controller.canCompleteSelection
                              ? AppConstants.darkGreenColor
                              : AppConstants.bgGreyColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Center(
                        child: Text(
                          "Продолжить",
                          style: GoogleFonts.unbounded(
                            color:
                                controller.canCompleteSelection
                                    ? AppConstants.bgColor
                                    : AppConstants.greyColor,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ),
        ),
        const SizedBox(height: 32),
      ],
    );
  }
}
