import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/lifestyle_screen/data/lifesphere_model.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/survey_controller.dart';

class SurveyResultsDisplay extends ConsumerWidget {
  final Widget? child;
  const SurveyResultsDisplay({Key? key, this.child}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(surveyController);

    return Padding(
      padding: const EdgeInsets.only(left: 16.0, right: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    'Общий обзор',
                    style: GoogleFonts.unbounded(
                      fontSize: 12,
                      color: AppConstants.darkGreenColor,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildOverviewStats(controller.spheres),
                ],
              ),
            ),
          ),
          SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: child ?? SizedBox(),
          ),
          SizedBox(height: 8),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.3,
            ),
            itemCount: controller.spheres.length,
            itemBuilder: (context, index) {
              return SphereResultCard(sphere: controller.spheres[index]);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewStats(List<LifeSphere> spheres) {
    final averageRating =
        spheres.map((s) => s.rating).reduce((a, b) => a + b) / spheres.length;
    final highSpheres = spheres.where((s) => s.rating >= 8).length;
    final lowSpheres = spheres.where((s) => s.rating <= 4).length;

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _StatItem(
              label: 'Средняя оценка',
              value: averageRating.toStringAsFixed(1),
              color: _getColorForRating(averageRating.round()),
            ),
            _StatItem(
              label: 'Высокие (8-10)',
              value: highSpheres.toString(),
              color: AppConstants.darkGreenColor,
            ),
            _StatItem(
              label: 'Низкие (0-4)',
              value: lowSpheres.toString(),
              color: Colors.red,
            ),
          ],
        ),
      ],
    );
  }

  Color _getColorForRating(int rating) {
    if (rating >= 8) return AppConstants.darkGreenColor;
    if (rating >= 6) return Colors.yellow[700]!;
    if (rating >= 4) return Colors.orange;
    return Colors.red;
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatItem({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: GoogleFonts.unbounded(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

class SphereResultCard extends StatelessWidget {
  final LifeSphere sphere;

  const SphereResultCard({Key? key, required this.sphere}) : super(key: key);

  Color _getColorFromHex(String hexColor) {
    return Color(int.parse(hexColor.substring(1), radix: 16) + 0xFF000000);
  }

  @override
  Widget build(BuildContext context) {
    final sphereColor = _getColorFromHex(sphere.colorCode);

    return Card(
      elevation: 2,
      child: Container(
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              sphereColor.withOpacity(0.1),
              sphereColor.withOpacity(0.05),
            ],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: sphereColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '${sphere.rating}/10',
                style: GoogleFonts.unbounded(
                  fontSize: 12,
                  color: AppConstants.bgColor,
                ),
              ),
            ),

            const SizedBox(height: 8),
            Text(
              sphere.title,
              style: GoogleFonts.unbounded(
                fontSize: 12,
                color: AppConstants.whiteColor,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),

            Text(
              sphere.satisfactionLevel,
              style: GoogleFonts.unbounded(fontSize: 10, color: sphereColor),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
