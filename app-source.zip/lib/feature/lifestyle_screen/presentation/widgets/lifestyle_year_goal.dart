import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_yeargoal_card.dart';

class LifestyleYearGoal extends ConsumerWidget {
  const LifestyleYearGoal({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var lifestyleModel = ref.watch(lifeStyleController);
    return Row(
      children: [
        Container(
          height: 50,
          width: 3,
          decoration: BoxDecoration(
            color: AppConstants.darkGreenColor,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              bottomLeft: Radius.circular(20),
            ),
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.95,
          decoration: BoxDecoration(
            color: AppConstants.secondaryColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            "Цели на год",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.whiteColor,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      lifestyleModel.yearGoals.isEmpty
                          ? SizedBox(
                            width: MediaQuery.of(context).size.width * 0.9,
                            child: Text(
                              "Когда Вы записываете цель, то с большей вероятностью она сбудется!",
                              style: GoogleFonts.unbounded(
                                color: AppConstants.greyColor,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )
                          : SizedBox(),
                      lifestyleModel.yearGoals.isEmpty
                          ? SizedBox()
                          : SizedBox(height: 8),
                      ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        itemCount: lifestyleModel.yearGoals.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: LifestyleYeargoalCard(
                              index: index,
                              yearGoalModel: lifestyleModel.yearGoals[index],
                              onTap: () async {
                                await ref
                                    .read(lifeStyleController)
                                    .makeGoalCompleted(
                                      lifestyleModel.yearGoals[index],
                                    );
                              },
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: AnimatedButton(
                  onTap: () async {
                    Navigation.goToAddYearGoalScreen(context);
                  },
                  child: Container(
                    height: 34,
                    width: MediaQuery.of(context).size.width * 0.94,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(147, 13, 14, 14),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Center(
                        child: Text(
                          "Добавить",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.darkGreenColor,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
