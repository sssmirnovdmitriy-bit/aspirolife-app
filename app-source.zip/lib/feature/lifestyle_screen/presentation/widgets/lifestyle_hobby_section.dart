import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';

class LifestyleHobbySection extends ConsumerWidget {
  const LifestyleHobbySection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var lifestyleModel = ref.watch(lifeStyleController);

    int completedCount = 0;
    for (var element in lifestyleModel.myHobbies) {
      if (element.isCompleted) {
        completedCount++;
      }
    }

    return AnimatedButton(
      onTap: () {
        Navigation.goToHobbyScreen(context);
      },
      child: Row(
        children: [
          Container(
            height: 50,
            width: 3,
            decoration: BoxDecoration(
              color: Colors.lightBlue,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                bottomLeft: Radius.circular(20),
              ),
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width * 0.95,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: AppConstants.bgGreyColor,
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Column(
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.68,
                        child: Text(
                          "Попробуйте новое Хобби!",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.whiteColor,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      SizedBox(height: 4),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.68,
                        child: Text(
                          "Разные активности помогают улучшить качество жизни",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.greyColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  Text(
                    "$completedCount из ${lifestyleModel.myHobbies.length}",
                    style: GoogleFonts.unbounded(
                      color: Colors.lightBlue,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(width: 4),
                  Icon(Icons.arrow_forward_ios_rounded),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
