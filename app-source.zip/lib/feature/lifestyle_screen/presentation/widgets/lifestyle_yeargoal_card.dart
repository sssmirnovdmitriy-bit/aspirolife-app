import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/year_goal_model.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/controller/lifestyle_controller.dart';

class LifestyleYeargoalCard extends ConsumerWidget {
  final int index;
  final YearGoalModel yearGoalModel;
  final void Function()? onTap;
  const LifestyleYeargoalCard({
    super.key,
    required this.index,
    required this.yearGoalModel,
    this.onTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AnimatedButton(
      onTap: onTap,
      child: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: AppConstants.bgColor.withAlpha(100),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color:
                          yearGoalModel.isCompleted == false
                              ? AppConstants.secondaryColor
                              : AppConstants.darkGreenColor,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child:
                          yearGoalModel.isCompleted == false
                              ? Text(
                                "#${index + 1}",
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.greyColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                              : Icon(
                                Icons.check,
                                color: AppConstants.bgColor,
                                size: 16,
                              ),
                    ),
                  ),
                  SizedBox(width: 16),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.7,
                    child: Text(
                      yearGoalModel.title,
                      maxLines: 2,
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
