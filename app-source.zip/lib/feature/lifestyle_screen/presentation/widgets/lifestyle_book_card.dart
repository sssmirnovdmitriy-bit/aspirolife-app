import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/purchase/book_constants.dart';

class LifestyleBookCard extends StatelessWidget {
  const LifestyleBookCard({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedButton(
      onTap: () {
        Navigation.goToBookScreen(context);
      },
      child: Row(
        children: [
          Container(
            height: 50,
            width: 3,
            decoration: BoxDecoration(
              color: AppConstants.darkGreenColor,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                bottomLeft: Radius.circular(20),
              ),
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width * 0.95,
            decoration: BoxDecoration(
              color: AppConstants.secondaryColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Книга: $bookTitle",
                        style: GoogleFonts.unbounded(
                          color: AppConstants.whiteColor,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  SizedBox(
                    width: MediaQuery.of(context).size.width,
                    child: Text(
                      "Дмитрий Смирнов — как перестать быть бедным",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.greyColor,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
