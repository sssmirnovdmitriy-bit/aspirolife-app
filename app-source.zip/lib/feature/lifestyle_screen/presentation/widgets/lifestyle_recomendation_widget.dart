import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/services/lifestyle_recomendation/mock_recomendations.dart';
import 'package:organizer/core/services/lifestyle_recomendation/recomendations_service.dart';

class LifeStyleRecomendationSection extends ConsumerStatefulWidget {
  const LifeStyleRecomendationSection({super.key});

  @override
  _LifeStyleRecomendationSectionState createState() =>
      _LifeStyleRecomendationSectionState();
}

class _LifeStyleRecomendationSectionState
    extends ConsumerState<LifeStyleRecomendationSection> {
  String recomendation = '';
  @override
  void initState() {
    _getFacts();
    super.initState();
  }

  void _getFacts() async {
    final recomendationsService = RecomendationsService(everydayRecomendations);
    await recomendationsService.init();
    setState(() {
      recomendation = recomendationsService.getTodayRecomendation();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: AppConstants.bgGreyColor,
      ),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  DateFormat('EEEE, d MMMM', 'ru').format(DateTime.now()),
                  style: GoogleFonts.unbounded(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 6),
            Row(
              children: [
                SizedBox(
                  height: 34,
                  width: MediaQuery.of(context).size.width * 0.89,
                  child:
                      recomendation == ""
                          ? Container()
                          : FactAnimator(facts: [recomendation]),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  "«/» Совет дня",
                  style: GoogleFonts.unbounded(
                    fontSize: 11,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class FactAnimator extends StatefulWidget {
  final List<String> facts;
  const FactAnimator({Key? key, required this.facts}) : super(key: key);

  @override
  _FactAnimatorState createState() => _FactAnimatorState();
}

class _FactAnimatorState extends State<FactAnimator> {
  int _currentFactIndex = 0;
  String _displayedText = "";
  late Timer _timer;
  Timer _typingTimer = Timer(Duration.zero, () {});

  @override
  void initState() {
    super.initState();
    _startTypingEffect();
    _timer = Timer.periodic(Duration(minutes: 10), (timer) {
      _nextFact();
    });
  }

  void _startTypingEffect() {
    String fullText = widget.facts[_currentFactIndex];
    _displayedText = "";
    _typingTimer?.cancel();

    int i = 0;
    _typingTimer = Timer.periodic(Duration(milliseconds: 50), (t) {
      if (i < fullText.length) {
        setState(() {
          _displayedText += fullText[i];
        });
        i++;
      } else {
        t.cancel();
      }
    });
  }

  void _nextFact() {
    setState(() {
      _currentFactIndex = (_currentFactIndex + 1) % widget.facts.length;
      _startTypingEffect();
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    _typingTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: Duration(milliseconds: 500),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: Offset(0.0, 0.2),
              end: Offset.zero,
            ).animate(animation),
            child: child,
          ),
        );
      },
      child: Text(
        _displayedText,
        key: ValueKey<String>(_displayedText),
        style: GoogleFonts.unbounded(
          fontSize: 12,
          color: AppConstants.lightGreyColor,
        ),
      ),
    );
  }
}
