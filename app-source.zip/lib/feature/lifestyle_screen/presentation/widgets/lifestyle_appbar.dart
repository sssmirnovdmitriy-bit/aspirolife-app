import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/services/lifestyle_recomendation/mock_recomendations.dart';
import 'package:organizer/core/services/lifestyle_recomendation/recomendations_service.dart';
import 'package:organizer/feature/bad_habbits_screen/presentation/widgets/add_bh_button.dart';
import 'package:organizer/feature/lifestyle_screen/presentation/widgets/lifestyle_recomendation_widget.dart';

class LifestyleAppbar extends StatefulWidget {
  const LifestyleAppbar({super.key});

  @override
  State<LifestyleAppbar> createState() => _LifestyleAppbarState();
}

class _LifestyleAppbarState extends State<LifestyleAppbar> {
  String recomendation = '';
  @override
  void initState() {
    _getFacts();
    super.initState();
  }

  void _getFacts() async {
    final recomendationsService = RecomendationsService(everydayRecomendations);
    await recomendationsService.init();
    setState(() {
      recomendation = recomendationsService.getTodayRecomendation();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Лайфстайл",
              style: GoogleFonts.unbounded(
                color: AppConstants.whiteColor,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
            Spacer(),
            Text(
              DateFormat('EEEE, d MMMM', 'ru').format(DateTime.now()),
              style: GoogleFonts.unbounded(fontSize: 12),
            ),
          ],
        ),
        SizedBox(height: 6),
        Row(
          children: [
            SizedBox(
              height: 34,
              width: MediaQuery.of(context).size.width * 0.89,
              child:
                  recomendation == ""
                      ? Container()
                      : FactAnimator(facts: [recomendation]),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              "«/» Совет дня",
              style: GoogleFonts.unbounded(fontSize: 11, color: Colors.grey),
            ),
          ],
        ),
      ],
    );
  }
}
