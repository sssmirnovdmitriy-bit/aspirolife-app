import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:organizer/components/app_constants.dart';

class LifestyleMessageSection extends StatelessWidget {
  const LifestyleMessageSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(
          width: 60,
          height: 60,
          child: LottieBuilder.asset(AppConstants.messageAnim, animate: true),
        ),
        SizedBox(width: 10),
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.76,
          child: Text(
            "Теперь ты можешь потратить заработанную сумму на полезную активность для жизни",
            style: GoogleFonts.unbounded(
              color: AppConstants.darkGreenColor,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
