import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/notifications/app_notifications.dart';
import 'package:organizer/core/purchase/book_constants.dart';
import 'package:organizer/core/purchase/book_purchase_service.dart';
import 'package:organizer/feature/book_screen/presentation/book_reader_screen.dart';
import 'package:purchases_flutter/purchases_flutter.dart';

class BookScreen extends StatefulWidget {
  const BookScreen({super.key});

  @override
  State<BookScreen> createState() => _BookScreenState();
}

class _BookScreenState extends State<BookScreen> {
  final _service = BookPurchaseService();

  bool _loading = true;
  bool _owned = false;
  bool _purchasing = false;
  StoreProduct? _product;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final owned = await _service.hasBook();
    final product = owned ? null : await _service.fetchProduct();
    if (!mounted) return;
    setState(() {
      _owned = owned;
      _product = product;
      _loading = false;
    });
  }

  Future<void> _buy() async {
    setState(() => _purchasing = true);
    final success = await _service.purchaseBook();
    if (!mounted) return;
    setState(() {
      _purchasing = false;
      _owned = success || _owned;
    });
    if (!success) {
      AppNotifications.showError(
        context,
        "Не удалось оформить покупку. Попробуйте ещё раз",
      );
    }
  }

  Future<void> _restore() async {
    setState(() => _purchasing = true);
    final owned = await _service.restorePurchases();
    if (!mounted) return;
    setState(() {
      _purchasing = false;
      _owned = owned || _owned;
    });
    if (!owned) {
      AppNotifications.showError(context, "Покупка не найдена");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      appBar: AppBar(
        backgroundColor: AppConstants.bgColor,
        iconTheme: IconThemeData(color: AppConstants.whiteColor),
      ),
      body:
          _loading
              ? Center(
                child: CircularProgressIndicator(
                  color: AppConstants.darkGreenColor,
                ),
              )
              : Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.menu_book_rounded,
                      color: AppConstants.darkGreenColor,
                      size: 64,
                    ),
                    SizedBox(height: 20),
                    Text(
                      bookTitle,
                      style: GoogleFonts.unbounded(
                        color: AppConstants.whiteColor,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Дмитрий Смирнов",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.greyColor,
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: 16),
                    Text(
                      bookDescription,
                      style: GoogleFonts.unbounded(
                        color: AppConstants.greyColor,
                        fontSize: 12,
                      ),
                    ),
                    Spacer(),
                    if (_owned)
                      AnimatedButton(
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => const BookReaderScreen(),
                            ),
                          );
                        },
                        child: Container(
                          height: 50,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: AppConstants.darkGreenColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: Text(
                              "Читать",
                              style: GoogleFonts.unbounded(
                                color: AppConstants.bgColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      )
                    else ...[
                      AnimatedButton(
                        onTap: _purchasing ? null : _buy,
                        child: Container(
                          height: 50,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: AppConstants.darkGreenColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child:
                                _purchasing
                                    ? SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: CircularProgressIndicator(
                                        color: AppConstants.bgColor,
                                        strokeWidth: 2,
                                      ),
                                    )
                                    : Text(
                                      "Купить за ${_product?.priceString ?? '\$15'}",
                                      style: GoogleFonts.unbounded(
                                        color: AppConstants.bgColor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      AnimatedButton(
                        onTap: _purchasing ? null : _restore,
                        child: Center(
                          child: Text(
                            "Восстановить покупку",
                            style: GoogleFonts.unbounded(
                              color: AppConstants.greyColor,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                    ],
                    SizedBox(height: 10),
                  ],
                ),
              ),
    );
  }
}
