import 'package:flutter/material.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/purchase/book_constants.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class BookReaderScreen extends StatelessWidget {
  const BookReaderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      appBar: AppBar(
        backgroundColor: AppConstants.bgColor,
        iconTheme: IconThemeData(color: AppConstants.whiteColor),
        title: Text(
          bookTitle,
          style: TextStyle(color: AppConstants.whiteColor, fontSize: 16),
        ),
      ),
      body: SfPdfViewer.asset(bookAssetPath),
    );
  }
}
