import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/animated_button.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:url_launcher/url_launcher_string.dart';

class PolicySetting extends StatelessWidget {
  const PolicySetting({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedButton(
      onTap: () {
        launchUrlString(
          'https://docs.google.com/document/d/1UZrLdeb1GrH1yVoQZfbvYBoRVw2tDwdDPZs8RyB_zMw/edit?usp=sharing',
        );
      },
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 54,
        decoration: BoxDecoration(
          color: AppConstants.secondaryColor,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "Политика конфиденциальности",
                style: GoogleFonts.unbounded(
                  color: AppConstants.whiteColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Spacer(),
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: AppConstants.whiteColor,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
