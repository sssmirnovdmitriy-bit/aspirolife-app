import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/feature/settings_screen/widgets/policy_setting.dart';
import 'package:organizer/feature/settings_screen/widgets/terms_setting.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      extendBodyBehindAppBar: false, // позволяет фону быть под AppBar
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60), // Задаем высоту AppBar
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: SafeArea(child: CustomAppBar(text: "Настройки")),
        ),
      ),

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(),

            PolicySetting(),
            SizedBox(height: 8),
            TermsSetting(),

            SizedBox(height: 50),
          ],
        ),
      ),
    );
  }
}
