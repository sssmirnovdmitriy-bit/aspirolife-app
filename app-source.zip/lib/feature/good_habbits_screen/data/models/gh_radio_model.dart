import 'package:organizer/core/models/habbit_model.dart';

class GhRadioModel {
  bool isSelected;
  final HabbitModel habbit;

  GhRadioModel(this.isSelected, this.habbit);
}
