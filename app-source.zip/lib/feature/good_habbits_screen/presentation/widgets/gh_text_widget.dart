import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/habbit_model.dart';

class GhTextInfoWidget extends ConsumerStatefulWidget {
  final HabbitModel habbit;
  const GhTextInfoWidget({super.key, required this.habbit});

  @override
  _GhTextInfoWidgetState createState() => _GhTextInfoWidgetState();
}

class _GhTextInfoWidgetState extends ConsumerState<GhTextInfoWidget> {
  List<String> textInfos = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _getTextInfos();
  }

  void _getTextInfos() {
    textInfos.clear();
    for (var element in widget.habbit.dailyMissions) {
      if (element.textInfo != null && element.textInfo!.trim().isNotEmpty) {
        textInfos.add(element.textInfo!.trim());
      }
    }
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? SizedBox(
          height: 30,
          width: 30,
          child: CircularProgressIndicator(
            strokeWidth: 1,
            color: AppConstants.darkGreenColor,
          ),
        )
        : ListView.builder(
          padding: EdgeInsets.zero,
          itemCount: textInfos.length,
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Номер блока в кружке
                  Column(
                    children: [
                      Container(
                        height: 40,
                        width: 40,
                        margin: const EdgeInsets.only(right: 12),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppConstants.darkGreenColor,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          "${index + 1}",
                          style: GoogleFonts.unbounded(
                            color: AppConstants.bgColor,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Container(
                        height: MediaQuery.of(context).size.height * 0.18,
                        width: 1,
                        margin: const EdgeInsets.only(right: 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(2),
                          color: AppConstants.darkGreenColor,
                        ),
                        alignment: Alignment.center,
                      ),
                    ],
                  ),
                  // Контейнер с текстом
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppConstants.secondaryColor.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Text(
                        textInfos[index],
                        style: GoogleFonts.unbounded(
                          color: AppConstants.darkGreenColor,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
  }
}
