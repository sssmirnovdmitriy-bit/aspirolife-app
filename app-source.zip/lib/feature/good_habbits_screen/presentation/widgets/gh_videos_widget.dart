import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:rutube_videoplayer/rutube_videoplayer.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
// Добавляем url_launcher для открытия внешних приложений
import 'package:url_launcher/url_launcher.dart';

class GhVideosWidget extends ConsumerStatefulWidget {
  final HabbitModel? habbit;
  final List<String>? customVideos;
  const GhVideosWidget({super.key, required this.habbit, this.customVideos});

  @override
  _GhVideosWidgetState createState() => _GhVideosWidgetState();
}

class _GhVideosWidgetState extends ConsumerState<GhVideosWidget> {
  List<VideoItem> videos = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _getVideos();
  }

  void _getVideos() {
    videos.clear();
    List<String> rawVideos = [];

    if (widget.customVideos == null) {
      if (widget.habbit != null) {
        for (var element in widget.habbit!.dailyMissions) {
          if (element.videoUrl != null && element.videoUrl!.isNotEmpty) {
            rawVideos.add(element.videoUrl!);
          }
        }
      }
    } else {
      rawVideos =
          widget.customVideos!.where((element) => element.isNotEmpty).toList();
    }

    for (var url in rawVideos) {
      if (url.contains('rutube.ru')) {
        videos.add(VideoItem(url: url, isYoutube: false));
      } else {
        String? videoId = YoutubePlayer.convertUrlToId(url) ?? url;
        if (videoId.isNotEmpty) {
          videos.add(VideoItem(url: videoId, isYoutube: true));
        }
      }
    }

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return SizedBox(
        height: 30,
        width: 30,
        child: CircularProgressIndicator(
          strokeWidth: 1,
          color: AppConstants.darkGreenColor,
        ),
      );
    }

    if (videos.isEmpty) {
      return Center(
        child: Text(
          'Нет доступных видео',
          style: GoogleFonts.unbounded(
            color: AppConstants.darkGreenColor,
            fontSize: 14,
          ),
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.zero,
      itemCount: videos.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 12.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: 40,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppConstants.darkGreenColor,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      "${index + 1}",
                      style: GoogleFonts.unbounded(
                        color: AppConstants.bgColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  if (index < videos.length - 1)
                    Container(
                      height: 180,
                      width: 1,
                      margin: const EdgeInsets.only(right: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                        color: AppConstants.darkGreenColor,
                      ),
                    ),
                ],
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: AppConstants.secondaryColor.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.all(8),
                  child:
                      videos[index].isYoutube
                          ? _YoutubeItemWidget(videoId: videos[index].url)
                          : RutubeVideoPlayer(videoUrl: videos[index].url),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _YoutubeItemWidget extends StatefulWidget {
  final String videoId;

  const _YoutubeItemWidget({required this.videoId});

  @override
  _YoutubeItemWidgetState createState() => _YoutubeItemWidgetState();
}

class _YoutubeItemWidgetState extends State<_YoutubeItemWidget> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = YoutubePlayerController(
      initialVideoId: widget.videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: false,
        mute: false,
        disableDragSeek: false,
        loop: false,
        isLive: false,
        forceHD: false,
        enableCaption: false,
      ),
    );
  }

  @override
  void deactivate() {
    _controller.pause();
    super.deactivate();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // Функция для открытия приложения YouTube
  Future<void> _launchNativeYoutube() async {
    // Останавливаем воспроизведение внутри приложения перед выходом
    _controller.pause();

    final Uri url = Uri.parse(
      'https://www.youtube.com/watch?v=${widget.videoId}',
    );

    // Mode.externalApplication заставляет систему открыть именно приложение YouTube,
    // если оно установлено, а не WebView.
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      debugPrint("Ошибка открытия ссылки: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // Мы убрали YoutubePlayerBuilder, так как не используем полноэкранный режим внутри приложения
    return YoutubePlayer(
      controller: _controller,
      showVideoProgressIndicator: true,
      progressIndicatorColor: AppConstants.darkGreenColor,
      progressColors: ProgressBarColors(
        playedColor: AppConstants.darkGreenColor,
        handleColor: AppConstants.darkGreenColor,
        backgroundColor: Colors.grey.withOpacity(0.3),
        bufferedColor: Colors.grey.withOpacity(0.5),
      ),
      // Настраиваем нижнюю панель
      bottomActions: [
        CurrentPosition(),
        const SizedBox(width: 10),
        ProgressBar(isExpanded: true),
        const SizedBox(width: 10),
        RemainingDuration(),
        // Вместо стандартной кнопки FullScreenButton ставим свою
        IconButton(
          icon: const Icon(
            Icons.open_in_new, // Или можно использовать Icons.fullscreen
            color: Colors.white,
          ),
          onPressed: _launchNativeYoutube, // Вызываем нашу функцию
          tooltip: 'Открыть в YouTube',
        ),
      ],
    );
  }
}

class VideoItem {
  final String url;
  final bool isYoutube;

  VideoItem({required this.url, required this.isYoutube});
}
