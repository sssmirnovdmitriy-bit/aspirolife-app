import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/add_gh_button.dart';

class GhAppbar extends StatelessWidget {
  const GhAppbar({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "Полезные привычки",
          style: GoogleFonts.unbounded(
            color: AppConstants.whiteColor,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
        AddGHButton(),
      ],
    );
  }
}
