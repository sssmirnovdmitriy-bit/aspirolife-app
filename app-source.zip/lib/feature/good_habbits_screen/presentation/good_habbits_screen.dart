import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/core/navigation/navigation.dart';
import 'package:organizer/core/services/money_counter/money_count_widget.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/add_gh_button.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/gh_appbar.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/gh_card.dart';
import 'package:unicons/unicons.dart';

class GoodHabbitsScreen extends ConsumerWidget {
  const GoodHabbitsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var ghModel = ref.watch(ghController);
    return Scaffold(
      // floatingActionButton: AddGHButton(),
      // backgroundColor: AppConstants.bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor,
              AppConstants.bgColor.withOpacity(0.5),
              AppConstants.bgGreyColor.withOpacity(0.3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                GhAppbar(),
                // SizedBox(height: 10),
                // MoneyCountWidget(isGoodHabbit: true),
                SizedBox(height: 10),
                ghModel.myActiveGoodHabbits.isNotEmpty
                    ? Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.only(bottom: 100.0),
                        shrinkWrap: true,
                        itemCount: ghModel.myActiveGoodHabbits.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: GhCard(
                              onTapStats: () {
                                Navigation.goToHabitAnalyticsScreen(
                                  context,
                                  ghModel.myActiveGoodHabbits[index],
                                );
                              },
                              onTap: () {
                                Navigation.goToGhDetailsScreen(
                                  context,
                                  ghModel.myActiveGoodHabbits[index],
                                );
                              },
                              habbitModel: ghModel.myActiveGoodHabbits[index],
                            ),
                          );
                        },
                      ),
                    )
                    : Padding(
                      padding: const EdgeInsets.only(top: 200),
                      child: SizedBox(
                        child: Column(
                          children: [
                            Icon(
                              UniconsLine.box,
                              size: 50,
                              color: AppConstants.greyColor,
                            ),
                            SizedBox(height: 16),
                            Text(
                              "Здесь пока пусто",
                              style: GoogleFonts.unbounded(
                                color: AppConstants.darkGreenColor,
                                fontSize: 12,
                              ),
                            ),
                            SizedBox(height: 8),
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.7,
                              child: Text(
                                "Нажмите кнопку сверху, чтобы начать отслеживать первую привычку",
                                textAlign: TextAlign.center,
                                style: GoogleFonts.unbounded(
                                  color: AppConstants.greyColor,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
