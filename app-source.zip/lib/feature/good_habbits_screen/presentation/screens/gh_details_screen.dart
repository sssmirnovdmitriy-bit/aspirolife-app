import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:organizer/components/app_constants.dart';
import 'package:organizer/components/custom_app_bar.dart';
import 'package:organizer/core/models/habbit_model.dart';
import 'package:organizer/core/storages/mock_habbit_storage.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/controller/gh_controller.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/gh_text_widget.dart';
import 'package:organizer/feature/good_habbits_screen/presentation/widgets/gh_videos_widget.dart';

class GhDetailsScreen extends ConsumerStatefulWidget {
  final HabbitModel habbitModel;
  const GhDetailsScreen({required this.habbitModel, super.key});

  @override
  _AddGhScreenSecondState createState() => _AddGhScreenSecondState();
}

class _AddGhScreenSecondState extends ConsumerState<GhDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    var ghModel = ref.watch(ghController);
    return Scaffold(
      backgroundColor: AppConstants.bgColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(text: "${widget.habbitModel.habbitName}"),
              Expanded(
                child: ListView(
                  children: [
                    Builder(
                      builder: (context) {
                        if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.JOGGING.name) {
                          return Column(
                            children: [
                              SizedBox(height: 20),
                              GhTextInfoWidget(habbit: widget.habbitModel),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.YOGA.name) {
                          return Column(
                            children: [
                              SizedBox(height: 20),
                              GhVideosWidget(habbit: widget.habbitModel),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.GYM.name) {
                          return Column(
                            children: [
                              SizedBox(height: 20),
                              GhVideosWidget(habbit: widget.habbitModel),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.EATING.name) {
                          return Column(
                            children: [
                              SizedBox(height: 20),
                              GhTextInfoWidget(habbit: widget.habbitModel),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.MEDITATION.name) {
                          return Column(
                            children: [
                              SizedBox(height: 20),
                              GhVideosWidget(habbit: widget.habbitModel),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.HARDENING.name) {
                          return Column(
                            children: [
                              SizedBox(height: 20),
                              GhVideosWidget(habbit: widget.habbitModel),
                            ],
                          );
                        } else if (widget.habbitModel.habbitType ==
                            GoodHabitTypes.WORKOUT.name) {
                          return Column(
                            children: [
                              SizedBox(height: 20),
                              GhVideosWidget(habbit: widget.habbitModel),
                            ],
                          );
                        } else {
                          return SizedBox();
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
