// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

// ignore_for_file: constant_identifier_names

abstract class  LocaleKeys {
  static const button_bottom_navbar_organizer = 'button_bottom_navbar_organizer';

}
